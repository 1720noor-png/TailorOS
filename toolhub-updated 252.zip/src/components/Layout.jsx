import { useEffect, useRef, useState } from 'react'
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { categories, tools } from '../data/registry.js'

const SearchIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" />
  </svg>
)

function useTheme() {
  const [theme, setTheme] = useState(() => {
    try { return localStorage.getItem('toolhub-theme') || 'auto' } catch { return 'auto' }
  })
  useEffect(() => {
    try {
      if (theme === 'auto') { document.documentElement.removeAttribute('data-theme'); localStorage.removeItem('toolhub-theme') }
      else { document.documentElement.setAttribute('data-theme', theme); localStorage.setItem('toolhub-theme', theme) }
    } catch { /* ignore */ }
  }, [theme])
  const effective = theme === 'auto'
    ? (typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
    : theme
  return [effective, () => setTheme(effective === 'dark' ? 'light' : 'dark')]
}

export default function Layout() {
  const [open, setOpen] = useState(false)
  const [mega, setMega] = useState(false)
  const { pathname } = useLocation()
  const nav = useNavigate()
  const searchRef = useRef(null)
  const megaRef = useRef(null)
  const [effectiveTheme, toggleTheme] = useTheme()

  useEffect(() => { setOpen(false); setMega(false); window.scrollTo(0, 0) }, [pathname])

  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); searchRef.current?.focus() }
      if (e.key === 'Escape') setMega(false)
    }
    const onClick = (e) => { if (megaRef.current && !megaRef.current.contains(e.target)) setMega(false) }
    window.addEventListener('keydown', onKey)
    window.addEventListener('mousedown', onClick)
    return () => { window.removeEventListener('keydown', onKey); window.removeEventListener('mousedown', onClick) }
  }, [])

  const submit = (e) => {
    e.preventDefault()
    const q = new FormData(e.currentTarget).get('q').toString().trim()
    nav(q ? `/?q=${encodeURIComponent(q)}` : '/')
  }

  const popularCount = (slug) => tools.filter((t) => t.cat === slug).length
  const popularTools = tools.filter((t) => t.popular).slice(0, 6)
  const featuredCats = categories.slice(0, 6)

  return (
    <>
      <a className="skip" href="#main">Skip to content</a>
      <header className="top">
        <div className="wrap bar">
          <Link to="/" className="brand">
            <span className="brand-mark" aria-hidden="true">T</span>
            ToolHub
          </Link>

          <button className="burger" aria-expanded={open} aria-controls="menu" aria-label="Toggle menu" onClick={() => setOpen(!open)}>☰</button>

          <nav id="menu" className={open ? 'open' : ''} aria-label="Main">
            <form className="nav-search" role="search" onSubmit={submit}>
              <SearchIcon />
              <input ref={searchRef} name="q" type="search" placeholder="Search tools…" aria-label="Search tools" id="global-search" />
              <span className="kbd-hint" aria-hidden="true">Ctrl K</span>
            </form>

            <NavLink to="/" end>Home</NavLink>

            <div className="mega-wrap" ref={megaRef}>
              <button type="button" className="mega-btn" aria-expanded={mega} aria-haspopup="true" onClick={() => setMega(!mega)}>
                Categories <span className="chev" aria-hidden="true">▾</span>
              </button>
              {mega && (
                <div className="mega-panel" role="menu">
                  {featuredCats.map((c) => (
                    <Link key={c.slug} to={'/' + c.slug} className={'mega-item accent-' + c.accent} role="menuitem">
                      <span className="mega-ico" aria-hidden="true">{c.icon}</span>
                      <span><strong>{c.short}</strong><span>{popularCount(c.slug)} tools</span></span>
                    </Link>
                  ))}
                  <div className="mega-footer"><Link to="/categories">View all {categories.length} categories →</Link></div>
                </div>
              )}
            </div>

            <NavLink to="/tools">All Tools</NavLink>
            <NavLink to="/tools?popular=1">Popular</NavLink>
          </nav>

          <div className="navbar-actions">
            <button type="button" className="icon-btn" onClick={toggleTheme} aria-label={effectiveTheme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}>
              {effectiveTheme === 'dark' ? '☀️' : '🌙'}
            </button>
          </div>
        </div>
      </header>

      <main id="main" className="wrap"><Outlet /></main>

      <footer className="site-footer">
        <div className="wrap">
          <div className="footer-grid">
            <div className="footer-brand">
              <Link to="/" className="brand"><span className="brand-mark" aria-hidden="true">T</span>ToolHub</Link>
              <p>{tools.length}+ free tools that run entirely in your browser. No accounts, no tracking, nothing uploaded.</p>
            </div>
            <div className="footer-col">
              <h4>Product</h4>
              <Link to="/">Home</Link>
              <Link to="/tools">All Tools</Link>
              <Link to="/categories">All Categories</Link>
              <Link to="/tools?popular=1">Popular Tools</Link>
            </div>
            <div className="footer-col">
              <h4>Categories</h4>
              {categories.slice(0, 5).map((c) => <Link key={c.slug} to={'/' + c.slug}>{c.short}</Link>)}
            </div>
            <div className="footer-col">
              <h4>Popular Tools</h4>
              {popularTools.slice(0, 5).map((t) => <Link key={t.cat + t.slug} to={`/${t.cat}/${t.slug}`}>{t.name}</Link>)}
            </div>
            <div className="footer-col">
              <h4>ToolHub</h4>
              <span style={{ display: 'block', marginBottom: '.55rem', fontSize: '.88rem' }}>100% client-side</span>
              <span style={{ display: 'block', marginBottom: '.55rem', fontSize: '.88rem' }}>No sign-up required</span>
              <span style={{ display: 'block', fontSize: '.88rem' }}>{categories.length} categories</span>
            </div>
          </div>
          <div className="footer-bottom">
            <span>© {new Date().getFullYear()} ToolHub. All calculations run locally in your browser.</span>
          </div>
        </div>
      </footer>
    </>
  )
}
