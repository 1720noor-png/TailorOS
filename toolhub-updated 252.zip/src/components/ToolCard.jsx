import { Link } from 'react-router-dom'
import { categories } from '../data/registry.js'
export default function ToolCard({ t }) {
  const c = categories.find((x) => x.slug === t.cat)
  const accent = c?.accent || 'blue'
  return (
    <Link className={'tool accent-' + accent} to={`/${t.cat}/${t.slug}`}>
      <div className="tool-top">
        <span className="ico" aria-hidden="true">{t.icon}</span>
        {t.popular && <span className="badges"><span className="badge popular">Popular</span></span>}
      </div>
      <h3>{t.name}</h3>
      <p>{t.desc}</p>
      {t.subcatName && <span className="badges" style={{ marginTop: '.5rem' }}><span className="badge sub">{t.subcatName}</span></span>}
      <p className="why"><b>Why useful?</b> {t.why}</p>
      <span className="open">Open tool →</span>
    </Link>
  )
}
