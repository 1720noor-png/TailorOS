import Gpa from '../tools/student/GpaCalculator.jsx'
import Percentage from '../tools/student/PercentageCalculator.jsx'
import Json from '../tools/developer/JsonFormatter.jsx'
import B64 from '../tools/developer/Base64Tool.jsx'
import Leave from '../tools/office/LeaveCalculator.jsx'
import Utm from '../tools/marketing/UtmBuilder.jsx'
import Pomodoro from '../tools/productivity/PomodoroTimer.jsx'
import Discount from '../tools/shopping/DiscountCalculator.jsx'
import Password from '../tools/security/PasswordGenerator.jsx'
import Hash from '../tools/security/HashGenerator.jsx'
import Grade from '../tools/student/GradeCalculator.jsx'
import Attendance from '../tools/student/AttendanceCalculator.jsx'
import Study from '../tools/student/StudyPlanner.jsx'
import Exam from '../tools/student/ExamCountdown.jsx'
import Timetable from '../tools/student/TimetableGenerator.jsx'
import Citation from '../tools/student/CitationGenerator.jsx'
import Assignment from '../tools/student/AssignmentPlanner.jsx'
import Flash from '../tools/student/FlashcardMaker.jsx'
import JsonVal from '../tools/developer/JsonValidator.jsx'
import Fmt from '../tools/developer/CodeFormatter.jsx'
import Regex from '../tools/developer/RegexTester.jsx'
import Url from '../tools/developer/UrlEncoder.jsx'
import Minify from '../tools/developer/Minifier.jsx'
import Color from '../tools/developer/ColorConverter.jsx'
import Qr from '../tools/developer/QrGenerator.jsx'
import Ts from '../tools/developer/TimestampConverter.jsx'
import Invoice from '../tools/office/InvoiceGenerator.jsx'
import Agenda from '../tools/office/MeetingAgenda.jsx'
import Minutes from '../tools/office/MeetingMinutes.jsx'
import TaskMgr from '../tools/office/TaskManager.jsx'
import Letter from '../tools/office/BusinessLetter.jsx'
import Signature from '../tools/office/EmailSignature.jsx'
import Timesheet from '../tools/office/TimesheetCalculator.jsx'
import Expense from '../tools/office/ExpenseReport.jsx'
import DocList from '../tools/office/DocumentChecklist.jsx'
import Keywords from '../tools/marketing/KeywordGenerator.jsx'
import Meta from '../tools/marketing/MetaTagGenerator.jsx'
import Hashtag from '../tools/marketing/HashtagGenerator.jsx'
import Caption from '../tools/marketing/CaptionGenerator.jsx'
import SeoTitle from '../tools/marketing/SeoTitleGenerator.jsx'
import SeoDesc from '../tools/marketing/SeoDescriptionGenerator.jsx'
import Calendar from '../tools/marketing/ContentCalendar.jsx'
import Serp from '../tools/marketing/SerpPreview.jsx'
import Roi from '../tools/marketing/MarketingRoi.jsx'
import Habit from '../tools/productivity/HabitTracker.jsx'
import Todo from '../tools/productivity/TodoList.jsx'
import DailyPlan from '../tools/productivity/DailyPlanner.jsx'
import WeeklyPlan from '../tools/productivity/WeeklyPlanner.jsx'
import TzConv from '../tools/productivity/TimeZoneConverter.jsx'
import WorldClock from '../tools/productivity/WorldClock.jsx'
import Countdown from '../tools/productivity/CountdownTimer.jsx'
import Decision from '../tools/productivity/RandomDecisionMaker.jsx'
import RandNum from '../tools/productivity/RandomNumberGenerator.jsx'
import ShopList from '../tools/shopping/ShoppingListMaker.jsx'
import PriceCmp from '../tools/shopping/PriceComparison.jsx'
import SalesTax from '../tools/shopping/SalesTaxCalculator.jsx'
import Tip from '../tools/shopping/TipCalculator.jsx'
import SplitBill from '../tools/shopping/SplitBillCalculator.jsx'
import UnitPrice from '../tools/shopping/UnitPriceCalculator.jsx'
import ShopBudget from '../tools/shopping/ShoppingBudgetCalculator.jsx'
import GiftBudget from '../tools/shopping/GiftBudgetPlanner.jsx'
import GroceryBudget from '../tools/shopping/GroceryBudgetPlanner.jsx'

// Finance & Investment Tools
import MortgageEmi from '../tools/finance/MortgageEmiCalculator.jsx'
import LoanPayoff from '../tools/finance/LoanPayoffCalculator.jsx'
import CompoundInterest from '../tools/finance/CompoundInterestCalculator.jsx'
import SipCalc from '../tools/finance/SipCalculator.jsx'

// Fitness & Personal Health Tools
import BmrTdee from '../tools/fitness/BmrTdeeCalculator.jsx'
import MacroCalc from '../tools/fitness/MacroCalculator.jsx'
import OneRepMax from '../tools/fitness/OneRepMaxCalculator.jsx'
import PaceCalc from '../tools/fitness/PaceCalculator.jsx'

// Design & Typography Tools
import TypeScale from '../tools/design/TypeScaleGenerator.jsx'
import AspectRatio from '../tools/design/AspectRatioCalculator.jsx'
import BoxShadow from '../tools/design/BoxShadowGenerator.jsx'
import GradientGen from '../tools/design/GradientGenerator.jsx'

// Math & Unit Conversion Tools
import UnitConv from '../tools/math/UnitConverter.jsx'
import DataConv from '../tools/math/DataConverter.jsx'
import GeometryCalc from '../tools/math/GeometryCalculator.jsx'
import StatsCalc from '../tools/math/StatisticsCalculator.jsx'

// Lifestyle & Travel Tools
import PackingList from '../tools/lifestyle/PackingListGenerator.jsx'
import FuelCost from '../tools/lifestyle/FuelCostCalculator.jsx'
import SpeechTiming from '../tools/lifestyle/SpeechReadingTimeCalculator.jsx'
import WaterIntake from '../tools/lifestyle/WaterIntakeCalculator.jsx'

// Communication Tools
import MsgLen from '../tools/communication/MessageLengthAnalyzer.jsx'
import MsgFmt from '../tools/communication/MessageFormattingHelper.jsx'
import TopicGen from '../tools/communication/ConversationTopicGenerator.jsx'
import OneOnOnePrep from '../tools/communication/OneOnOnePrepPlanner.jsx'

// Audio & Sound Tools
import AudioDur from '../tools/audio/AudioDurationCalculator.jsx'
import AudioSize from '../tools/audio/AudioFileSizeEstimator.jsx'
import DecibelRef from '../tools/audio/DecibelReferenceTool.jsx'
import FreqConv from '../tools/audio/FrequencyConverter.jsx'

// Music Tools
import BpmConv from '../tools/music/BpmConverter.jsx'
import NoteFreq from '../tools/music/MusicNoteFrequencyCalculator.jsx'
import ChordProg from '../tools/music/ChordProgressionGenerator.jsx'
import Metronome from '../tools/music/MetronomeTool.jsx'

// Pet Care Tools
import PetFeed from '../tools/pet/PetFeedingSchedule.jsx'
import PetExp from '../tools/pet/PetExpenseTracker.jsx'
import PetAge from '../tools/pet/PetAgeConverter.jsx'
import PetMed from '../tools/pet/PetMedicationSchedule.jsx'

// Automotive Tools
import CarDeprec from '../tools/automotive/CarDepreciationCalculator.jsx'
import CarOwnerCost from '../tools/automotive/CarOwnershipCostCalculator.jsx'
import TireCmp from '../tools/automotive/TireSizeComparison.jsx'
import MaintPlan from '../tools/automotive/VehicleMaintenancePlanner.jsx'

// Accessibility Tools
import ContrastCheck from '../tools/accessibility/ContrastRatioChecker.jsx'
import ColorBlindSim from '../tools/accessibility/ColorBlindnessSimulator.jsx'
import FontA11yCheck from '../tools/accessibility/FontSizeAccessibilityChecker.jsx'
import LineSpacingCalc from '../tools/accessibility/LineSpacingCalculator.jsx'

// Science & Measurement Tools
import OhmsLaw from '../tools/science/OhmsLawCalculator.jsx'
import ForceCalc from '../tools/science/ForceCalculator.jsx'
import SciNotation from '../tools/science/ScientificNotationConverter.jsx'
import SigFigs from '../tools/science/SignificantFiguresCalculator.jsx'

// Astronomy & Space Tools
import LightYearConv from '../tools/astronomy/LightYearConverter.jsx'
import WeightPlanets from '../tools/astronomy/WeightOnPlanetsCalculator.jsx'
import MoonPhase from '../tools/astronomy/MoonPhaseCalculator.jsx'
import PlanetSize from '../tools/astronomy/PlanetarySizeComparison.jsx'

// Privacy & Digital Safety Tools
import PassStrength from '../tools/privacy/PasswordStrengthAnalyzer.jsx'
import DataExpCheck from '../tools/privacy/PersonalDataExposureChecklist.jsx'
import PrivSettingsCheck from '../tools/privacy/PrivacySettingsChecklist.jsx'
import FileShareCheck from '../tools/privacy/SecureFileSharingChecklist.jsx'

// Geography & Maps Tools
import LatLngConv from '../tools/geography/LatitudeLongitudeConverter.jsx'
import CoordDist from '../tools/geography/CoordinateDistanceCalculator.jsx'
import DaylightSolar from '../tools/geography/DaylightSolarCalculator.jsx'
import CountryArea from '../tools/geography/CountryAreaComparison.jsx'

// Batch: first 30 of 300 new tools
import WordCounter from '../tools/student/WordCounter.jsx'
import EssayOutlineGenerator from '../tools/student/EssayOutlineGenerator.jsx'
import UuidGenerator from '../tools/developer/UuidGenerator.jsx'
import CronExpressionExplainer from '../tools/developer/CronExpressionExplainer.jsx'
import CssUnitConverter from '../tools/developer/CssUnitConverter.jsx'
import LoremIpsumGenerator from '../tools/developer/LoremIpsumGenerator.jsx'
import HttpStatusLookup from '../tools/developer/HttpStatusLookup.jsx'
import OutOfOfficeGenerator from '../tools/office/OutOfOfficeGenerator.jsx'
import SalaryBreakdownCalculator from '../tools/office/SalaryBreakdownCalculator.jsx'
import MeetingCostCalculator from '../tools/office/MeetingCostCalculator.jsx'
import OnboardingChecklist from '../tools/office/OnboardingChecklist.jsx'
import SocialCharacterCounter from '../tools/marketing/SocialCharacterCounter.jsx'
import AdBudgetEstimator from '../tools/marketing/AdBudgetEstimator.jsx'
import EisenhowerMatrix from '../tools/productivity/EisenhowerMatrix.jsx'
import GoalMilestoneTracker from '../tools/productivity/GoalMilestoneTracker.jsx'
import SubscriptionCostTracker from '../tools/shopping/SubscriptionCostTracker.jsx'
import CostPerUseCalculator from '../tools/shopping/CostPerUseCalculator.jsx'
import PassphraseGenerator from '../tools/security/PassphraseGenerator.jsx'
import PinGenerator from '../tools/security/PinGenerator.jsx'
import DebtPayoffStrategyPlanner from '../tools/finance/DebtPayoffStrategyPlanner.jsx'
import RetirementSavingsCalculator from '../tools/finance/RetirementSavingsCalculator.jsx'
import CalorieBurnEstimator from '../tools/fitness/CalorieBurnEstimator.jsx'
import HeartRateZoneCalculator from '../tools/fitness/HeartRateZoneCalculator.jsx'
import ColorPaletteGenerator from '../tools/design/ColorPaletteGenerator.jsx'
import BorderRadiusGenerator from '../tools/design/BorderRadiusGenerator.jsx'
import CookingMeasurementConverter from '../tools/math/CookingMeasurementConverter.jsx'
import SleepCycleCalculator from '../tools/lifestyle/SleepCycleCalculator.jsx'
import MessageToneChecker from '../tools/communication/MessageToneChecker.jsx'
import ReadabilityScoreChecker from '../tools/accessibility/ReadabilityScoreChecker.jsx'
import OrbitalPeriodCalculator from '../tools/astronomy/OrbitalPeriodCalculator.jsx'

// Gardening Tools
import WateringScheduleCalculator from '../tools/gardening/WateringScheduleCalculator.jsx'
import SoilPhAdjustmentCalculator from '../tools/gardening/SoilPhAdjustmentCalculator.jsx'
import SeedStartingDateCalculator from '../tools/gardening/SeedStartingDateCalculator.jsx'
import GardenBedLayoutPlanner from '../tools/gardening/GardenBedLayoutPlanner.jsx'

// Photography Tools
import ExposureTriangleCalculator from '../tools/photography/ExposureTriangleCalculator.jsx'
import DepthOfFieldCalculator from '../tools/photography/DepthOfFieldCalculator.jsx'
import GoldenHourCalculator from '../tools/photography/GoldenHourCalculator.jsx'
import PhotoPrintSizeCalculator from '../tools/photography/PhotoPrintSizeCalculator.jsx'

// Home Maintenance Tools
import PaintCoverageCalculator from '../tools/home/PaintCoverageCalculator.jsx'
import WallpaperCalculator from '../tools/home/WallpaperCalculator.jsx'
import HvacFilterReminder from '../tools/home/HvacFilterReminder.jsx'
import MaintenanceChecklistGenerator from '../tools/home/MaintenanceChecklistGenerator.jsx'

// Electronics Tools
import ResistorColorCodeCalculator from '../tools/electronics/ResistorColorCodeCalculator.jsx'
import VoltageDividerCalculator from '../tools/electronics/VoltageDividerCalculator.jsx'
import BatteryLifeEstimator from '../tools/electronics/BatteryLifeEstimator.jsx'
import WireGaugeCalculator from '../tools/electronics/WireGaugeCalculator.jsx'

// Parenting Tools
import BabyFeedingScheduleTracker from '../tools/parenting/BabyFeedingScheduleTracker.jsx'
import DueDateCalculator from '../tools/parenting/DueDateCalculator.jsx'
import ChildGrowthRateTracker from '../tools/parenting/ChildGrowthRateTracker.jsx'
import ScreenTimeTracker from '../tools/parenting/ScreenTimeTracker.jsx'

// Events Tools
import PartyBudgetPlanner from '../tools/events/PartyBudgetPlanner.jsx'
import CateringQuantityCalculator from '../tools/events/CateringQuantityCalculator.jsx'
import RsvpTracker from '../tools/events/RsvpTracker.jsx'
import SeatingChartPlanner from '../tools/events/SeatingChartPlanner.jsx'

// Sewing & Crafts Tools
import FabricYardageCalculator from '../tools/crafts/FabricYardageCalculator.jsx'
import SeamAllowanceCalculator from '../tools/crafts/SeamAllowanceCalculator.jsx'
import YarnRequirementEstimator from '../tools/crafts/YarnRequirementEstimator.jsx'
import CraftProjectCostCalculator from '../tools/crafts/CraftProjectCostCalculator.jsx'

// Sports Tools
import ShootingPercentageTracker from '../tools/sports/ShootingPercentageTracker.jsx'
import TeamRosterRotationPlanner from '../tools/sports/TeamRosterRotationPlanner.jsx'
import TournamentBracketGenerator from '../tools/sports/TournamentBracketGenerator.jsx'
import FantasyPointsCalculator from '../tools/sports/FantasyPointsCalculator.jsx'

// Weather Tools
import WindChillCalculator from '../tools/weather/WindChillCalculator.jsx'
import HeatIndexCalculator from '../tools/weather/HeatIndexCalculator.jsx'
import DewPointCalculator from '../tools/weather/DewPointCalculator.jsx'
import RainfallCollectionCalculator from '../tools/weather/RainfallCollectionCalculator.jsx'

// Construction Tools
import ConcreteVolumeCalculator from '../tools/construction/ConcreteVolumeCalculator.jsx'
import LumberBoardFeetCalculator from '../tools/construction/LumberBoardFeetCalculator.jsx'
import RoofingSquareCalculator from '../tools/construction/RoofingSquareCalculator.jsx'
import DrywallSheetCalculator from '../tools/construction/DrywallSheetCalculator.jsx'

// Interior Design Tools
import FurnitureLayoutSpacePlanner from '../tools/interior/FurnitureLayoutSpacePlanner.jsx'
import FlooringSquareFootageCalculator from '../tools/interior/FlooringSquareFootageCalculator.jsx'
import RugSizeCalculator from '../tools/interior/RugSizeCalculator.jsx'
import CurtainFabricCalculator from '../tools/interior/CurtainFabricCalculator.jsx'

// Business Operations Tools
import BreakEvenPointCalculator from '../tools/business/BreakEvenPointCalculator.jsx'
import ProfitMarginCalculator from '../tools/business/ProfitMarginCalculator.jsx'
import InventoryReorderPointCalculator from '../tools/business/InventoryReorderPointCalculator.jsx'
import StaffSchedulingCoverageCalculator from '../tools/business/StaffSchedulingCoverageCalculator.jsx'

// Personal Organization Tools
import ClosetDeclutteringPlanner from '../tools/organization/ClosetDeclutteringPlanner.jsx'
import MovingBoxInventoryTracker from '../tools/organization/MovingBoxInventoryTracker.jsx'
import FileNamingConventionGenerator from '../tools/organization/FileNamingConventionGenerator.jsx'
import DigitalPhotoOrganizationPlanner from '../tools/organization/DigitalPhotoOrganizationPlanner.jsx'

// Household Tools
import CleaningScheduleRotator from '../tools/household/CleaningScheduleRotator.jsx'
import LaundryLoadSizeEstimator from '../tools/household/LaundryLoadSizeEstimator.jsx'
import HomeInventoryValueTracker from '../tools/household/HomeInventoryValueTracker.jsx'
import PantryStockTracker from '../tools/household/PantryStockTracker.jsx'

// Language Learning Tools
import VocabularyGrowthTracker from '../tools/language/VocabularyGrowthTracker.jsx'
import FlashcardReviewIntervalCalculator from '../tools/language/FlashcardReviewIntervalCalculator.jsx'
import LanguageStudyStreakTracker from '../tools/language/LanguageStudyStreakTracker.jsx'
import ImmersionHoursCalculator from '../tools/language/ImmersionHoursCalculator.jsx'

// Outdoor & Camping Tools
import CampingFoodQuantityCalculator from '../tools/outdoor/CampingFoodQuantityCalculator.jsx'
import TentCapacityChecker from '../tools/outdoor/TentCapacityChecker.jsx'
import BackpackWeightCalculator from '../tools/outdoor/BackpackWeightCalculator.jsx'
import CampfireWoodCalculator from '../tools/outdoor/CampfireWoodCalculator.jsx'

// Real Estate Investment Tools
import CapRateCalculator from '../tools/realestate/CapRateCalculator.jsx'
import CashOnCashReturnCalculator from '../tools/realestate/CashOnCashReturnCalculator.jsx'
import RentVsBuyComparisonTool from '../tools/realestate/RentVsBuyComparisonTool.jsx'
import RentalPropertyCashFlowCalculator from '../tools/realestate/RentalPropertyCashFlowCalculator.jsx'
import PropertyAppreciationEstimator from '../tools/realestate/PropertyAppreciationEstimator.jsx'
import RentIncreaseCalculator from '../tools/realestate/RentIncreaseCalculator.jsx'
import SecurityDepositCalculator from '../tools/realestate/SecurityDepositCalculator.jsx'
import LandlordLateFeeCalculator from '../tools/realestate/LandlordLateFeeCalculator.jsx'
import VacancyRateCalculator from '../tools/realestate/VacancyRateCalculator.jsx'
import OnePercentRulePropertyScreener from '../tools/realestate/OnePercentRulePropertyScreener.jsx'
import ClosingCostEstimator from '../tools/realestate/ClosingCostEstimator.jsx'
import HomeEquityCalculator from '../tools/realestate/HomeEquityCalculator.jsx'

// Insurance Tools
import LifeInsuranceNeedsCalculator from '../tools/insurance/LifeInsuranceNeedsCalculator.jsx'
import InsuranceCoverageGapCalculator from '../tools/insurance/InsuranceCoverageGapCalculator.jsx'
import HealthInsuranceDeductibleTracker from '../tools/insurance/HealthInsuranceDeductibleTracker.jsx'
import DeductiblePremiumTradeoffCalculator from '../tools/insurance/DeductiblePremiumTradeoffCalculator.jsx'
import RentersInsuranceCoverageEstimator from '../tools/insurance/RentersInsuranceCoverageEstimator.jsx'
import UmbrellaPolicyCoverageCalculator from '../tools/insurance/UmbrellaPolicyCoverageCalculator.jsx'
import InsuranceClaimDocumentationChecklist from '../tools/insurance/InsuranceClaimDocumentationChecklist.jsx'
import TermVsWholeLifeComparison from '../tools/insurance/TermVsWholeLifeComparison.jsx'
import HsaContributionCalculator from '../tools/insurance/HsaContributionCalculator.jsx'
import PremiumPaymentFrequencyCalculator from '../tools/insurance/PremiumPaymentFrequencyCalculator.jsx'
import OutOfPocketMaximumTracker from '../tools/insurance/OutOfPocketMaximumTracker.jsx'
import InsurancePolicyRenewalReminder from '../tools/insurance/InsurancePolicyRenewalReminder.jsx'

// Retirement Planning Tools
import SocialSecurityBenefitEstimator from '../tools/retirement/SocialSecurityBenefitEstimator.jsx'
import EmployerMatchCalculator from '../tools/retirement/EmployerMatchCalculator.jsx'
import WithdrawalRateCalculator from '../tools/retirement/WithdrawalRateCalculator.jsx'
import RmdCalculator from '../tools/retirement/RmdCalculator.jsx'
import IncomeReplacementRatioCalculator from '../tools/retirement/IncomeReplacementRatioCalculator.jsx'
import YearsToRetirementCountdown from '../tools/retirement/YearsToRetirementCountdown.jsx'
import PensionLumpSumVsAnnuity from '../tools/retirement/PensionLumpSumVsAnnuity.jsx'
import CatchUpContributionCalculator from '../tools/retirement/CatchUpContributionCalculator.jsx'
import CoastFireCalculator from '../tools/retirement/CoastFireCalculator.jsx'
import RetirementHealthcareCostEstimator from '../tools/retirement/RetirementHealthcareCostEstimator.jsx'
import SocialSecurityClaimingAgeComparison from '../tools/retirement/SocialSecurityClaimingAgeComparison.jsx'
import RequiredSavingsRateCalculator from '../tools/retirement/RequiredSavingsRateCalculator.jsx'

export const categories = [
  { slug: 'student-tools', accent: 'indigo', short: 'Student', name: 'Student Tools', icon: '🎓', desc: 'Grades, percentages and study calculators for coursework.' },
  { slug: 'developer-tools', accent: 'blue', short: 'Developer', name: 'Developer Tools', icon: '💻', desc: 'Format, encode and inspect data while you build.' },
  { slug: 'office-tools', accent: 'orange', short: 'Office', name: 'Office Tools', icon: '🏢', desc: 'Everyday calculators and generators for work.' },
  { slug: 'marketing-tools', accent: 'pink', short: 'Marketing', name: 'Marketing Tools', icon: '📣', desc: 'Campaign tracking and SEO helpers that need no paid API.' },
  { slug: 'productivity-tools', accent: 'teal', short: 'Productivity', name: 'Productivity Tools', icon: '⏱️', desc: 'Timers and planners to keep you focused.' },
  { slug: 'shopping-tools', accent: 'amber', short: 'Shopping', name: 'Shopping Tools', icon: '🛒', desc: 'Work out what you really pay before you buy.' },
  { slug: 'security-tools', accent: 'green', short: 'Security', name: 'Security & Privacy Tools', icon: '🔒', desc: 'Passwords and hashes generated locally in your browser.' },
  { slug: 'finance-tools', accent: 'amber', short: 'Finance', name: 'Finance & Investment Tools', icon: '💰', desc: 'Mortgage EMI, loan payoffs, compound growth, and SIP return calculators.',
    subcategories: [
      { slug: 'loan-debt', name: 'Loan & Debt Calculators' },
      { slug: 'investment-savings', name: 'Investment & Savings Tools' },
    ]
  },
  { slug: 'fitness-tools', accent: 'green', short: 'Fitness', name: 'Fitness & Personal Health Tools', icon: '🏋️', desc: 'BMR, TDEE, macronutrients, 1RM, and running pace calculators.',
    subcategories: [
      { slug: 'body-energy', name: 'Body & Energy Metrics' },
      { slug: 'workout-performance', name: 'Workout & Performance Tools' },
    ]
  },
  { slug: 'design-tools', accent: 'purple', short: 'Design', name: 'Design & Typography Tools', icon: '🎨', desc: 'Type scales, aspect ratios, box shadows, and CSS gradients.',
    subcategories: [
      { slug: 'typography-layout', name: 'Typography & Layout' },
      { slug: 'css-graphics', name: 'CSS & Graphics' },
    ]
  },
  { slug: 'math-unit-tools', accent: 'blue', short: 'Math & Unit', name: 'Math & Unit Conversion Tools', icon: '📐', desc: 'Physical units, data storage, geometry, and statistical analysis.',
    subcategories: [
      { slug: 'unit-converters', name: 'Physical & Data Unit Converters' },
      { slug: 'geometry-statistics', name: 'Geometry & Statistics' },
    ]
  },
  { slug: 'lifestyle-travel-tools', accent: 'pink', short: 'Lifestyle', name: 'Lifestyle & Travel Tools', icon: '✈️', desc: 'Travel packing lists, road trip fuel costs, reading time, and water hydration.',
    subcategories: [
      { slug: 'trip-travel', name: 'Trip & Travel Planning' },
      { slug: 'everyday-utilities', name: 'Everyday Utilities' },
    ]
  },
  { slug: 'communication-tools', accent: 'teal', short: 'Communication', name: 'Communication Tools', icon: '💬', desc: 'Message length analyzers, formatting tools, and conversation planners.',
    subcategories: [
      { slug: 'message-utilities', name: 'Message Utilities' },
      { slug: 'communication-planning', name: 'Communication Planning' },
    ]
  },
  { slug: 'audio-sound-tools', accent: 'purple', short: 'Audio & Sound', name: 'Audio & Sound Tools', icon: '🔊', desc: 'Audio duration, file size estimation, decibel references, and frequency converters.',
    subcategories: [
      { slug: 'audio-utilities', name: 'Audio Utilities' },
      { slug: 'sound-analysis', name: 'Sound Analysis' },
    ]
  },
  { slug: 'music-tools', accent: 'purple', short: 'Music', name: 'Music Tools', icon: '🎵', desc: 'BPM converters, note frequencies, chord progression generators, and web metronome.',
    subcategories: [
      { slug: 'music-theory', name: 'Music Theory' },
      { slug: 'practice-composition', name: 'Practice & Composition' },
    ]
  },
  { slug: 'pet-care-tools', accent: 'pink', short: 'Pet Care', name: 'Pet Care Tools', icon: '🐾', desc: 'Pet feeding schedules, expense trackers, human age converters, and medication planners.',
    subcategories: [
      { slug: 'pet-planning', name: 'Pet Planning' },
      { slug: 'pet-information', name: 'Pet Information' },
    ]
  },
  { slug: 'automotive-tools', accent: 'orange', short: 'Automotive', name: 'Automotive Tools', icon: '🚗', desc: 'Car depreciation, ownership costs, tire size comparison, and maintenance planners.',
    subcategories: [
      { slug: 'vehicle-costs', name: 'Vehicle Costs' },
      { slug: 'vehicle-planning', name: 'Vehicle Planning' },
    ]
  },
  { slug: 'accessibility-tools', accent: 'teal', short: 'Accessibility', name: 'Accessibility Tools', icon: '♿', desc: 'WCAG contrast checkers, color blindness simulators, font size & line spacing calculators.',
    subcategories: [
      { slug: 'visual-accessibility', name: 'Visual Accessibility' },
      { slug: 'text-accessibility', name: 'Text Accessibility' },
    ]
  },
  { slug: 'science-measurement-tools', accent: 'indigo', short: 'Science', name: 'Science & Measurement Tools', icon: '🧪', desc: 'Ohm\'s law, force, scientific notation, and significant figures calculators.',
    subcategories: [
      { slug: 'physics-utilities', name: 'Physics Utilities' },
      { slug: 'scientific-measurement', name: 'Scientific Measurement' },
    ]
  },
  { slug: 'astronomy-space-tools', accent: 'indigo', short: 'Astronomy', name: 'Astronomy & Space Tools', icon: '🚀', desc: 'Light-year converters, weight on planets, planetary size comparisons, and moon phase calculators.',
    subcategories: [
      { slug: 'space-calculators', name: 'Space Calculators' },
      { slug: 'astronomy-utilities', name: 'Astronomy Utilities' },
    ]
  },
  { slug: 'privacy-safety-tools', accent: 'green', short: 'Privacy & Safety', name: 'Privacy & Digital Safety Tools', icon: '🛡️', desc: 'Password entropy analyzers, personal data exposure checklists, and digital privacy audits.',
    subcategories: [
      { slug: 'privacy-utilities', name: 'Privacy Utilities' },
      { slug: 'digital-safety', name: 'Digital Safety' },
    ]
  },
  { slug: 'geography-maps-tools', accent: 'blue', short: 'Geography', name: 'Geography & Maps Tools', icon: '🗺️', desc: 'Lat/long converters, coordinate distance calculators, solar time calculators, and country area comparisons.',
    subcategories: [
      { slug: 'geographic-calculations', name: 'Geographic Calculations' },
      { slug: 'location-planning', name: 'Location Planning' },
    ]
  },
  { slug: 'gardening-tools', accent: 'green', short: 'Gardening', name: 'Gardening Tools', icon: '🌱', desc: 'Watering schedules, soil pH adjustment, seed starting dates, and garden bed layout planning.',
    subcategories: [
      { slug: 'plant-care', name: 'Plant Care' },
      { slug: 'garden-planning', name: 'Garden Planning' },
    ]
  },
  { slug: 'photography-tools', accent: 'purple', short: 'Photography', name: 'Photography Tools', icon: '📷', desc: 'Exposure triangle, depth of field, golden hour, and print size calculators.',
    subcategories: [
      { slug: 'camera-settings', name: 'Camera Settings' },
      { slug: 'photo-planning', name: 'Photo Planning' },
    ]
  },
  { slug: 'home-maintenance-tools', accent: 'orange', short: 'Home Maintenance', name: 'Home Maintenance Tools', icon: '🏠', desc: 'Paint coverage, wallpaper, HVAC filter reminders, and seasonal maintenance checklists.',
    subcategories: [
      { slug: 'home-projects', name: 'Home Projects' },
      { slug: 'maintenance-schedules', name: 'Maintenance Schedules' },
    ]
  },
  { slug: 'electronics-tools', accent: 'blue', short: 'Electronics', name: 'Electronics Tools', icon: '🔌', desc: 'Resistor color codes, voltage dividers, battery life, and wire gauge calculators.',
    subcategories: [
      { slug: 'circuit-calculators', name: 'Circuit Calculators' },
      { slug: 'battery-power', name: 'Battery & Power' },
    ]
  },
  { slug: 'parenting-tools', accent: 'pink', short: 'Parenting', name: 'Parenting Tools', icon: '👶', desc: 'Feeding schedules, due date estimates, growth rate tracking, and screen time tracking.',
    subcategories: [
      { slug: 'baby-planning', name: 'Baby Planning' },
      { slug: 'child-development', name: 'Child Development' },
    ]
  },
  { slug: 'events-tools', accent: 'amber', short: 'Events', name: 'Event Planning Tools', icon: '🎉', desc: 'Party budgets, catering quantities, RSVP tracking, and seating chart planning.',
    subcategories: [
      { slug: 'party-planning', name: 'Party Planning' },
      { slug: 'guest-management', name: 'Guest Management' },
    ]
  },
  { slug: 'sewing-crafts-tools', accent: 'pink', short: 'Sewing & Crafts', name: 'Sewing & Crafts Tools', icon: '🧵', desc: 'Fabric yardage, seam allowance, yarn requirements, and craft project cost calculators.',
    subcategories: [
      { slug: 'fabric-measurement', name: 'Fabric Measurement' },
      { slug: 'craft-planning', name: 'Craft Planning' },
    ]
  },
  { slug: 'sports-tools', accent: 'green', short: 'Sports', name: 'Sports Tools', icon: '⚽', desc: 'Shooting percentage tracking, roster rotation planning, bracket generation, and fantasy points.',
    subcategories: [
      { slug: 'performance-tracking', name: 'Performance Tracking' },
      { slug: 'game-planning', name: 'Game Planning' },
    ]
  },
  { slug: 'weather-tools', accent: 'blue', short: 'Weather', name: 'Weather Tools', icon: '🌦️', desc: 'Wind chill, heat index, dew point, and rainwater collection calculators.',
    subcategories: [
      { slug: 'weather-planning', name: 'Weather Planning' },
      { slug: 'climate-utilities', name: 'Climate Utilities' },
    ]
  },
  { slug: 'construction-tools', accent: 'orange', short: 'Construction', name: 'Construction Tools', icon: '🏗️', desc: 'Concrete volume, lumber board feet, roofing squares, and drywall sheet calculators.',
    subcategories: [
      { slug: 'material-estimation', name: 'Material Estimation' },
      { slug: 'project-calculations', name: 'Project Calculations' },
    ]
  },
  { slug: 'interior-design-tools', accent: 'pink', short: 'Interior Design', name: 'Interior Design Tools', icon: '🛋️', desc: 'Furniture layout planning, flooring, rug sizing, and curtain fabric calculators.',
    subcategories: [
      { slug: 'room-planning', name: 'Room Planning' },
      { slug: 'furniture-fitting', name: 'Furniture Fitting' },
    ]
  },
  { slug: 'business-tools', accent: 'indigo', short: 'Business', name: 'Business Operations Tools', icon: '💼', desc: 'Break-even point, profit margin, inventory reorder point, and staff scheduling coverage.',
    subcategories: [
      { slug: 'pricing-costing', name: 'Pricing & Costing' },
      { slug: 'operations-planning', name: 'Operations Planning' },
    ]
  },
  { slug: 'organization-tools', accent: 'teal', short: 'Organization', name: 'Personal Organization Tools', icon: '🗂️', desc: 'Closet decluttering, moving box inventory, file naming, and digital photo organization.',
    subcategories: [
      { slug: 'home-organization', name: 'Home Organization' },
      { slug: 'digital-organization', name: 'Digital Organization' },
    ]
  },
  { slug: 'household-tools', accent: 'amber', short: 'Household', name: 'Household Utilities Tools', icon: '🧹', desc: 'Cleaning schedule rotation, laundry load sizing, home inventory, and pantry stock tracking.',
    subcategories: [
      { slug: 'cleaning-schedules', name: 'Cleaning Schedules' },
      { slug: 'home-inventory', name: 'Home Inventory' },
    ]
  },
  { slug: 'language-tools', accent: 'purple', short: 'Language Learning', name: 'Language Learning Tools', icon: '🗣️', desc: 'Vocabulary growth tracking, flashcard review intervals, study streaks, and immersion hour goals.',
    subcategories: [
      { slug: 'vocabulary-building', name: 'Vocabulary Building' },
      { slug: 'study-tracking', name: 'Study Tracking' },
    ]
  },
  { slug: 'outdoor-tools', accent: 'green', short: 'Outdoor & Camping', name: 'Outdoor & Camping Tools', icon: '🏕️', desc: 'Camping food quantities, tent capacity, backpack weight, and campfire wood calculators.',
    subcategories: [
      { slug: 'trip-prep', name: 'Trip Prep' },
      { slug: 'gear-planning', name: 'Gear Planning' },
    ]
  },
  { slug: 'real-estate-tools', accent: 'indigo', short: 'Real Estate', name: 'Real Estate Investment Tools', icon: '🏘️', desc: 'Cap rate, cash-on-cash return, rent vs buy, cash flow, closing costs, and home equity calculators.' },
  { slug: 'insurance-tools', accent: 'blue', short: 'Insurance', name: 'Insurance Tools', icon: '🛡️', desc: 'Life insurance needs, coverage gaps, deductible tracking, HSA limits, and policy renewal reminders.' },
  { slug: 'retirement-planning-tools', accent: 'teal', short: 'Retirement Planning', name: 'Retirement Planning Tools', icon: '🏖️', desc: 'Social Security estimates, 401(k) match, RMDs, Coast FIRE, and retirement healthcare cost tools.' },
]

export const tools = [
  { cat: 'student-tools', slug: 'gpa-calculator', name: 'GPA/CGPA Calculator', icon: '📊', popular: true, Component: Gpa,
    desc: 'Calculate your semester GPA, and your cumulative CGPA, from grades and credit hours.',
    why: 'Skips the manual credit-weighted maths so you can see where you stand in seconds.',
    steps: ['Enter each course (name is optional).', 'Choose the grade you received or expect.', 'Enter the credit hours.', 'Select Calculate.', 'Read your GPA on a 4.0 scale.'],
    keywords: 'grade point average cgpa semester university college marks' },
  { cat: 'student-tools', slug: 'percentage-calculator', name: 'Percentage Calculator', icon: '％', Component: Percentage,
    desc: 'Find a percentage of a number, what percent one number is of another, or a percent change.',
    why: 'Handy for marks, score improvements and any “how much is that in percent” question.',
    steps: ['Pick the kind of question.', 'Enter the two numbers.', 'Select Calculate.', 'Copy the result if you need it.'],
    keywords: 'percent marks score change increase decrease ratio' },
  { cat: 'developer-tools', slug: 'json-formatter', name: 'JSON Formatter', icon: '{ }', popular: true, Component: Json,
    desc: 'Validate, pretty-print or minify JSON and see exactly where a syntax error is.',
    why: 'Turns unreadable API responses into clean JSON and pinpoints syntax errors quickly.',
    steps: ['Paste your JSON.', 'Choose an indent size.', 'Select Format or Minify.', 'Copy or download the result.'],
    keywords: 'json validator validate pretty print minify beautify api' },
  { cat: 'developer-tools', slug: 'base64-encoder-decoder', name: 'Base64 Encoder/Decoder', icon: '🔤', Component: B64,
    desc: 'Encode text to Base64 or decode it back, with full UTF-8 support.',
    why: 'Lets you inspect tokens, data URIs and encoded config values without extra software.',
    steps: ['Choose Encode or Decode.', 'Paste your text.', 'Select Convert.', 'Copy the output.'],
    keywords: 'base64 encode decode utf-8 text binary' },
  { cat: 'office-tools', slug: 'leave-calculator', name: 'Leave Calculator', icon: '🏖️', Component: Leave,
    desc: "Count working leave days between two dates, skipping weekends and your public holidays, with the calculation explained.",
    why: "Shows exactly how many days a leave request uses before you submit it.",
    steps: ["Pick the first and last day of leave.", "Choose your weekend days.", "Add public holidays (optional) and your balance.", "Select Calculate and read the explanation."],
    keywords: 'vacation holiday time off days working days hr annual leave' },
  { cat: 'marketing-tools', slug: 'utm-builder', name: 'UTM Builder', icon: '🔗', popular: true, Component: Utm,
    desc: 'Add UTM campaign parameters to any URL for clean analytics tracking.',
    why: 'Consistent UTM links let you see which campaign actually drove each visit.',
    steps: ['Enter the destination URL.', 'Fill in source, medium and campaign.', 'Add optional term and content.', 'Select Build link and copy it.'],
    keywords: 'utm campaign tracking link analytics google url source medium' },
  { cat: 'productivity-tools', slug: 'pomodoro-timer', name: 'Pomodoro Timer', icon: '🍅', popular: true, Component: Pomodoro,
    desc: 'Work in focused sessions with timed breaks and a session count.',
    why: 'Short timed sprints make it easier to start and to stop before you burn out.',
    steps: ['Set focus and break minutes.', 'Select Reset to apply them.', 'Select Start and focus.', 'Take the break when the timer switches.'],
    keywords: 'focus timer break study work sprint time management' },
  { cat: 'shopping-tools', slug: 'discount-calculator', name: 'Discount Calculator', icon: '🏷️', popular: true, Component: Discount,
    desc: 'Work out the sale price, savings and final cost including tax.',
    why: 'Shows the real price after the discount so you can compare deals honestly.',
    steps: ['Enter the original price.', 'Enter the discount percent.', 'Optionally add a tax rate.', 'Select Calculate.'],
    keywords: 'sale price percent off savings tax coupon' },
  { cat: 'security-tools', slug: 'password-generator', name: 'Password Generator', icon: '🔑', popular: true, Component: Password,
    desc: 'Create strong random passwords locally with the browser’s secure random generator.',
    why: 'Unique random passwords stop one leaked site from exposing your other accounts.',
    steps: ['Choose a length.', 'Pick the character types.', 'Select Generate.', 'Copy the password into your password manager.'],
    keywords: 'password random secure strong generator credential' },
  { cat: 'security-tools', slug: 'hash-generator', name: 'Hash Generator', icon: '#️⃣', Component: Hash,
    desc: 'Generate SHA-1, SHA-256, SHA-384 or SHA-512 hashes of text using the Web Crypto API.',
    why: 'Verify that text or data matches an expected fingerprint without uploading it anywhere.',
    steps: ['Choose an algorithm.', 'Enter your text.', 'Select Generate hash.', 'Copy the hex digest.'],
    keywords: 'sha256 sha1 sha512 checksum digest hash crypto' },
  { cat: 'student-tools', slug: 'grade-calculator', name: 'Grade Calculator', icon: '📝', popular: true, Component: Grade,
    desc: "Turn marks and total marks into a percentage and letter grade using a visible grading scale.",
    why: "Shows your overall percentage across assessments so you know what grade you are on.",
    steps: ["Enter marks obtained and total marks for each assessment.", "Add more assessments if needed.", "Select Calculate.", "Compare the result with the grading scale shown."],
    keywords: 'marks percentage score letter grade exam result assessment' },
  { cat: 'student-tools', slug: 'attendance-calculator', name: 'Attendance Calculator', icon: '📅', popular: true, Component: Attendance,
    desc: "Find your attendance percentage and how many classes you can miss or must attend to reach a target.",
    why: "Helps you avoid falling below a minimum attendance requirement.",
    steps: ["Enter classes attended and total classes held.", "Set your target percentage.", "Select Calculate.", "Read how many classes you can skip or need to attend."],
    keywords: 'attendance class present absent percentage target bunk' },
  { cat: 'student-tools', slug: 'study-planner', name: 'Study Planner', icon: '📚', Component: Study,
    desc: "Plan study sessions by subject, topic and date, and track what is done.",
    why: "A dated list of sessions makes it easier to spread revision out before exams.",
    steps: ["Enter subject, task and study date.", "Select Add study session.", "Change a status to Done when finished.", "Download the plan as CSV if you want a copy."],
    keywords: 'study revision schedule plan subject task hours' },
  { cat: 'student-tools', slug: 'exam-countdown', name: 'Exam Countdown', icon: '⏳', Component: Exam,
    desc: "Count down the days, hours and minutes to your exams.",
    why: "Seeing exactly how much time is left makes it easier to prioritise revision.",
    steps: ["Enter the exam name.", "Choose the date and time.", "Select Add exam.", "Watch the live countdown."],
    keywords: 'exam test countdown days remaining date timer deadline' },
  { cat: 'student-tools', slug: 'timetable-generator', name: 'Timetable Generator', icon: '🗓️', Component: Timetable,
    desc: "Build a weekly class timetable, check for clashes, then print or download it.",
    why: "A single weekly view of classes and rooms prevents missed lectures and double-booking.",
    steps: ["Choose the day and times.", "Enter the subject and optional room.", "Select Add class.", "Print or download the timetable."],
    keywords: 'weekly schedule classes lecture timetable planner routine' },
  { cat: 'student-tools', slug: 'citation-generator', name: 'Citation Generator', icon: '🔖', Component: Citation,
    desc: "Format website, book and journal citations in APA 7 or MLA 9.",
    why: "Correct citations protect you from plagiarism marks and save formatting time.",
    steps: ["Choose the style and source type.", "Enter authors, title, year and other details.", "Select Generate citation.", "Copy the citation into your bibliography."],
    keywords: 'citation reference apa mla bibliography source cite references' },
  { cat: 'student-tools', slug: 'assignment-planner', name: 'Assignment Planner', icon: '✅', Component: Assignment,
    desc: "Track assignments with subject, deadline, priority and status.",
    why: "Deadlines and priorities in one list show what needs attention first.",
    steps: ["Enter the title and deadline.", "Set the priority.", "Select Add assignment.", "Update the status as you progress."],
    keywords: 'assignment homework deadline priority status due tasks' },
  { cat: 'student-tools', slug: 'flashcard-maker', name: 'Flashcard Maker', icon: '🃏', Component: Flash,
    desc: "Create, edit and review flashcards with shuffled study sessions.",
    why: "Active recall with flashcards is a proven way to memorise terms and facts.",
    steps: ["Write the question and the answer.", "Select Add card; edit or delete cards any time.", "Select Review cards.", "Flip each card and mark Got it or Again."],
    keywords: 'flashcards memorize revision quiz cards recall study' },
  { cat: 'developer-tools', slug: 'json-validator', name: 'JSON Validator', icon: '✔️', Component: JsonVal,
    desc: "Check whether JSON is valid and see the line and column of the first error.",
    why: "Finds syntax errors before they break an API call or config file.",
    steps: ["Paste your JSON.", "Select Validate.", "Read the result or the error position.", "Fix the JSON and validate again."],
    keywords: 'json validate check syntax error lint parse' },
  { cat: 'developer-tools', slug: 'code-formatter', name: 'Code Formatter', icon: '🧹', Component: Fmt,
    desc: "Pretty-print JSON, CSS and HTML with clean indentation.",
    why: "Readable, consistently indented code is easier to review and debug.",
    steps: ["Choose the language.", "Paste your code.", "Select Format.", "Copy or download the result."],
    keywords: 'format beautify prettify indent css html json code' },
  { cat: 'developer-tools', slug: 'regex-tester', name: 'Regex Tester', icon: '🔍', popular: true, Component: Regex,
    desc: "Test a regular expression against text and see matches, positions and capture groups.",
    why: "Lets you check a pattern on real text before you put it in code.",
    steps: ["Enter the pattern and choose flags.", "Paste the test text.", "Select Test.", "Review the highlighted matches and groups."],
    keywords: 'regex regexp regular expression pattern match test' },
  { cat: 'developer-tools', slug: 'url-encoder-decoder', name: 'URL Encoder/Decoder', icon: '🌐', Component: Url,
    desc: "Percent-encode or decode URLs and text locally.",
    why: "Correct encoding keeps special characters from breaking links and query strings.",
    steps: ["Paste text or a URL.", "Choose Encode text, Encode full URL or Decode.", "Copy the output."],
    keywords: 'url encode decode percent escape uri query string' },
  { cat: 'developer-tools', slug: 'minifier', name: 'HTML/CSS/JS Minifier', icon: '📦', Component: Minify,
    desc: "Remove comments and whitespace from HTML, CSS and JavaScript to shrink file size.",
    why: "Smaller files load faster and reduce bandwidth.",
    steps: ["Choose the language.", "Paste your code.", "Select Minify.", "Check the size saved, then copy or download."],
    keywords: 'minify compress html css javascript js minimize size' },
  { cat: 'developer-tools', slug: 'color-converter', name: 'Color Converter', icon: '🎨', Component: Color,
    desc: "Convert colours between HEX, RGB and HSL with a live preview.",
    why: "Design specs and code often use different colour formats; this converts between them.",
    steps: ["Type a HEX, RGB or HSL value or use the picker.", "Select Convert.", "Copy the format you need."],
    keywords: 'color colour hex rgb hsl convert picker css' },
  { cat: 'developer-tools', slug: 'qr-code-generator', name: 'QR Code Generator', icon: '▦', Component: Qr,
    desc: "Generate a QR code for any text or URL and download it as PNG or SVG.",
    why: "Makes links, Wi-Fi details and text scannable from a phone in seconds.",
    steps: ["Enter text or a URL.", "Choose error correction and size.", "Select Generate QR code.", "Download the PNG or SVG."],
    keywords: 'qr code barcode generate link scan' },
  { cat: 'developer-tools', slug: 'timestamp-converter', name: 'Timestamp Converter', icon: '🕒', Component: Ts,
    desc: "Convert Unix timestamps to readable dates and back.",
    why: "Log files and APIs use Unix time; this shows what moment it really is.",
    steps: ["Enter a Unix timestamp, or choose a date.", "Select the conversion button.", "Copy the result."],
    keywords: 'timestamp unix epoch date time convert iso utc' },
  { cat: 'office-tools', slug: 'invoice-generator', name: 'Invoice Generator', icon: '🧾', popular: true, Component: Invoice,
    desc: "Create an itemised invoice with automatic subtotal, discount, tax and total, then print or download it.",
    why: "Produces a clean, correctly totalled invoice without a spreadsheet or paid software.",
    steps: ["Enter your business and customer details.", "Add items with quantity and price.", "Add discount or tax if needed, then select Generate invoice.", "Print, save as PDF or download the HTML."],
    keywords: 'invoice bill receipt billing tax freelancer client payment' },
  { cat: 'office-tools', slug: 'meeting-agenda-maker', name: 'Meeting Agenda Maker', icon: '📋', Component: Agenda,
    desc: "Build a timed meeting agenda with participants and export or print it.",
    why: "A timed agenda keeps meetings focused and finishing on schedule.",
    steps: ["Enter the title, date and participants.", "Add agenda items with minutes and a lead.", "Select Create agenda.", "Copy, download or print it."],
    keywords: 'meeting agenda schedule participants time allocation' },
  { cat: 'office-tools', slug: 'meeting-minutes-generator', name: 'Meeting Minutes Generator', icon: '📝', Component: Minutes,
    desc: "Turn discussion points, decisions and action items into formatted meeting minutes.",
    why: "Clear minutes record who agreed to do what, and by when.",
    steps: ["Enter meeting details and attendees.", "List discussion points and decisions.", "Add action items with a responsible person.", "Select Create minutes and copy, download or print."],
    keywords: 'meeting minutes notes action items decisions attendees record' },
  { cat: 'office-tools', slug: 'task-manager', name: 'Task Manager', icon: '☑️', popular: true, Component: TaskMgr,
    desc: "Add tasks with priority and due date, filter them, mark them complete and keep them saved locally.",
    why: "A single prioritised list shows what to do next and what is overdue.",
    steps: ["Type a task and choose priority and due date.", "Select Add task.", "Tick tasks when done.", "Use the filters to focus."],
    keywords: 'tasks todo to-do list priority due date manager' },
  { cat: 'office-tools', slug: 'business-letter-generator', name: 'Business Letter Generator', icon: '✉️', Component: Letter,
    desc: "Write a properly structured business letter from simple fields and copy or print it.",
    why: "Correct letter layout makes formal correspondence look professional.",
    steps: ["Enter sender and recipient details.", "Add the date, subject and body.", "Choose a closing.", "Select Generate letter and copy it."],
    keywords: 'letter formal business correspondence cover letter template' },
  { cat: 'office-tools', slug: 'email-signature-generator', name: 'Email Signature Generator', icon: '🖋️', Component: Signature,
    desc: "Create a clean HTML email signature with contact details and links, ready to copy.",
    why: "A consistent signature looks professional and gives people your contact details.",
    steps: ["Enter your name, title and contact details.", "Add optional links.", "Select Generate signature.", "Copy the formatted signature or the HTML."],
    keywords: 'email signature html contact card outlook gmail' },
  { cat: 'office-tools', slug: 'timesheet-calculator', name: 'Timesheet Calculator', icon: '⏰', Component: Timesheet,
    desc: "Add start, end and break times per day to get total working hours and optional earnings.",
    why: "Accurate hour totals make payroll and invoicing quick and error-free.",
    steps: ["Enter date, start, end and break for each day.", "Add an hourly rate if you want earnings.", "Select Calculate hours.", "Copy the total or download CSV."],
    keywords: 'timesheet hours work time clock shift overtime payroll' },
  { cat: 'office-tools', slug: 'expense-report-generator', name: 'Expense Report Generator', icon: '💳', Component: Expense,
    desc: "List expenses by date and category, get totals, and print or export the report.",
    why: "A tidy report with category totals speeds up reimbursement.",
    steps: ["Enter the report title and employee name.", "Add each expense with date, category and amount.", "Select Generate report.", "Print, or download CSV or HTML."],
    keywords: 'expense report reimbursement receipts travel claim totals' },
  { cat: 'office-tools', slug: 'document-checklist', name: 'Document Checklist', icon: '📁', Component: DocList,
    desc: "Keep a checklist of required documents that you can tick off, reset and reuse.",
    why: "Prevents missing paperwork for applications, audits and onboarding.",
    steps: ["Type a document and select Add document.", "Tick items as you gather them.", "Use Reset to uncheck all and start again."],
    keywords: 'checklist documents paperwork requirements list visa application' },
  { cat: 'marketing-tools', slug: 'keyword-generator', name: 'Keyword Generator', icon: '🔑', popular: true, Component: Keywords,
    desc: "Turn a seed keyword into grouped keyword ideas using common search patterns (no search-volume data).",
    why: "Gives you a starting list of angles to research and write about.",
    steps: ["Enter a seed keyword.", "Add audiences or places if you like.", "Select Generate keyword ideas.", "Copy or download the list, then check it in a research tool."],
    keywords: 'keyword ideas seo long tail research questions search terms' },
  { cat: 'marketing-tools', slug: 'meta-tag-generator', name: 'Meta Tag Generator', icon: '🏷️', Component: Meta,
    desc: "Generate title, description, robots, canonical and Open Graph tags as copyable HTML.",
    why: "Correct meta tags control how your page appears in search and when shared.",
    steps: ["Enter the title and description.", "Add URL, image and site name if you have them.", "Select Generate meta tags.", "Copy the HTML into your page head."],
    keywords: 'meta tags open graph og twitter card seo head canonical robots' },
  { cat: 'marketing-tools', slug: 'hashtag-generator', name: 'Hashtag Generator', icon: '#️⃣', Component: Hashtag,
    desc: "Create hashtag ideas from your own topics, with platform guidance (not live trending data).",
    why: "Saves time brainstorming relevant hashtags for a post.",
    steps: ["Enter topics or keywords.", "Choose how many hashtags and the platform.", "Select Generate hashtags.", "Copy the ones you want."],
    keywords: 'hashtags instagram tiktok social media tags ideas' },
  { cat: 'marketing-tools', slug: 'social-media-caption-generator', name: 'Social Media Caption Generator', icon: '💬', Component: Caption,
    desc: "Get caption drafts for Instagram, LinkedIn, X, Facebook or TikTok in your chosen tone (template-based, no AI service).",
    why: "Gives you a solid first draft so you can post faster.",
    steps: ["Enter your topic.", "Pick platform and tone.", "Add keywords or your own call to action.", "Select Generate captions and edit your favourite."],
    keywords: 'caption social media post instagram linkedin tone copywriting' },
  { cat: 'marketing-tools', slug: 'seo-title-generator', name: 'SEO Title Generator', icon: '📰', popular: true, Component: SeoTitle,
    desc: "Generate several title ideas for a topic, with character counts and truncation guidance.",
    why: "A clear title of the right length improves how your page shows in results.",
    steps: ["Enter a topic or keyword.", "Choose topic or action type.", "Select Generate titles.", "Copy a title and refine it."],
    keywords: 'seo title headline blog title tag generator page title' },
  { cat: 'marketing-tools', slug: 'seo-description-generator', name: 'SEO Description Generator', icon: '📄', Component: SeoDesc,
    desc: "Generate meta description drafts with length guidance for the 120–160 character range.",
    why: "A good description can improve clicks from search results.",
    steps: ["Enter the topic and optional audience and benefit.", "Choose a call to action.", "Select Generate descriptions.", "Copy one and adjust it to match your page."],
    keywords: 'seo meta description snippet search result description generator' },
  { cat: 'marketing-tools', slug: 'content-calendar', name: 'Content Calendar', icon: '🗓️', Component: Calendar,
    desc: "Plan content ideas by date, platform, type and status, saved locally.",
    why: "A dated plan keeps posting consistent and shows what is still in draft.",
    steps: ["Enter the idea, date, platform and type.", "Select Add content item.", "Update the status as work progresses.", "Download CSV to share."],
    keywords: 'content calendar social media schedule editorial plan posts' },
  { cat: 'marketing-tools', slug: 'serp-preview', name: 'SERP Preview', icon: '🔎', Component: Serp,
    desc: "Preview how a title, URL and description may look in search results, with length guidance (estimate, not live data).",
    why: "Lets you check truncation before you publish.",
    steps: ["Enter the title, URL and description.", "Toggle mobile preview if needed.", "Read the length guidance and adjust."],
    keywords: 'serp preview google search result snippet title description truncation' },
  { cat: 'marketing-tools', slug: 'marketing-roi-calculator', name: 'Marketing ROI Calculator', icon: '📈', Component: Roi,
    desc: "Calculate ROI, net profit and ROAS from marketing cost, revenue and extra expenses, with the formula shown.",
    why: "Shows whether a campaign paid for itself.",
    steps: ["Enter marketing cost and revenue.", "Add extra expenses if any.", "Select Calculate ROI.", "Read the result and the formula."],
    keywords: 'roi return on investment roas campaign profit marketing spend' },
  // ---- Batch 3: Productivity ----
  { cat: 'productivity-tools', slug: 'habit-tracker', name: 'Habit Tracker', icon: '🔁', Component: Habit,
    desc: 'Track daily habits, see your current and best streaks, and check how consistent you were over the last 30 days.',
    why: 'Seeing an unbroken streak is a simple, proven way to keep a new routine going.',
    steps: ['Type a habit and select Add habit.', 'Tap a day to mark it done (tap again to undo).', 'Check your streaks and 30-day completion.', 'Copy the summary if you want to share progress.'],
    keywords: 'habit streak routine daily tracker goals consistency check-in' },
  { cat: 'productivity-tools', slug: 'to-do-list', name: 'To-Do List', icon: '📌', Component: Todo,
    desc: 'A simple to-do list that saves in your browser: add tasks, tick them off, and clear what is finished.',
    why: 'Getting tasks out of your head and onto a list makes it easier to focus on one thing at a time.',
    steps: ['Type a task and select Add task.', 'Tick a task when it is done.', 'Remove tasks you no longer need.', 'Use Reset to uncheck everything or Clear list to start over.'],
    keywords: 'todo to-do task list checklist tasks reminders things to do' },
  { cat: 'productivity-tools', slug: 'daily-planner', name: 'Daily Planner', icon: '🌅', Component: DailyPlan,
    desc: 'Plan any day with timed tasks and notes, tick items off, and copy, download or print the day’s plan.',
    why: 'A written plan for the day helps you spend your time on purpose instead of reacting.',
    steps: ['Pick a date.', 'Add tasks with an optional time.', 'Tick tasks as you finish them and add notes.', 'Copy, download or print the plan.'],
    keywords: 'daily planner day schedule agenda plan today appointments time blocking' },
  { cat: 'productivity-tools', slug: 'weekly-planner', name: 'Weekly Planner', icon: '📆', Component: WeeklyPlan,
    desc: 'Lay out your week day by day with weekly goals, choose Monday or Sunday as the first day, then copy, download or print it.',
    why: 'A week view shows how busy each day is and helps you spread work sensibly.',
    steps: ['Choose which day your week starts on.', 'Write your goals for the week.', 'Add tasks for each day, one per line.', 'Copy, download or print the plan.'],
    keywords: 'weekly planner week schedule plan goals calendar agenda' },
  { cat: 'productivity-tools', slug: 'time-zone-converter', name: 'Time Zone Converter', icon: '🌍', Component: TzConv,
    desc: 'Convert a date and time from one time zone to several others, with daylight saving handled by your browser’s time-zone data.',
    why: 'Makes it easy to schedule calls and deadlines across countries without mental arithmetic.',
    steps: ['Enter the date and time.', 'Choose the zone you are converting from.', 'Add the zones you want to see.', 'Copy the result to share.'],
    keywords: 'time zone timezone converter meeting utc gmt world time convert offset dst' },
  { cat: 'productivity-tools', slug: 'world-clock', name: 'World Clock', icon: '🕰️', Component: WorldClock,
    desc: 'See the current time in several cities at once, with dates and UTC offsets, ticking live from your device clock.',
    why: 'A glance tells you whether it is a good time to call a colleague, friend or client abroad.',
    steps: ['Filter and choose a city or time zone.', 'Select Add clock.', 'Switch between 12-hour and 24-hour time.', 'Remove clocks you do not need.'],
    keywords: 'world clock time zones cities current time utc local time' },
  { cat: 'productivity-tools', slug: 'countdown-timer', name: 'Countdown Timer', icon: '⌛', Component: Countdown,
    desc: 'Count down from any time up to 99 hours, with presets, pause and resume, and an optional sound when time is up.',
    why: 'Handy for cooking, breaks, workouts, presentations and any time-boxed task.',
    steps: ['Enter hours, minutes and seconds, or pick a preset.', 'Select Start.', 'Pause and resume if needed.', 'Reset to set a new time.'],
    keywords: 'countdown timer stopwatch alarm minutes seconds cooking break kitchen timer' },
  { cat: 'productivity-tools', slug: 'random-decision-maker', name: 'Random Decision Maker', icon: '🎲', Component: Decision,
    desc: 'Type your options and let a secure random pick choose one, or shuffle them into a random order.',
    why: 'Removes decision fatigue for small choices like where to eat or who goes first.',
    steps: ['Enter one option per line (at least two).', 'Select Pick one, or shuffle into a random order.', 'Optionally remove the winner from the list.', 'Copy the result.'],
    keywords: 'random decision maker picker choose wheel choice coin flip shuffle draw lottery' },
  { cat: 'productivity-tools', slug: 'random-number-generator', name: 'Random Number Generator', icon: '🔢', Component: RandNum,
    desc: 'Generate one or many random whole numbers or decimals in a range, with optional no-repeat and sorting.',
    why: 'Useful for games, sampling, giveaways, test data and quick draws.',
    steps: ['Enter the minimum and maximum.', 'Choose how many numbers and how many decimals.', 'Tick No repeats or Sort if needed.', 'Select Generate, then copy or download.'],
    keywords: 'random number generator rng dice range integer decimal unique lottery draw' },

  // ---- Batch 3: Shopping ----
  { cat: 'shopping-tools', slug: 'shopping-list-maker', name: 'Shopping List Maker', icon: '🛍️', Component: ShopList,
    desc: 'Build a shopping list grouped by aisle, tick items off in the store, and total your estimated cost.',
    why: 'A grouped list saves trips back down the aisles and stops impulse buys.',
    steps: ['Enter an item, quantity and category.', 'Add an estimated price if you want a total.', 'Tick items as you buy them.', 'Copy, download or print the list.'],
    keywords: 'shopping list grocery groceries checklist supermarket items buy' },
  { cat: 'shopping-tools', slug: 'price-comparison-calculator', name: 'Price Comparison Calculator', icon: '⚖️', Component: PriceCmp,
    desc: 'Compare the true final cost of the same item from different sellers, including discounts, tax and shipping.',
    why: 'The lowest sticker price is not always the cheapest once delivery and tax are added.',
    steps: ['Enter each store’s price, discount and shipping.', 'Add a sales tax rate if it applies.', 'Select Compare prices.', 'See the cheapest option and how much the others cost extra.'],
    keywords: 'price comparison compare prices cheapest deal shipping delivery store online best price' },
  { cat: 'shopping-tools', slug: 'sales-tax-calculator', name: 'Sales Tax Calculator', icon: '🧮', Component: SalesTax,
    desc: 'Add sales tax (or VAT/GST) to a price, or take it out of a price that already includes tax.',
    why: 'Shows the real price at the till and how much of a receipt total is tax.',
    steps: ['Choose add tax or remove tax.', 'Enter the price and your tax rate.', 'Select Calculate.', 'Copy the result if needed.'],
    keywords: 'sales tax vat gst calculator add tax remove tax inclusive exclusive price receipt' },
  { cat: 'shopping-tools', slug: 'tip-calculator', name: 'Tip Calculator', icon: '💵', Component: Tip,
    desc: 'Work out the tip and total for a bill, and each person’s share, with optional rounding up.',
    why: 'Takes the awkward maths out of paying at a restaurant.',
    steps: ['Enter the bill and tip percentage.', 'Enter how many people are paying.', 'Choose whether to round each share up.', 'Select Calculate.'],
    keywords: 'tip calculator gratuity restaurant bill percent service charge dining' },
  { cat: 'shopping-tools', slug: 'split-bill-calculator', name: 'Split Bill Calculator', icon: '🍽️', Component: SplitBill,
    desc: 'Split a bill equally, or by what each person ordered, with shared dishes, tax and tip divided fairly.',
    why: 'Keeps group meals fair when people ordered very different amounts.',
    steps: ['Choose an equal split or split by order.', 'Enter the amounts, plus shared items, tax and tip.', 'Select Calculate.', 'Copy or print what each person owes.'],
    keywords: 'split bill divide share group dinner friends who owes each person restaurant' },
  { cat: 'shopping-tools', slug: 'unit-price-calculator', name: 'Unit Price Calculator', icon: '📏', Component: UnitPrice,
    desc: 'Compare products of different sizes by price per 100 g, per 100 ml or per item, converting kg, lb, oz, litres and more.',
    why: 'The bigger pack is not always cheaper per unit, and this shows which one really is.',
    steps: ['Enter each product’s price and size.', 'Pick the unit for each product.', 'Select Compare unit prices.', 'Look for the Best value row in each group.'],
    keywords: 'unit price per kg per litre per 100g compare size pack best value grocery weight volume' },
  { cat: 'shopping-tools', slug: 'shopping-budget-calculator', name: 'Shopping Budget Calculator', icon: '💰', Component: ShopBudget,
    desc: 'Check planned purchases against your budget, split into needs and wants, and see which wants still fit.',
    why: 'Helps you decide before you buy, so you stay within budget.',
    steps: ['Enter your total budget.', 'List items with price, quantity and need or want.', 'Select Calculate.', 'See what is left and which wants fit.'],
    keywords: 'shopping budget calculator spending plan needs wants purchases afford limit' },
  { cat: 'shopping-tools', slug: 'gift-budget-planner', name: 'Gift Budget Planner', icon: '🎁', Component: GiftBudget,
    desc: 'Plan gift spending for each person and occasion, track what you have spent, and see what is left.',
    why: 'Keeps holiday and birthday spending under control and avoids last-minute overspending.',
    steps: ['Enter your total gift budget.', 'Add each recipient with a planned amount.', 'Update “spent so far” as you buy.', 'Select Calculate, then copy, download or print.'],
    keywords: 'gift budget planner presents birthday holiday christmas eid wedding spending recipients' },
  { cat: 'shopping-tools', slug: 'grocery-budget-planner', name: 'Grocery Budget Planner', icon: '🥕', Component: GroceryBudget,
    desc: 'Set a weekly, fortnightly or monthly grocery budget, plan it by category, and track spending as you shop.',
    why: 'Shows which food categories are running over before the month is out.',
    steps: ['Choose a budget period and enter your budget.', 'Enter planned amounts per category.', 'Update “spent so far” as you shop.', 'Select Calculate to see what is left.'],
    keywords: 'grocery budget planner food weekly monthly supermarket spending categories meal' },

  // ---- New Batch: Finance ----
  { cat: 'finance-tools', subcat: 'loan-debt', subcatName: 'Loan & Debt Calculators', slug: 'mortgage-emi-calculator', name: 'Mortgage & EMI Calculator', icon: '🏠', popular: true, Component: MortgageEmi,
    desc: 'Calculate monthly mortgage or loan EMI payments, interest breakdown, and payment schedules.',
    why: 'Shows your exact monthly loan commitments and principal vs interest split.',
    steps: ['Enter total loan amount.', 'Specify annual interest rate %.', 'Choose loan term in years.', 'Add monthly taxes or insurance if applicable.', 'Copy or download your loan summary.'],
    keywords: 'mortgage emi loan principal interest monthly payment schedule debt house home bank' },

  { cat: 'finance-tools', subcat: 'loan-debt', subcatName: 'Loan & Debt Calculators', slug: 'loan-payoff-calculator', name: 'Loan Payoff & Extra Payment Calculator', icon: '💸', Component: LoanPayoff,
    desc: 'Calculate how extra monthly payments reduce debt payoff duration and save total interest.',
    why: 'Demonstrates how small extra monthly contributions shorten debt timelines by years.',
    steps: ['Enter current loan balance.', 'Input interest rate.', 'Enter standard monthly payment.', 'Specify extra monthly contribution.', 'Compare standard vs accelerated timeline.'],
    keywords: 'loan payoff extra payment debt payoff interest saved mortgage car loan credit card debt' },

  { cat: 'finance-tools', subcat: 'investment-savings', subcatName: 'Investment & Savings Tools', slug: 'compound-interest-calculator', name: 'Compound Interest Calculator', icon: '📈', popular: true, Component: CompoundInterest,
    desc: 'Project wealth accumulation over time with compounding interest and regular contributions.',
    why: 'Helps visualize how long-term compounding turns consistent savings into wealth.',
    steps: ['Enter initial investment amount.', 'Specify monthly deposit.', 'Set annual interest rate %.', 'Choose investment horizon years.', 'View year-by-year balance growth.'],
    keywords: 'compound interest savings investment wealth future value compounding interest rate portfolio' },

  { cat: 'finance-tools', subcat: 'investment-savings', subcatName: 'Investment & Savings Tools', slug: 'sip-calculator', name: 'SIP & Mutual Fund Returns Calculator', icon: '📊', Component: SipCalc,
    desc: 'Calculate expected returns for Systematic Investment Plans (SIP) or lump sum mutual fund investments.',
    why: 'Gives clarity on future maturity value for monthly investments.',
    steps: ['Select SIP or Lump Sum mode.', 'Enter investment amount.', 'Set expected annual return rate.', 'Choose investment duration in years.', 'Review total invested vs returns.'],
    keywords: 'sip mutual fund returns systematic investment plan lump sum wealth growth stock market' },

  // ---- New Batch: Fitness ----
  { cat: 'fitness-tools', subcat: 'body-energy', subcatName: 'Body & Energy Metrics', slug: 'bmr-tdee-calculator', name: 'BMR & TDEE Calculator', icon: '🔥', popular: true, Component: BmrTdee,
    desc: 'Calculate Basal Metabolic Rate and Total Daily Energy Expenditure for weight goals.',
    why: 'Provides the exact daily calorie target needed to lose, maintain, or gain weight.',
    steps: ['Select unit system (metric/imperial).', 'Enter age, sex, weight, and height.', 'Choose activity level.', 'Read BMR and TDEE calorie targets.', 'Check loss and gain goals.'],
    keywords: 'bmr tdee calories metabolic rate weight loss deficit bulk maintenance energy' },

  { cat: 'fitness-tools', subcat: 'body-energy', subcatName: 'Body & Energy Metrics', slug: 'macro-calculator', name: 'Macro Nutrient Calculator', icon: '🥗', Component: MacroCalc,
    desc: 'Calculate daily protein, carbohydrate, and fat gram targets for your diet and fitness goal.',
    why: 'Converts daily calories into actionable gram targets for every meal.',
    steps: ['Enter total daily target calories.', 'Select fitness goal (cut, maintain, bulk).', 'Choose diet preset (balanced, high protein, keto).', 'Set meals per day.', 'Review per-meal targets.'],
    keywords: 'macros macronutrients protein carbs fats nutrition diet meal plan keto high protein' },

  { cat: 'fitness-tools', subcat: 'workout-performance', subcatName: 'Workout & Performance Tools', slug: 'one-rep-max-calculator', name: 'One-Rep Max (1RM) Calculator', icon: '🏋️', Component: OneRepMax,
    desc: 'Estimate your 1RM for bench press, squat, or deadlift and generate training percentages.',
    why: 'Lets you find maximum strength without risking injury on true max attempts.',
    steps: ['Enter weight lifted.', 'Enter reps completed (1-12).', 'Select unit (kg or lbs).', 'View estimated 1RM.', 'Use percentage matrix for training loads.'],
    keywords: '1rm one rep max bench squat deadlift lifting powerlifting strength weights workout' },

  { cat: 'fitness-tools', subcat: 'workout-performance', subcatName: 'Workout & Performance Tools', slug: 'pace-calculator', name: 'Pace & Race Time Calculator', icon: '🏃', Component: PaceCalc,
    desc: 'Calculate running pace per km or mile and project finish times for 5k, 10k, and marathon.',
    why: 'Helps runners set realistic race day pacing strategies.',
    steps: ['Enter total distance or pick a race preset.', 'Input target hours, minutes, and seconds.', 'Read pace per km and mile.', 'View projected race finish times.'],
    keywords: 'running pace race time 5k 10k marathon half marathon km mile split times jog' },

  // ---- New Batch: Design ----
  { cat: 'design-tools', subcat: 'typography-layout', subcatName: 'Typography & Layout', slug: 'type-scale-generator', name: 'Modular Type Scale Generator', icon: '🔤', Component: TypeScale,
    desc: 'Generate harmonic modular typography scales with px and rem values for UI design.',
    why: 'Ensures consistent typographic hierarchy across web screens.',
    steps: ['Set base font size in pixels.', 'Choose modular ratio preset (e.g. Major Third, Golden Ratio).', 'Preview text hierarchy.', 'Copy CSS custom properties.'],
    keywords: 'type scale typography font size rem px modular ratio css variables heading hierarchy' },

  { cat: 'design-tools', subcat: 'typography-layout', subcatName: 'Typography & Layout', slug: 'aspect-ratio-calculator', name: 'Aspect Ratio Calculator', icon: '📐', Component: AspectRatio,
    desc: 'Calculate target width or height preserving aspect ratio and generate CSS code.',
    why: 'Prevents distorted images and responsive canvas layout issues.',
    steps: ['Choose a preset (16:9, 4:3, 1:1) or enter custom ratio.', 'Set target width or height in pixels.', 'View simplified ratio and canvas preview.', 'Copy CSS code.'],
    keywords: 'aspect ratio resolution dimension 16:9 4:3 video image scaling canvas CSS' },

  { cat: 'design-tools', subcat: 'css-graphics', subcatName: 'CSS & Graphics', slug: 'box-shadow-generator', name: 'CSS Box Shadow Generator', icon: '🖼️', popular: true, Component: BoxShadow,
    desc: 'Design multi-layered CSS box shadows with blur, spread, inset, and live canvas preview.',
    why: 'Produces clean, modern elevation shadows without hand-writing RGBA code.',
    steps: ['Adjust horizontal and vertical offsets.', 'Set blur and spread radius.', 'Pick shadow color and opacity.', 'Toggle inset or dark canvas preview.', 'Copy CSS code.'],
    keywords: 'box shadow css drop shadow blur spread elevation box-shadow design generator ui' },

  { cat: 'design-tools', subcat: 'css-graphics', subcatName: 'CSS & Graphics', slug: 'gradient-generator', name: 'CSS Gradient Generator', icon: '🌈', Component: GradientGen,
    desc: 'Create linear and radial CSS gradients with multi-color stops, angles, and live preview.',
    why: 'Builds cross-browser gradient CSS with color picker precision.',
    steps: ['Choose linear or radial gradient.', 'Adjust angle in degrees.', 'Pick colors and stop percentages.', 'Preview gradient canvas.', 'Copy background CSS code.'],
    keywords: 'css gradient linear gradient radial color stop background background-image generator ui' },

  // ---- New Batch: Math & Unit ----
  { cat: 'math-unit-tools', subcat: 'unit-converters', subcatName: 'Physical & Data Unit Converters', slug: 'universal-unit-converter', name: 'Universal Unit Converter', icon: '🔄', popular: true, Component: UnitConv,
    desc: 'Convert length, mass, temperature, speed, area, and volume across metric and imperial units.',
    why: 'Handles everyday unit conversions instantly in your browser.',
    steps: ['Select unit category (Length, Mass, Speed, Area).', 'Enter value.', 'Choose input and output units.', 'Click swap to invert units if needed.', 'Copy conversion result.'],
    keywords: 'unit converter length mass weight speed temperature metric imperial km miles kg lbs' },

  { cat: 'math-unit-tools', subcat: 'unit-converters', subcatName: 'Physical & Data Unit Converters', slug: 'data-storage-converter', name: 'Data Storage & Speed Converter', icon: '💾', Component: DataConv,
    desc: 'Convert data sizes (MB, GB, TB) in decimal/binary standards and estimate file download times.',
    why: 'Eliminates confusion between 1000 vs 1024 data standards and calculates download speed.',
    steps: ['Enter data size and unit.', 'Enter connection speed in Mbps.', 'Read exact byte conversions.', 'Check estimated download duration.'],
    keywords: 'data storage converter mb gb tb gib kib download time speed internet mbps bytes' },

  { cat: 'math-unit-tools', subcat: 'geometry-statistics', subcatName: 'Geometry & Statistics', slug: 'geometry-calculator', name: '2D & 3D Geometry Calculator', icon: '📐', Component: GeometryCalc,
    desc: 'Calculate area, perimeter, surface area, and volume for 2D shapes and 3D solids.',
    why: 'Provides exact geometric calculations and formulas without manual trigonometry.',
    steps: ['Select shape (Circle, Rectangle, Sphere, Cylinder, Prism).', 'Enter dimensions.', 'View area, perimeter, volume, or surface area.', 'Copy calculation report.'],
    keywords: 'geometry area perimeter volume surface area circle sphere cylinder prism triangle' },

  { cat: 'math-unit-tools', subcat: 'geometry-statistics', subcatName: 'Geometry & Statistics', slug: 'statistics-calculator', name: 'Statistics & Variance Calculator', icon: '📊', Component: StatsCalc,
    desc: 'Calculate mean, median, mode, range, standard deviation, and variance for data sets.',
    why: 'Delivers full statistical summary statistics for any list of numbers.',
    steps: ['Paste or enter numbers separated by commas or spaces.', 'View mean, median, and mode.', 'Check sample and population standard deviations.', 'Copy statistical report.'],
    keywords: 'statistics mean median mode standard deviation variance range sum sample data stats' },

  // ---- New Batch: Lifestyle & Travel ----
  { cat: 'lifestyle-travel-tools', subcat: 'trip-travel', subcatName: 'Trip & Travel Planning', slug: 'travel-packing-list-generator', name: 'Travel Packing List Generator', icon: '🧳', popular: true, Component: PackingList,
    desc: 'Generate smart, categorized packing checklists based on trip duration, climate, and purpose.',
    why: 'Prevents forgetting travel essentials like documents, chargers, and weather clothing.',
    steps: ['Enter trip duration in days.', 'Select destination climate.', 'Choose trip purpose (vacation, business, outdoor).', 'Check off items as you pack.', 'Download list.'],
    keywords: 'packing list travel checklist suitcase luggage trip vacation business travel clothes' },

  { cat: 'lifestyle-travel-tools', subcat: 'trip-travel', subcatName: 'Trip & Travel Planning', slug: 'fuel-cost-calculator', name: 'Fuel & Road Trip Calculator', icon: '⛽', Component: FuelCost,
    desc: 'Calculate total gas cost, fuel volume needed, and per-person split for road trips.',
    why: 'Makes splitting road trip gas expenses fair and effortless.',
    steps: ['Enter one-way distance.', 'Specify fuel efficiency (L/100km or MPG).', 'Enter gas price.', 'Set passenger count.', 'Toggle round trip if applicable.'],
    keywords: 'fuel cost road trip gas calculator mileage mpg liters per person split drive distance' },

  { cat: 'lifestyle-travel-tools', subcat: 'everyday-utilities', subcatName: 'Everyday Utilities', slug: 'speech-reading-time-calculator', name: 'Speech & Reading Time Calculator', icon: '⏱️', Component: SpeechTiming,
    desc: 'Estimate speech duration and silent reading time for articles, scripts, and presentations.',
    why: 'Ensures your speeches and presentations fit within allotted time limits.',
    steps: ['Paste text script or article.', 'Adjust target speech pace WPM.', 'View estimated speaking time in minutes & seconds.', 'Check word and character counts.'],
    keywords: 'reading time speech time speaking duration word count wpm script keynote presentation' },

  { cat: 'lifestyle-travel-tools', subcat: 'everyday-utilities', subcatName: 'Everyday Utilities', slug: 'water-intake-calculator', name: 'Water Intake & Hydration Calculator', icon: '💧', Component: WaterIntake,
    desc: 'Calculate daily water intake recommendations based on weight, exercise, and weather, with interactive logging.',
    why: 'Helps maintain healthy daily hydration with a simple glass counter.',
    steps: ['Enter body weight in kg.', 'Input daily exercise minutes.', 'Select environment weather.', 'View daily liters and glass target.', 'Track glasses drank today.'],
    keywords: 'water intake hydration daily water calculator drink glasses health fitness habit' },

  // ---- Batch 5: Communication Tools ----
  { cat: 'communication-tools', subcat: 'message-utilities', subcatName: 'Message Utilities', slug: 'message-length-analyzer', name: 'Message Length Analyzer', icon: '📝', popular: true, Component: MsgLen,
    desc: 'Analyze message character limits, word counts, sentence counts, and reading/speaking duration for social platforms.',
    why: 'Prevents post truncation on X/Twitter, SMS, and LinkedIn.',
    steps: ['Type or paste your message text.', 'View character counts and word statistics.', 'Check character limits across social platforms.', 'Copy or download the report.'],
    keywords: 'message length character count word count twitter sms linkedin post reading time' },

  { cat: 'communication-tools', subcat: 'message-utilities', subcatName: 'Message Utilities', slug: 'message-formatting-helper', name: 'Message Formatting Helper', icon: '🧹', Component: MsgFmt,
    desc: 'Format unformatted text into clean bulleted lists, numbered sequences, paragraph breaks, and Markdown.',
    why: 'Turns raw notes into structured, readable team updates.',
    steps: ['Paste unformatted plain text.', 'Select list formatting style (bullets, numbered, paragraphs).', 'Preview formatted text.', 'Copy or download result.'],
    keywords: 'message format bullets numbered list text formatter clean paragraphs' },

  { cat: 'communication-tools', subcat: 'communication-planning', subcatName: 'Communication Planning', slug: 'conversation-topic-generator', name: 'Conversation Topic Generator', icon: '💡', Component: TopicGen,
    desc: 'Generate engaging conversation starters, networking topics, and follow-up questions for social and work settings.',
    why: 'Removes awkward silence in small talk, networking events, and interviews.',
    steps: ['Select communication situation.', 'Read the primary conversation question.', 'Review suggested follow-up question.', 'Click next topic to shuffle.'],
    keywords: 'conversation topic icebreaker small talk networking interview questions starters' },

  { cat: 'communication-tools', subcat: 'communication-planning', subcatName: 'Communication Planning', slug: 'one-on-one-prep-planner', name: 'One-on-One Meeting Prep Planner', icon: '📋', Component: OneOnOnePrep,
    desc: 'Structure check-in agendas, recent wins, blockers, and career growth topics for 1-on-1 manager/report meetings.',
    why: 'Keeps 1-on-1 check-ins focused and productive.',
    steps: ['Enter partner name and role context.', 'List recent wins and accomplishments.', 'Outline current blockers.', 'Add career growth discussion topics.', 'Copy outline.'],
    keywords: 'one on one meeting prep checkin manager report agenda blockers career growth' },

  // ---- Batch 5: Audio & Sound Tools ----
  { cat: 'audio-sound-tools', subcat: 'audio-utilities', subcatName: 'Audio Utilities', slug: 'audio-duration-calculator', name: 'Audio Duration Calculator', icon: '⏱️', Component: AudioDur,
    desc: 'Calculate total audio duration across multiple playlist tracks, podcast segments, or audio clips.',
    why: 'Accurately sums track lengths for podcast editing and album mastering.',
    steps: ['Add track titles and duration (minutes & seconds).', 'Add or remove tracks as needed.', 'View total hours, minutes, and seconds.', 'Copy duration summary.'],
    keywords: 'audio duration track length playlist podcast editor sum total time sound' },

  { cat: 'audio-sound-tools', subcat: 'audio-utilities', subcatName: 'Audio Utilities', slug: 'audio-file-size-estimator', name: 'Audio File Size Estimator', icon: '💾', Component: AudioSize,
    desc: 'Estimate audio file sizes in MB/GB based on duration, bitrate, sample rate, and format (MP3, WAV, FLAC).',
    why: 'Helps plan storage requirements before exporting large audio projects.',
    steps: ['Select preset or enter audio duration in minutes.', 'Choose format (MP3, WAV, FLAC).', 'Set bitrate or quality level.', 'Read estimated file size in MB.'],
    keywords: 'audio file size bitrate wav mp3 flac storage estimate export sound' },

  { cat: 'audio-sound-tools', subcat: 'sound-analysis', subcatName: 'Sound Analysis', slug: 'decibel-reference-tool', name: 'Decibel Level Reference Tool', icon: '🔊', popular: true, Component: DecibelRef,
    desc: 'Explore decibel (dB SPL) levels and compare real-world sound environments with hearing safety guidelines.',
    why: 'Provides real-world context for sound volume and hearing protection safety.',
    steps: ['Use slider to select a decibel level (0-140 dB).', 'Read real-world sound environment examples.', 'Check OSHA/WHO hearing damage risk assessment.'],
    keywords: 'decibel db spl volume loudness hearing safety reference sound noise' },

  { cat: 'audio-sound-tools', subcat: 'sound-analysis', subcatName: 'Sound Analysis', slug: 'frequency-converter', name: 'Frequency Converter', icon: '〰️', Component: FreqConv,
    desc: 'Convert frequencies between Hz, kHz, MHz, and GHz, and calculate sound wavelength in air.',
    why: 'Essential for audio engineering, acoustic physics, and radio frequency work.',
    steps: ['Enter frequency value.', 'Select input unit (Hz, kHz, MHz, GHz).', 'View equivalent values.', 'Check calculated sound wavelength in air.'],
    keywords: 'frequency converter hz khz mhz ghz wavelength period sound wave' },

  // ---- Batch 5: Music Tools ----
  { cat: 'music-tools', subcat: 'music-theory', subcatName: 'Music Theory', slug: 'bpm-converter', name: 'BPM Converter', icon: '♩', popular: true, Component: BpmConv,
    desc: 'Convert tempo (BPM) into beat interval milliseconds and Hz frequencies for delay and LFO audio sync.',
    why: 'Calculates exact delay times for music production and beat sync.',
    steps: ['Enter song tempo in BPM.', 'View millisecond lengths for 1/4, 1/8, and 1/16 notes.', 'Check dotted and triplet note lengths.', 'Copy delay time matrix.'],
    keywords: 'bpm tempo converter delay time milliseconds lfo sync beat music production' },

  { cat: 'music-tools', subcat: 'music-theory', subcatName: 'Music Theory', slug: 'music-note-frequency-calculator', name: 'Music Note Frequency Calculator', icon: '🎵', Component: NoteFreq,
    desc: 'Calculate exact Hz frequencies of musical notes based on concert pitch tuning (A4 = 440 Hz).',
    why: 'Provides precise pitch frequencies for instrument tuning and synthesizer design.',
    steps: ['Select note name (C through B).', 'Choose octave number (0-8).', 'Adjust concert A4 reference frequency if needed.', 'Read exact note frequency in Hz.'],
    keywords: 'music note frequency hz pitch tuning A4 440 synthesizer scale' },

  { cat: 'music-tools', subcat: 'practice-composition', subcatName: 'Practice & Composition', slug: 'chord-progression-generator', name: 'Chord Progression Generator', icon: '🎸', Component: ChordProg,
    desc: 'Generate harmonic chord progressions by key signature and genre style (Pop, Rock, Jazz, R&B).',
    why: 'Sparks songwriting inspiration with proven chord structures.',
    steps: ['Select root key signature.', 'Choose genre style.', 'Review roman numeral and letter chord charts.', 'Copy progression list.'],
    keywords: 'chord progression songwriting guitar piano pop jazz rock r&b chords' },

  { cat: 'music-tools', subcat: 'practice-composition', subcatName: 'Practice & Composition', slug: 'metronome', name: 'Web Metronome', icon: '⏱️', popular: true, Component: Metronome,
    desc: 'Functional browser metronome with adjustable BPM, time signatures, visual pulse, and audio click.',
    why: 'Provides a clean, reliable timing click for music practice.',
    steps: ['Set target tempo BPM.', 'Choose time signature beats.', 'Click Start Metronome to begin audio/visual pulse.', 'Adjust speed during playback.'],
    keywords: 'metronome bpm tempo click track time signature music practice timing' },

  // ---- Batch 5: Pet Care Tools ----
  { cat: 'pet-care-tools', subcat: 'pet-planning', subcatName: 'Pet Planning', slug: 'pet-feeding-schedule', name: 'Pet Feeding Schedule Generator', icon: '🦴', popular: true, Component: PetFeed,
    desc: 'Generate daily food portion sizes and feeding schedules based on pet weight and life stage.',
    why: 'Ensures correct daily nutrition portions and meal timing for dogs and cats.',
    steps: ['Enter pet name, type, and weight.', 'Select number of meals per day.', 'Read total daily grams and portion per meal.', 'Copy feeding schedule.'],
    keywords: 'pet feeding schedule dog cat portion food weight diet nutrition' },

  { cat: 'pet-care-tools', subcat: 'pet-planning', subcatName: 'Pet Planning', slug: 'pet-expense-tracker', name: 'Pet Expense Tracker', icon: '🐾', Component: PetExp,
    desc: 'Track recurring and one-time pet expenses by category (Food, Vet, Grooming, Toys).',
    why: 'Helps pet owners budget and monitor total pet care costs.',
    steps: ['Enter expense item name, category, and cost.', 'Click Add Expense.', 'Review total cost breakdown.', 'Download or copy report.'],
    keywords: 'pet expense tracker dog cat vet cost grooming budget supplies' },

  { cat: 'pet-care-tools', subcat: 'pet-information', subcatName: 'Pet Information', slug: 'pet-age-converter', name: 'Pet Age Converter', icon: '🐱', Component: PetAge,
    desc: 'Convert dog and cat age in years into equivalent human age based on breed size.',
    why: 'Accurately estimates pet life stages beyond the basic 7-year rule.',
    steps: ['Select pet type and size category.', 'Enter pet age in years.', 'View equivalent human age and life stage.', 'Copy age assessment.'],
    keywords: 'pet age converter dog age cat age human years life stage puppy senior' },

  { cat: 'pet-care-tools', subcat: 'pet-information', subcatName: 'Pet Information', slug: 'pet-medication-schedule', name: 'Pet Medication Schedule Planner', icon: '💊', Component: PetMed,
    desc: 'Create a medication reminder schedule with dosage, timing, and administration notes.',
    why: 'Keeps track of complex pet treatment schedules safely.',
    steps: ['Enter pet name.', 'Add medication name, dosage, time, and instructions.', 'Review master schedule.', 'Download or copy schedule.'],
    keywords: 'pet medication schedule reminder dosage vet treatment schedule log' },

  // ---- Batch 5: Automotive Tools ----
  { cat: 'automotive-tools', subcat: 'vehicle-costs', subcatName: 'Vehicle Costs', slug: 'car-depreciation-calculator', name: 'Car Depreciation Calculator', icon: '📉', popular: true, Component: CarDeprec,
    desc: 'Estimate vehicle value decline and residual value over a 1 to 10 year ownership horizon.',
    why: 'Shows true vehicle depreciation loss before buying or selling a car.',
    steps: ['Enter vehicle purchase price.', 'Select new or pre-owned condition.', 'Choose ownership duration in years.', 'View year-by-year resale value schedule.'],
    keywords: 'car depreciation vehicle value resale trade in loss auto finance' },

  { cat: 'automotive-tools', subcat: 'vehicle-costs', subcatName: 'Vehicle Costs', slug: 'car-ownership-cost-calculator', name: 'Car Ownership Cost Calculator', icon: '🚘', Component: CarOwnerCost,
    desc: 'Estimate total monthly and annual car ownership costs including loan, insurance, fuel, and maintenance.',
    why: 'Calculates the true total monthly cost of owning a vehicle.',
    steps: ['Enter monthly loan, insurance, and fuel costs.', 'Enter annual maintenance and registration expenses.', 'Read total monthly and annual cost.', 'Copy summary.'],
    keywords: 'car ownership cost total cost of ownership auto insurance fuel maintenance monthly bill' },

  { cat: 'automotive-tools', subcat: 'vehicle-planning', subcatName: 'Vehicle Planning', slug: 'tire-size-comparison', name: 'Tire Size Comparison Tool', icon: '🛞', Component: TireCmp,
    desc: 'Compare two tire specifications and calculate overall diameter, sidewall height, and speedometer error.',
    why: 'Prevents speedometer errors and clearance issues when changing wheel/tire sizes.',
    steps: ['Enter stock tire specs (Width/Aspect/Rim).', 'Enter target new tire specs.', 'View diameter difference and percentage change.', 'Check speedometer error at 60 mph.'],
    keywords: 'tire size comparison diameter speedometer error rim wheel sidewall fitment' },

  { cat: 'automotive-tools', subcat: 'vehicle-planning', subcatName: 'Vehicle Planning', slug: 'vehicle-maintenance-planner', name: 'Vehicle Maintenance Cost Planner', icon: '🔧', Component: MaintPlan,
    desc: 'Organize expected automotive maintenance expenses and service intervals into a master plan.',
    why: 'Helps plan preventative vehicle service budgets before unexpected breakdowns.',
    steps: ['Add service item (Oil change, brakes, filters).', 'Specify service interval and estimated cost.', 'Review total planned maintenance budget.', 'Download plan.'],
    keywords: 'vehicle maintenance planner car service oil change brakes budget repairs' },

  // ---- Batch 5: Accessibility Tools ----
  { cat: 'accessibility-tools', subcat: 'visual-accessibility', subcatName: 'Visual Accessibility', slug: 'contrast-ratio-checker', name: 'Contrast Ratio Checker', icon: '👁️', popular: true, Component: ContrastCheck,
    desc: 'Calculate color contrast ratios and evaluate compliance against WCAG 2.1 AA and AAA standards.',
    why: 'Ensures web text is readable for users with low vision or color deficiencies.',
    steps: ['Pick foreground text color and background color.', 'View calculated contrast ratio.', 'Check WCAG AA/AAA pass/fail status for normal & large text.', 'Copy report.'],
    keywords: 'contrast ratio wcag accessibility color contrast aa aaa accessibility checker web design' },

  { cat: 'accessibility-tools', subcat: 'visual-accessibility', subcatName: 'Visual Accessibility', slug: 'color-blindness-simulator', name: 'Color Blindness Simulator', icon: '🎨', Component: ColorBlindSim,
    desc: 'Simulate how palette colors appear under Protanopia, Deuteranopia, Tritanopia, and Achromatopsia.',
    why: 'Helps designers choose accessible color palettes for all visual conditions.',
    steps: ['Select a base color from the picker.', 'View simulated color swatches for red, green, and blue blindness.', 'Copy simulated Hex values.'],
    keywords: 'color blindness simulator protanopia deuteranopia tritanopia accessibility color palette' },

  { cat: 'accessibility-tools', subcat: 'text-accessibility', subcatName: 'Text Accessibility', slug: 'font-size-accessibility-checker', name: 'Font Size Accessibility Checker', icon: '🔤', Component: FontA11yCheck,
    desc: 'Evaluate font sizes in px, rem, and pt against web accessibility legibility guidelines.',
    why: 'Ensures font sizes are sufficiently large and legibly scaled.',
    steps: ['Use slider to set font size in px.', 'View equivalent rem and pt values.', 'Read accessibility rating.', 'Test legibility on live text preview.'],
    keywords: 'font size accessibility rem px pt legibility web design text size' },

  { cat: 'accessibility-tools', subcat: 'text-accessibility', subcatName: 'Text Accessibility', slug: 'line-spacing-calculator', name: 'Line Spacing Calculator', icon: '📐', Component: LineSpacingCalc,
    desc: 'Calculate optimal line-height ratios and paragraph spacing according to WCAG 1.4.12 guidelines.',
    why: 'Prevents text line overlap and improves paragraph readability.',
    steps: ['Enter font size in pixels.', 'Select line-height ratio preset (e.g. 1.5 WCAG recommended).', 'View calculated pixel line-height.', 'Copy CSS typography rules.'],
    keywords: 'line spacing line height calculator wcag text typography paragraph spacing css' },

  // ---- Batch 5: Science & Measurement Tools ----
  { cat: 'science-measurement-tools', subcat: 'physics-utilities', subcatName: 'Physics Utilities', slug: 'ohms-law-calculator', name: "Ohm's Law Calculator", icon: '⚡', popular: true, Component: OhmsLaw,
    desc: "Calculate Voltage (V), Current (I), Resistance (R), or Power (P) in electrical circuits using Ohm's Law.",
    why: 'Solves circuit calculations quickly for electronics and physics.',
    steps: ['Select target parameter to calculate.', 'Enter the two known values.', 'Read calculated parameter and electrical power in Watts.', 'Copy report.'],
    keywords: 'ohms law voltage current resistance power volts amps ohms watts circuit physics' },

  { cat: 'science-measurement-tools', subcat: 'physics-utilities', subcatName: 'Physics Utilities', slug: 'force-calculator', name: 'Force & Acceleration Calculator', icon: '🎯', Component: ForceCalc,
    desc: 'Calculate Force (F = m × a), mass, or acceleration using Newton’s Second Law of Motion.',
    why: 'Calculates physical force in Newtons, pounds-force, and dynes.',
    steps: ['Enter mass in kg.', 'Enter acceleration in m/s².', 'Read force in Newtons (N) and lbf.', 'Copy force calculation.'],
    keywords: 'force calculator newtons acceleration mass f=ma newtonian physics dynamics' },

  { cat: 'science-measurement-tools', subcat: 'scientific-measurement', subcatName: 'Scientific Measurement', slug: 'scientific-notation-converter', name: 'Scientific Notation Converter', icon: '🔢', Component: SciNotation,
    desc: 'Convert standard decimal numbers into scientific notation (a × 10^b), E-notation, and engineering notation.',
    why: 'Formats extremely large or small numbers clearly for science and math.',
    steps: ['Enter decimal or standard number.', 'View scientific notation (a × 10^b).', 'View E-notation and engineering notation.', 'Copy result.'],
    keywords: 'scientific notation converter e-notation engineering notation exponent math science' },

  { cat: 'science-measurement-tools', subcat: 'scientific-measurement', subcatName: 'Scientific Measurement', slug: 'significant-figures-calculator', name: 'Significant Figures Calculator', icon: '📊', Component: SigFigs,
    desc: 'Count significant figures in any number and round values to target sig-fig counts.',
    why: 'Ensures correct scientific precision and sig-fig rules for measurements.',
    steps: ['Enter number.', 'Read counted significant digits.', 'Set target sig-fig rounding count.', 'Copy rounded scientific value.'],
    keywords: 'significant figures sig figs rounding scientific precision measurement math' },

  // ---- Batch 5: Astronomy & Space Tools ----
  { cat: 'astronomy-space-tools', subcat: 'space-calculators', subcatName: 'Space Calculators', slug: 'light-year-converter', name: 'Light-Year Distance Converter', icon: '✨', popular: true, Component: LightYearConv,
    desc: 'Convert light-years into kilometers, miles, Astronomical Units (AU), and parsecs.',
    why: 'Converts immense cosmic distances into relatable scientific units.',
    steps: ['Enter distance in light-years or select cosmic landmark preset.', 'View equivalent kilometers and miles in scientific notation.', 'Check AU and parsecs.'],
    keywords: 'light year distance converter kilometers miles astronomical unit parsec space astronomy' },

  { cat: 'astronomy-space-tools', subcat: 'space-calculators', subcatName: 'Space Calculators', slug: 'weight-on-planets-calculator', name: 'Weight on Other Planets Calculator', icon: '🪐', Component: WeightPlanets,
    desc: 'Calculate how much you would weigh on Mercury, Venus, Mars, Jupiter, Saturn, Uranus, Neptune, and the Moon.',
    why: 'Demonstrates how surface gravity varies across Solar System bodies.',
    steps: ['Enter your weight on Earth.', 'Select weight unit (kg or lbs).', 'Review planetary weight comparison table.', 'Copy weight chart.'],
    keywords: 'weight on planets mars moon jupiter gravity planetary solar system astronomy' },

  { cat: 'astronomy-space-tools', subcat: 'astronomy-utilities', subcatName: 'Astronomy Utilities', slug: 'moon-phase-calculator', name: 'Moon Phase Calculator', icon: '🌕', Component: MoonPhase,
    desc: 'Calculate current or date-specific lunar phases, illumination percentages, and synodic cycle age.',
    why: 'Provides accurate moon phase tracking for stargazing and photography.',
    steps: ['Select calendar date.', 'View phase name and emoji symbol.', 'Check illumination percentage and lunar age in days.', 'Copy report.'],
    keywords: 'moon phase calculator lunar cycle full moon new moon illumination astronomy stargazing' },

  { cat: 'astronomy-space-tools', subcat: 'astronomy-utilities', subcatName: 'Astronomy Utilities', slug: 'planetary-size-comparison', name: 'Planetary Size & Scale Comparison Tool', icon: '🌌', Component: PlanetSize,
    desc: 'Compare diameters, volume ratios, and relative scales of planets in our Solar System.',
    why: 'Visualizes the true relative scale of celestial bodies.',
    steps: ['Select baseline reference planet.', 'Review comparative diameter scaling.', 'Check total volume multiplier relative to Earth.', 'Copy size table.'],
    keywords: 'planetary size comparison planet diameter scale volume solar system astronomy' },

  // ---- Batch 5: Privacy & Digital Safety Tools ----
  { cat: 'privacy-safety-tools', subcat: 'privacy-utilities', subcatName: 'Privacy Utilities', slug: 'password-strength-analyzer', name: 'Password Strength Analyzer', icon: '🛡️', popular: true, Component: PassStrength,
    desc: 'Analyze password entropy, character diversity, and estimated offline brute-force crack time locally.',
    why: 'Evaluates credential security without sending passwords over the internet.',
    steps: ['Type or paste password in the input field.', 'View calculated entropy bits.', 'Read estimated brute-force crack time.', 'Check character criteria rules.'],
    keywords: 'password strength analyzer entropy security brute force crack time credential privacy' },

  { cat: 'privacy-safety-tools', subcat: 'privacy-utilities', subcatName: 'Privacy Utilities', slug: 'personal-data-exposure-checklist', name: 'Personal Data Exposure Checklist', icon: '🔍', Component: DataExpCheck,
    desc: 'Interactive audit checklist to review public profiles, credentials, and device data exposure points.',
    why: 'Helps identify potential personal data leaks before they are exploited.',
    steps: ['Review data exposure audit categories.', 'Check off items as you verify profiles and settings.', 'Track overall audit completion percentage.', 'Download report.'],
    keywords: 'personal data exposure checklist privacy audit security digital footprint OSINT' },

  { cat: 'privacy-safety-tools', subcat: 'digital-safety', subcatName: 'Digital Safety', slug: 'privacy-settings-checklist', name: 'Privacy Settings Checklist', icon: '🔒', Component: PrivSettingsCheck,
    desc: 'Interactive checklist for hardening privacy settings across browsers, social media, and mobile OS.',
    why: 'Guides step-by-step privacy hardening for everyday digital accounts.',
    steps: ['Review browser, social media, and mobile OS privacy items.', 'Tick off verified settings.', 'View progress meter.', 'Download privacy hardening plan.'],
    keywords: 'privacy settings checklist browser security social media privacy mobile OS hardening' },

  { cat: 'privacy-safety-tools', subcat: 'digital-safety', subcatName: 'Digital Safety', slug: 'secure-file-sharing-checklist', name: 'Secure File Sharing Checklist', icon: '📁', Component: FileShareCheck,
    desc: 'Practical checklist for scrubbing metadata, encrypting attachments, and sharing files securely.',
    why: 'Ensures confidential files are safely stripped of metadata before sending.',
    steps: ['Review pre-share preparation and link security steps.', 'Check off completed security steps.', 'Copy or download checklist.'],
    keywords: 'secure file sharing checklist metadata removal encryption privacy digital safety' },

  // ---- Batch 5: Geography & Maps Tools ----
  { cat: 'geography-maps-tools', subcat: 'geographic-calculations', subcatName: 'Geographic Calculations', slug: 'latitude-longitude-converter', name: 'Latitude Longitude Converter', icon: '🌐', popular: true, Component: LatLngConv,
    desc: 'Convert coordinates between Decimal Degrees (DD) and Degrees-Minutes-Seconds (DMS).',
    why: 'Converts map coordinates seamlessly between GPS and classic mapping formats.',
    steps: ['Choose conversion direction (DD → DMS or DMS → DD).', 'Enter latitude and longitude coordinates.', 'Read converted output.', 'Copy coordinates.'],
    keywords: 'latitude longitude converter decimal degrees dms coordinates gps map' },

  { cat: 'geography-maps-tools', subcat: 'geographic-calculations', subcatName: 'Geographic Calculations', slug: 'coordinate-distance-calculator', name: 'Coordinate Distance Calculator', icon: '📏', Component: CoordDist,
    desc: 'Calculate Great-Circle geodesic distance between two latitude/longitude points using the Haversine formula.',
    why: 'Measures straight-line distance across the Earth’s surface in km, miles, and nautical miles.',
    steps: ['Enter point A coordinates (lat/lng) or select preset.', 'Enter point B coordinates.', 'Read geodesic distance in kilometers, miles, and nautical miles.'],
    keywords: 'coordinate distance calculator haversine geodesic distance latitude longitude miles km' },

  { cat: 'geography-maps-tools', subcat: 'location-planning', subcatName: 'Location Planning', slug: 'daylight-solar-calculator', name: 'Daylight Hours & Solar Time Calculator', icon: '☀️', Component: DaylightSolar,
    desc: 'Calculate total daylight duration, approximate sunrise, sunset, and solar noon for any latitude.',
    why: 'Calculates day length and solar solar positions for travel and agriculture.',
    steps: ['Enter latitude location.', 'Select calendar date.', 'View total daylight hours and minutes.', 'Check sunrise and sunset times.'],
    keywords: 'daylight hours solar calculator sunrise sunset day length solar noon latitude geography' },

  { cat: 'geography-maps-tools', subcat: 'location-planning', subcatName: 'Location Planning', slug: 'country-area-comparison', name: 'Country Area Comparison Tool', icon: '🗺️', Component: CountryArea,
    desc: 'Compare total land area in square kilometers and square miles between any two countries.',
    why: 'Provides clear numerical scale comparisons between nations.',
    steps: ['Select first country.', 'Select second country.', 'View relative area multiplier and difference in square km/miles.', 'Copy report.'],
    keywords: 'country area comparison land area square kilometers square miles geography map scale' },

  { cat: 'student-tools', slug: 'word-counter-text-stats', name: 'Word Counter & Text Statistics', icon: '🔤', Component: WordCounter,
    desc: 'Count words, characters, sentences and paragraphs, and estimate reading and speaking time.',
    why: 'Checks your writing against word limits or estimates how long it takes to read or present.',
    steps: ['Paste or type your text.', 'Read the live word, character and sentence counts.', 'Check the estimated reading and speaking time.'],
    keywords: 'word count character count text statistics reading time speaking time essay length' },
  { cat: 'student-tools', slug: 'essay-outline-generator', name: 'Essay Outline Generator', icon: '🧭', Component: EssayOutlineGenerator,
    desc: 'Turn a topic, thesis and body points into a structured essay outline you can fill in.',
    why: 'Gives you a starting structure so you spend your time on arguments, not formatting.',
    steps: ['Enter your topic and thesis.', 'Add body paragraph points.', 'Select Generate outline.', 'Copy or download it.'],
    keywords: 'essay outline structure thesis body paragraph writing plan' },

  { cat: 'developer-tools', slug: 'uuid-generator', name: 'UUID Generator', icon: '🆔', Component: UuidGenerator,
    desc: 'Generate one or many random UUID v4 identifiers, with optional uppercase and hyphen formatting.',
    why: 'Quickly produces unique IDs for test data, database keys or config without leaving the browser.',
    steps: ['Choose how many to generate.', 'Set formatting options.', 'Select Generate.', 'Copy or download the list.'],
    keywords: 'uuid guid unique identifier random generator v4' },
  { cat: 'developer-tools', slug: 'cron-expression-explainer', name: 'Cron Expression Explainer', icon: '⏰', Component: CronExpressionExplainer,
    desc: 'Paste a 5-field cron expression and get a plain-English description of when it runs.',
    why: 'Saves you from misreading a scheduled job and running it at the wrong time.',
    steps: ['Paste your cron expression.', 'Read the plain-English explanation.', 'Adjust the fields until it matches your schedule.'],
    keywords: 'cron expression schedule job crontab explain parse' },
  { cat: 'developer-tools', slug: 'css-unit-converter', name: 'CSS Unit Converter', icon: '📏', Component: CssUnitConverter,
    desc: 'Convert pixel values to rem, em, pt, pc and viewport width based on your root font size.',
    why: 'Keeps CSS sizing consistent when moving between fixed and relative units.',
    steps: ['Enter a value in pixels.', 'Set your root font size.', 'Read the converted values.'],
    keywords: 'css px rem em pt viewport unit convert font size' },
  { cat: 'developer-tools', slug: 'lorem-ipsum-generator', name: 'Lorem Ipsum Generator', icon: '📄', Component: LoremIpsumGenerator,
    desc: 'Generate placeholder paragraphs, sentences or words for mockups and layouts.',
    why: 'Fills a design or prototype with realistic-looking text instantly.',
    steps: ['Choose paragraphs, sentences or words.', 'Set how many.', 'Select Generate.', 'Copy or download the text.'],
    keywords: 'lorem ipsum placeholder text dummy filler mockup' },
  { cat: 'developer-tools', slug: 'http-status-code-lookup', name: 'HTTP Status Code Lookup', icon: '📶', Component: HttpStatusLookup,
    desc: 'Search common HTTP status codes by number or keyword and see what each one means.',
    why: 'A fast reference when debugging an API response or writing error handling.',
    steps: ['Type a status code or keyword.', 'Browse the matching results.'],
    keywords: 'http status code error 404 500 api reference lookup' },

  { cat: 'office-tools', slug: 'out-of-office-message-generator', name: 'Out-of-Office Message Generator', icon: '📧', Component: OutOfOfficeGenerator,
    desc: 'Generate a formal or casual out-of-office email reply with dates and a backup contact.',
    why: 'Produces a polished auto-reply in seconds instead of writing one from scratch.',
    steps: ['Enter your name, reason and dates.', 'Add a backup contact if needed.', 'Choose a tone.', 'Select Generate message and copy it.'],
    keywords: 'out of office auto reply email vacation away message' },
  { cat: 'office-tools', slug: 'salary-breakdown-calculator', name: 'Salary Breakdown Calculator', icon: '💵', Component: SalaryBreakdownCalculator,
    desc: 'Convert an annual, monthly, weekly or hourly salary into all the other pay periods.',
    why: 'Makes it easy to compare job offers quoted in different pay periods.',
    steps: ['Choose the pay period you have.', 'Enter the amount and weekly hours.', 'Select Calculate.'],
    keywords: 'salary pay period hourly monthly annual weekly breakdown wage' },
  { cat: 'office-tools', slug: 'meeting-cost-calculator', name: 'Meeting Cost Calculator', icon: '🧮', Component: MeetingCostCalculator,
    desc: 'Estimate what a meeting costs in salary time based on attendees, average salary and length.',
    why: 'Puts a number on recurring meetings so teams can decide if they are worth the cost.',
    steps: ['Enter attendees, average salary and meeting length.', 'Select Calculate cost.', 'See the per-meeting, weekly and yearly cost.'],
    keywords: 'meeting cost salary time waste productivity calculator' },
  { cat: 'office-tools', slug: 'onboarding-checklist', name: 'Employee Onboarding Checklist', icon: '🗂️', Component: OnboardingChecklist,
    desc: 'Track onboarding tasks for a new hire and check them off as they are completed.',
    why: 'Keeps onboarding steps from being missed during a new employee’s first days.',
    steps: ['Add onboarding tasks.', 'Check each one off as it is done.', 'Clear the list to reuse it for the next hire.'],
    keywords: 'onboarding checklist new hire employee tasks hr' },

  { cat: 'marketing-tools', slug: 'social-media-character-counter', name: 'Social Media Character Counter', icon: '📱', Component: SocialCharacterCounter,
    desc: 'Check your post length against the character limits of major social platforms at once.',
    why: 'Avoids a post getting cut off or rejected for being too long on a given platform.',
    steps: ['Paste your post text.', 'Check the count against each platform’s limit.'],
    keywords: 'character count social media limit twitter instagram linkedin post length' },
  { cat: 'marketing-tools', slug: 'ad-budget-estimator', name: 'Ad Budget & CPC/CPM Estimator', icon: '📊', Component: AdBudgetEstimator,
    desc: 'Estimate clicks, impressions, conversions and cost per conversion from a budget and expected rates.',
    why: 'Turns a raw ad budget into an expected outcome before you spend it.',
    steps: ['Enter budget, expected CPC, CTR and conversion rate.', 'Select Estimate.', 'Review the projected results.'],
    keywords: 'ad budget cpc cpm ctr conversion rate advertising estimate' },

  { cat: 'productivity-tools', slug: 'eisenhower-matrix', name: 'Eisenhower Matrix Task Sorter', icon: '🗳️', Component: EisenhowerMatrix,
    desc: 'Sort tasks into Do first, Schedule, Delegate and Eliminate based on urgency and importance.',
    why: 'A quick way to see what actually deserves your attention today.',
    steps: ['Enter a task.', 'Mark whether it is urgent and/or important.', 'Select Add task.', 'Review the four quadrants.'],
    keywords: 'eisenhower matrix urgent important priority task sort' },
  { cat: 'productivity-tools', slug: 'goal-milestone-tracker', name: 'Goal & Milestone Tracker', icon: '🎯', Component: GoalMilestoneTracker,
    desc: 'Break goals into milestones and track completion percentage for each one.',
    why: 'Large goals feel more achievable once broken into checkable milestones.',
    steps: ['Add a goal.', 'Add milestones under it.', 'Check off milestones as you complete them.'],
    keywords: 'goal tracker milestone progress achievement planning' },

  { cat: 'shopping-tools', slug: 'subscription-cost-tracker', name: 'Subscription Cost Tracker', icon: '📺', Component: SubscriptionCostTracker,
    desc: 'List your recurring subscriptions and see the total monthly and yearly cost.',
    why: 'Small subscriptions add up quietly — this shows the real total.',
    steps: ['Add each subscription with its cost and billing cycle.', 'Review the combined monthly and yearly total.'],
    keywords: 'subscription tracker recurring cost monthly yearly budget' },
  { cat: 'shopping-tools', slug: 'cost-per-use-calculator', name: 'Cost-Per-Use Calculator', icon: '👟', Component: CostPerUseCalculator,
    desc: 'Divide a purchase price by expected uses or days of use to find the true cost per use.',
    why: 'Helps compare a cheap item used rarely against a pricier one used often.',
    steps: ['Enter the purchase price.', 'Enter expected uses or days of use.', 'Select Calculate.'],
    keywords: 'cost per use per wear per day purchase value calculator' },

  { cat: 'security-tools', slug: 'passphrase-generator', name: 'Passphrase Generator', icon: '🔐', Component: PassphraseGenerator,
    desc: 'Generate a memorable multi-word passphrase from a wordlist, with optional numbers.',
    why: 'Long word-based passphrases are easier to remember and type than random character strings.',
    steps: ['Set the number of words and separator.', 'Select Generate passphrase.', 'Copy it into your password manager.'],
    keywords: 'passphrase diceware memorable password word based generator' },
  { cat: 'security-tools', slug: 'pin-generator', name: 'Random PIN Generator', icon: '🔢', Component: PinGenerator,
    desc: 'Generate random numeric PINs of a chosen length, avoiding obvious repeats and runs.',
    why: 'Produces PINs that are harder to guess than birthdays or 1234-style patterns.',
    steps: ['Set the PIN length and how many to generate.', 'Select Generate.', 'Copy the list.'],
    keywords: 'pin generator numeric code random security' },

  { cat: 'finance-tools', subcat: 'loan-debt', subcatName: 'Loan & Debt Calculators', slug: 'debt-payoff-strategy-planner', name: 'Debt Payoff Strategy Planner', icon: '📉', Component: DebtPayoffStrategyPlanner,
    desc: 'Compare the snowball (smallest balance first) and avalanche (highest rate first) payoff strategies across multiple debts.',
    why: 'Shows which order of payoff saves the most interest or clears debts soonest.',
    steps: ['Add each debt with balance, rate and minimum payment.', 'Enter extra monthly payment.', 'Select Compare strategies.'],
    keywords: 'debt payoff snowball avalanche strategy interest payment plan' },
  { cat: 'finance-tools', subcat: 'investment-savings', subcatName: 'Investment & Savings Tools', slug: 'retirement-savings-calculator', name: 'Retirement Savings Goal Calculator', icon: '🏖️', Component: RetirementSavingsCalculator,
    desc: 'Project retirement savings from current balance, monthly contributions, years and expected return.',
    why: 'Shows whether current contributions are on track to meet a retirement goal.',
    steps: ['Enter current savings and monthly contribution.', 'Enter years until retirement and expected return.', 'Select Calculate.'],
    keywords: 'retirement savings goal projection compound investment 401k' },

  { cat: 'fitness-tools', subcat: 'body-energy', subcatName: 'Body & Energy Metrics', slug: 'calorie-burn-estimator', name: 'Calorie Burn Estimator', icon: '🔥', Component: CalorieBurnEstimator,
    desc: 'Estimate calories burned during an activity using standard MET values, weight and duration.',
    why: 'Gives a quick estimate of energy expenditure for common activities.',
    steps: ['Enter your weight.', 'Choose an activity and duration.', 'Select Estimate calories burned.'],
    keywords: 'calorie burn met activity exercise energy expenditure' },
  { cat: 'fitness-tools', subcat: 'workout-performance', subcatName: 'Workout & Performance Tools', slug: 'heart-rate-zone-calculator', name: 'Target Heart Rate Zone Calculator', icon: '❤️', Component: HeartRateZoneCalculator,
    desc: 'Calculate training heart rate zones from age, and optionally resting heart rate using the Karvonen method.',
    why: 'Shows the heart rate ranges for fat burn, aerobic and max-effort training.',
    steps: ['Enter your age.', 'Optionally add resting heart rate.', 'Select Calculate zones.'],
    keywords: 'heart rate zone training max karvonen cardio fitness' },

  { cat: 'design-tools', subcat: 'css-graphics', subcatName: 'CSS & Graphics', slug: 'color-palette-generator', name: 'Color Palette Generator', icon: '🌈', Component: ColorPaletteGenerator,
    desc: 'Generate shades, complementary, analogous and triadic colors from a single base color.',
    why: 'Builds a coordinated color palette from one starting color using color-wheel relationships.',
    steps: ['Pick a base color.', 'Review the generated shades and color relationships.', 'Copy the values you need.'],
    keywords: 'color palette generator shades complementary analogous triadic design' },
  { cat: 'design-tools', subcat: 'css-graphics', subcatName: 'CSS & Graphics', slug: 'border-radius-generator', name: 'CSS Border Radius Generator', icon: '⬜', Component: BorderRadiusGenerator,
    desc: 'Adjust each corner radius with a live preview and copy the generated border-radius CSS.',
    why: 'Lets you dial in an exact rounded-corner look visually instead of guessing values.',
    steps: ['Set each corner radius.', 'Preview the shape.', 'Copy the CSS.'],
    keywords: 'border radius css rounded corners generator design' },

  { cat: 'math-unit-tools', subcat: 'unit-converters', subcatName: 'Physical & Data Unit Converters', slug: 'cooking-measurement-converter', name: 'Cooking Measurement Converter', icon: '🥄', Component: CookingMeasurementConverter,
    desc: 'Convert between cooking volume units (teaspoons to liters) or weight units (grams to pounds).',
    why: 'Converts a recipe’s measurements when you only have different tools on hand.',
    steps: ['Choose volume or weight.', 'Enter the amount and unit.', 'Read the converted amounts.'],
    keywords: 'cooking measurement conversion cups tablespoons grams recipe kitchen' },

  { cat: 'lifestyle-travel-tools', subcat: 'everyday-utilities', subcatName: 'Everyday Utilities', slug: 'sleep-cycle-calculator', name: 'Sleep Cycle Calculator', icon: '😴', Component: SleepCycleCalculator,
    desc: 'Work out the best bedtime or wake-up time based on 90-minute sleep cycles.',
    why: 'Waking at the end of a sleep cycle instead of mid-cycle tends to feel less groggy.',
    steps: ['Choose whether you have a wake-up time or bedtime.', 'Enter the time.', 'Review the suggested times.'],
    keywords: 'sleep cycle calculator bedtime wake up rest time' },

  { cat: 'communication-tools', subcat: 'message-utilities', subcatName: 'Message Utilities', slug: 'message-tone-checker', name: 'Message Tone Checker', icon: '🗯️', Component: MessageToneChecker,
    desc: 'Scan a draft message for capitalization, punctuation and wording that could come across as harsh.',
    why: 'Catches an accidentally sharp-sounding message before you hit send.',
    steps: ['Paste your draft message.', 'Read the tone flags, if any.', 'Adjust the wording as needed.'],
    keywords: 'tone checker message email harsh shouting caps punctuation' },

  { cat: 'accessibility-tools', subcat: 'text-accessibility', subcatName: 'Text Accessibility', slug: 'readability-score-checker', name: 'Readability Score Checker', icon: '📖', Component: ReadabilityScoreChecker,
    desc: 'Calculate Flesch Reading Ease and Flesch-Kincaid Grade Level for a piece of text.',
    why: 'Checks whether writing matches the reading level of its intended audience.',
    steps: ['Paste your text.', 'Read the Flesch Reading Ease score and grade level.'],
    keywords: 'readability flesch kincaid grade level reading ease accessibility text' },

  { cat: 'astronomy-space-tools', subcat: 'space-calculators', subcatName: 'Space Calculators', slug: 'orbital-period-calculator', name: 'Orbital Period Calculator', icon: '🛰️', Component: OrbitalPeriodCalculator,
    desc: 'Calculate an orbital period using Kepler’s third law or from a central body’s mass.',
    why: 'Shows how long an orbit takes given its distance, without complex manual astrophysics math.',
    steps: ['Choose a calculation method.', 'Enter the semi-major axis (and mass, if using that method).', 'Select Calculate period.'],
    keywords: 'orbital period kepler orbit calculator astronomy space semi-major axis' },

  { cat: 'gardening-tools', subcat: 'plant-care', subcatName: 'Plant Care', slug: 'watering-schedule-calculator', name: 'Plant Watering Schedule Calculator', icon: '💧', Component: WateringScheduleCalculator,
    desc: 'Get a suggested watering interval and next watering date for your plant.',
    why: 'Turns plant type, pot size, season and location into a concrete watering interval.',
    steps: ['Choose your plant type.', 'Pick container size and season.', 'Select Calculate schedule.'],
    keywords: 'plant watering schedule houseplant garden frequency indoor outdoor' },
  { cat: 'gardening-tools', subcat: 'plant-care', subcatName: 'Plant Care', slug: 'soil-ph-adjustment-calculator', name: 'Soil pH Adjustment Calculator', icon: '🧪', Component: SoilPhAdjustmentCalculator,
    desc: 'Work out how much lime or sulfur to add to shift your soil pH toward a target.',
    why: 'Converts a pH gap into a concrete amount of amendment for your soil type and bed size.',
    steps: ['Enter current and target pH.', 'Enter bed area and soil type.', 'Select Calculate.'],
    keywords: 'soil ph lime sulfur garden amendment acidity alkaline' },
  { cat: 'gardening-tools', subcat: 'garden-planning', subcatName: 'Garden Planning', slug: 'seed-starting-date-calculator', name: 'Seed Starting Date Calculator', icon: '🌱', Component: SeedStartingDateCalculator,
    desc: 'Find when to start seeds indoors and when to transplant, based on your last frost date.',
    why: 'Counts back from frost date using standard per-crop lead times.',
    steps: ['Enter your last spring frost date.', 'Choose a crop.', 'Select Calculate dates.'],
    keywords: 'seed starting frost date transplant garden planting schedule' },
  { cat: 'gardening-tools', subcat: 'garden-planning', subcatName: 'Garden Planning', slug: 'garden-bed-layout-planner', name: 'Garden Bed Layout Planner', icon: '🪴', Component: GardenBedLayoutPlanner,
    desc: 'Work out how many plants of each crop fit a garden bed given their spacing needs.',
    why: 'Turns bed dimensions and per-crop spacing into a plant count and grid layout.',
    steps: ['Enter bed width and length.', 'Add each crop with its spacing.', 'Select Calculate layout.'],
    keywords: 'garden bed layout spacing plants raised bed planning' },

  { cat: 'photography-tools', subcat: 'camera-settings', subcatName: 'Camera Settings', slug: 'exposure-triangle-calculator', name: 'Exposure Triangle Calculator', icon: '🎞️', Component: ExposureTriangleCalculator,
    desc: 'Find the equivalent shutter speed when you change aperture, to keep the same exposure.',
    why: 'Skips manual stop maths when you need to adjust one exposure setting and compensate another.',
    steps: ['Set your current aperture, shutter and ISO.', 'Pick a new aperture.', 'Select Calculate equivalent exposure.'],
    keywords: 'exposure triangle aperture shutter speed iso stops photography camera' },
  { cat: 'photography-tools', subcat: 'camera-settings', subcatName: 'Camera Settings', slug: 'depth-of-field-calculator', name: 'Depth of Field Calculator', icon: '🔭', Component: DepthOfFieldCalculator,
    desc: 'Calculate near/far focus limits, total depth of field and hyperfocal distance.',
    why: 'Shows exactly how much of a scene will be in focus before you shoot.',
    steps: ['Enter focal length, aperture and subject distance.', 'Choose your sensor format.', 'Select Calculate.'],
    keywords: 'depth of field hyperfocal distance aperture focal length photography' },
  { cat: 'photography-tools', subcat: 'photo-planning', subcatName: 'Photo Planning', slug: 'golden-hour-calculator', name: 'Golden Hour Calculator', icon: '🌅', Component: GoldenHourCalculator,
    desc: 'Get golden hour and blue hour windows from a sunrise and sunset time.',
    why: 'Turns published sunrise/sunset times into the actual shooting windows photographers plan around.',
    steps: ['Enter sunrise and sunset time for your date and location.', 'Select Calculate windows.'],
    keywords: 'golden hour blue hour sunrise sunset photography lighting' },
  { cat: 'photography-tools', subcat: 'photo-planning', subcatName: 'Photo Planning', slug: 'photo-print-size-calculator', name: 'Photo Print Size Calculator', icon: '🖼️', Component: PhotoPrintSizeCalculator,
    desc: 'Find the largest print size your image supports at a given DPI.',
    why: 'Converts pixel dimensions into real-world print inches and centimetres before you order prints.',
    steps: ['Enter image width and height in pixels.', 'Enter your target DPI.', 'Select Calculate max print size.'],
    keywords: 'photo print size dpi resolution inches centimeters' },

  { cat: 'home-maintenance-tools', subcat: 'home-projects', subcatName: 'Home Projects', slug: 'paint-coverage-calculator', name: 'Paint Coverage Calculator', icon: '🎨', Component: PaintCoverageCalculator,
    desc: 'Work out how many gallons of paint you need for a room.',
    why: 'Accounts for wall area, coats and openings so you buy the right amount the first time.',
    steps: ['Add each wall\u2019s width and height.', 'Subtract doors/windows.', 'Set coats and coverage.', 'Select Calculate.'],
    keywords: 'paint coverage calculator gallons room walls diy' },
  { cat: 'home-maintenance-tools', subcat: 'home-projects', subcatName: 'Home Projects', slug: 'wallpaper-calculator', name: 'Wallpaper Calculator', icon: '🧻', Component: WallpaperCalculator,
    desc: 'Calculate how many rolls of wallpaper a room needs.',
    why: 'Accounts for roll size and pattern repeat so you don\u2019t under- or over-order.',
    steps: ['Enter room perimeter and wall height.', 'Enter roll width, length and pattern repeat.', 'Select Calculate rolls needed.'],
    keywords: 'wallpaper calculator rolls room diy pattern repeat' },
  { cat: 'home-maintenance-tools', subcat: 'maintenance-schedules', subcatName: 'Maintenance Schedules', slug: 'hvac-filter-reminder', name: 'HVAC Filter Replacement Reminder', icon: '🌬️', Component: HvacFilterReminder,
    desc: 'Find your next HVAC filter replacement date based on filter type.',
    why: 'Turns filter type and last-changed date into a concrete next replacement date.',
    steps: ['Choose your filter type.', 'Enter the date you last replaced it.', 'Select Calculate next change.'],
    keywords: 'hvac filter replacement reminder furnace air conditioner home' },
  { cat: 'home-maintenance-tools', subcat: 'maintenance-schedules', subcatName: 'Maintenance Schedules', slug: 'maintenance-checklist-generator', name: 'Home Maintenance Checklist Generator', icon: '📋', Component: MaintenanceChecklistGenerator,
    desc: 'Get a seasonal home maintenance checklist you can check off, copy or download.',
    why: 'Groups the common seasonal upkeep tasks so nothing gets missed.',
    steps: ['Pick a season.', 'Check off tasks as you complete them.', 'Copy or download the list.'],
    keywords: 'home maintenance checklist seasonal spring fall winter summer' },

  { cat: 'electronics-tools', subcat: 'circuit-calculators', subcatName: 'Circuit Calculators', slug: 'resistor-color-code-calculator', name: 'Resistor Color Code Calculator', icon: '🎚️', Component: ResistorColorCodeCalculator,
    desc: 'Read a 4-band resistor color code and get its resistance and tolerance.',
    why: 'Saves you from manually decoding color bands with a reference chart.',
    steps: ['Select each band\u2019s color.', 'Read the resistance and tolerance.'],
    keywords: 'resistor color code calculator electronics resistance ohms' },
  { cat: 'electronics-tools', subcat: 'circuit-calculators', subcatName: 'Circuit Calculators', slug: 'voltage-divider-calculator', name: 'Voltage Divider Calculator', icon: '⚡', Component: VoltageDividerCalculator,
    desc: 'Solve for output voltage or the resistor needed to hit a target voltage.',
    why: 'Handles both directions of the voltage divider formula so you can design or check a circuit.',
    steps: ['Choose what to solve for.', 'Enter Vin and known resistor(s).', 'Select Calculate.'],
    keywords: 'voltage divider calculator resistor circuit electronics vout' },
  { cat: 'electronics-tools', subcat: 'battery-power', subcatName: 'Battery & Power', slug: 'battery-life-estimator', name: 'Battery Life Estimator', icon: '🔋', Component: BatteryLifeEstimator,
    desc: 'Estimate device runtime from battery capacity and current draw.',
    why: 'Converts mAh and current draw into a realistic runtime estimate, with an efficiency factor for real-world loss.',
    steps: ['Enter battery capacity in mAh.', 'Enter average current draw.', 'Enter an efficiency percentage.', 'Select Estimate runtime.'],
    keywords: 'battery life estimator runtime mah current draw electronics' },
  { cat: 'electronics-tools', subcat: 'battery-power', subcatName: 'Battery & Power', slug: 'wire-gauge-calculator', name: 'Wire Gauge Calculator', icon: '🔧', Component: WireGaugeCalculator,
    desc: 'Get a recommended wire gauge for a run length, current and acceptable voltage drop.',
    why: 'Finds the thinnest wire in a standard AWG table that still keeps voltage drop under your limit.',
    steps: ['Enter current, wire length and system voltage.', 'Enter your max acceptable voltage drop.', 'Select Recommend gauge.'],
    keywords: 'wire gauge awg calculator voltage drop electrical current' },

  { cat: 'parenting-tools', subcat: 'baby-planning', subcatName: 'Baby Planning', slug: 'baby-feeding-schedule-tracker', name: 'Baby Feeding Schedule Tracker', icon: '🍼', Component: BabyFeedingScheduleTracker,
    desc: 'Get a guideline feeding frequency and suggested feeding times based on baby\u2019s age.',
    why: 'Turns age-based feeding guidelines into a concrete daily schedule from your baby\u2019s wake time.',
    steps: ['Enter baby\u2019s age in months.', 'Enter typical wake-up time.', 'Select Generate guideline schedule.'],
    keywords: 'baby feeding schedule newborn infant tracker parenting' },
  { cat: 'parenting-tools', subcat: 'baby-planning', subcatName: 'Baby Planning', slug: 'due-date-calculator', name: 'Due Date Calculator', icon: '🤰', Component: DueDateCalculator,
    desc: 'Estimate a pregnancy due date from the last menstrual period or conception date.',
    why: 'Applies the standard 280/266-day rule so you get an estimate instantly.',
    steps: ['Choose last period or conception date.', 'Enter the date.', 'Select Calculate due date.'],
    keywords: 'due date calculator pregnancy last period conception weeks' },
  { cat: 'parenting-tools', subcat: 'child-development', subcatName: 'Child Development', slug: 'child-growth-rate-tracker', name: 'Child Growth Rate Tracker', icon: '📏', Component: ChildGrowthRateTracker,
    desc: 'Calculate height and weight growth rate per month between two measurements.',
    why: 'Turns two dated measurements into a monthly growth rate you can track over time.',
    steps: ['Enter the first measurement date, height and weight.', 'Enter the second.', 'Select Calculate growth rate.'],
    keywords: 'child growth rate tracker height weight kids parenting' },
  { cat: 'parenting-tools', subcat: 'child-development', subcatName: 'Child Development', slug: 'screen-time-tracker', name: 'Screen Time Tracker', icon: '📱', Component: ScreenTimeTracker,
    desc: 'Log daily screen time against a target limit and see weekly totals.',
    why: 'Shows at a glance which days went over your family\u2019s screen time target.',
    steps: ['Set a daily limit.', 'Enter minutes for each day.', 'Read the weekly total and average.'],
    keywords: 'screen time tracker kids limit weekly parenting digital wellbeing' },

  { cat: 'events-tools', subcat: 'party-planning', subcatName: 'Party Planning', slug: 'party-budget-planner', name: 'Party Budget Planner', icon: '🎈', Component: PartyBudgetPlanner,
    desc: 'Split a total party budget across categories like venue, food and decorations.',
    why: 'Turns a lump-sum budget and percentage splits into a dollar figure per category.',
    steps: ['Enter your total budget.', 'Set a percentage for each category.', 'Check the remaining unallocated amount.'],
    keywords: 'party budget planner event spending categories percentages' },
  { cat: 'events-tools', subcat: 'party-planning', subcatName: 'Party Planning', slug: 'catering-quantity-calculator', name: 'Catering Quantity Calculator', icon: '🍽️', Component: CateringQuantityCalculator,
    desc: 'Estimate food, drink and ice quantities for an event from guest count and service style.',
    why: 'Applies standard catering rules of thumb so you don\u2019t under- or over-order.',
    steps: ['Enter guest count and event length.', 'Choose a service style.', 'Select Calculate quantities.'],
    keywords: 'catering calculator party food quantity drinks ice guests' },
  { cat: 'events-tools', subcat: 'guest-management', subcatName: 'Guest Management', slug: 'rsvp-tracker', name: 'RSVP Tracker', icon: '✉️', Component: RsvpTracker,
    desc: 'Track guest responses and see totals attending, declined and pending.',
    why: 'Keeps a live headcount as responses come in, including party sizes.',
    steps: ['Add each guest or party.', 'Set their party size and response.', 'Read the running totals.'],
    keywords: 'rsvp tracker guest list event party wedding responses' },
  { cat: 'events-tools', subcat: 'guest-management', subcatName: 'Guest Management', slug: 'seating-chart-planner', name: 'Seating Chart Planner', icon: '🪑', Component: SeatingChartPlanner,
    desc: 'Distribute a guest list evenly across tables for an event.',
    why: 'Turns a plain guest list into a table-by-table seating plan you can copy out.',
    steps: ['Paste guest names, one per line.', 'Set number of tables and seats per table.', 'Select Assign seating.'],
    keywords: 'seating chart planner event wedding tables guests' },

  { cat: 'sewing-crafts-tools', subcat: 'fabric-measurement', subcatName: 'Fabric Measurement', slug: 'fabric-yardage-calculator', name: 'Fabric Yardage Calculator', icon: '📐', Component: FabricYardageCalculator,
    desc: 'Estimate total fabric yardage needed for a set of pattern pieces.',
    why: 'Accounts for fabric width and how pieces lay out across it, plus a waste buffer.',
    steps: ['Add each pattern piece with width, length and quantity.', 'Enter fabric width and waste buffer.', 'Select Calculate yardage.'],
    keywords: 'fabric yardage calculator sewing pattern pieces cloth' },
  { cat: 'sewing-crafts-tools', subcat: 'fabric-measurement', subcatName: 'Fabric Measurement', slug: 'seam-allowance-calculator', name: 'Seam Allowance Calculator', icon: '✂️', Component: SeamAllowanceCalculator,
    desc: 'Add seam allowance to a finished piece size to get the cut size.',
    why: 'Handles the simple but easy-to-miss maths of adding allowance to every seamed edge.',
    steps: ['Enter the finished piece width and height.', 'Enter your seam allowance per edge.', 'Select Calculate cut size.'],
    keywords: 'seam allowance calculator sewing cut size pattern' },
  { cat: 'sewing-crafts-tools', subcat: 'craft-planning', subcatName: 'Craft Planning', slug: 'yarn-requirement-estimator', name: 'Yarn Requirement Estimator', icon: '🧶', Component: YarnRequirementEstimator,
    desc: 'Estimate total yarn yardage and number of skeins for a knit or crochet project.',
    why: 'Converts project size and yarn weight into a skein count so you buy enough in one trip.',
    steps: ['Enter project width and length.', 'Choose yarn weight and skein yardage.', 'Select Estimate yarn needed.'],
    keywords: 'yarn requirement estimator knitting crochet skeins yardage' },
  { cat: 'sewing-crafts-tools', subcat: 'craft-planning', subcatName: 'Craft Planning', slug: 'craft-project-cost-calculator', name: 'Craft Project Cost Calculator', icon: '🧮', Component: CraftProjectCostCalculator,
    desc: 'Total up materials and labor cost for a craft project and get a suggested sale price.',
    why: 'Adds material costs and labor time, then applies a markup so you can price for selling.',
    steps: ['List each material with quantity and cost.', 'Enter hours spent and your hourly rate.', 'Set a markup percentage.'],
    keywords: 'craft project cost calculator pricing handmade materials labor' },

  { cat: 'sports-tools', subcat: 'performance-tracking', subcatName: 'Performance Tracking', slug: 'shooting-percentage-tracker', name: 'Shooting Percentage Tracker', icon: '🏀', Component: ShootingPercentageTracker,
    desc: 'Track makes and attempts across games and see per-game and overall shooting percentage.',
    why: 'Keeps a running shooting percentage across multiple games without manual recalculation.',
    steps: ['Add an entry for each game or practice.', 'Enter makes and attempts.', 'Read the overall percentage.'],
    keywords: 'shooting percentage tracker basketball stats sports' },
  { cat: 'sports-tools', subcat: 'performance-tracking', subcatName: 'Performance Tracking', slug: 'team-roster-rotation-planner', name: 'Team Roster Rotation Planner', icon: '🔄', Component: TeamRosterRotationPlanner,
    desc: 'Generate a fair playing-time rotation for a team roster across periods.',
    why: 'Rotates the lineup automatically so every player gets roughly equal playing time.',
    steps: ['Paste player names, one per line.', 'Set players on field and number of periods.', 'Select Generate rotation.'],
    keywords: 'team roster rotation planner lineup sports coach playing time' },
  { cat: 'sports-tools', subcat: 'game-planning', subcatName: 'Game Planning', slug: 'tournament-bracket-generator', name: 'Tournament Bracket Generator', icon: '🏆', Component: TournamentBracketGenerator,
    desc: 'Generate a single-elimination bracket from a list of teams or players, with byes handled.',
    why: 'Handles seeding, byes for non-power-of-2 entries, and round structure automatically.',
    steps: ['Paste team or player names, one per line.', 'Choose seeding.', 'Select Generate bracket.'],
    keywords: 'tournament bracket generator single elimination sports seeding' },
  { cat: 'sports-tools', subcat: 'game-planning', subcatName: 'Game Planning', slug: 'fantasy-points-calculator', name: 'Fantasy League Points Calculator', icon: '🏈', Component: FantasyPointsCalculator,
    desc: 'Calculate fantasy sports points from editable stat categories and per-unit weights.',
    why: 'Lets you plug in any league\u2019s scoring rules instead of being locked to one format.',
    steps: ['Enter each stat\u2019s value.', 'Adjust points-per-unit to match your league.', 'Read the total.'],
    keywords: 'fantasy points calculator sports league scoring stats' },

  { cat: 'weather-tools', subcat: 'weather-planning', subcatName: 'Weather Planning', slug: 'wind-chill-calculator', name: 'Wind Chill Calculator', icon: '🥶', Component: WindChillCalculator,
    desc: 'Calculate the wind chill "feels like" temperature from air temperature and wind speed.',
    why: 'Uses the official NWS wind chill formula so you know how cold it actually feels outside.',
    steps: ['Enter air temperature and wind speed.', 'Select Calculate wind chill.'],
    keywords: 'wind chill calculator feels like temperature cold weather' },
  { cat: 'weather-tools', subcat: 'weather-planning', subcatName: 'Weather Planning', slug: 'heat-index-calculator', name: 'Heat Index Calculator', icon: '🥵', Component: HeatIndexCalculator,
    desc: 'Calculate the heat index "feels like" temperature from air temperature and humidity.',
    why: 'Uses the NWS heat index formula so you know the real heat risk, not just the thermometer reading.',
    steps: ['Enter air temperature and relative humidity.', 'Select Calculate heat index.'],
    keywords: 'heat index calculator feels like temperature humidity weather' },
  { cat: 'weather-tools', subcat: 'climate-utilities', subcatName: 'Climate Utilities', slug: 'dew-point-calculator', name: 'Dew Point Calculator', icon: '💦', Component: DewPointCalculator,
    desc: 'Calculate dew point from air temperature and relative humidity.',
    why: 'Dew point is a more reliable comfort indicator than humidity percentage alone.',
    steps: ['Enter air temperature and relative humidity.', 'Select Calculate dew point.'],
    keywords: 'dew point calculator humidity temperature weather comfort' },
  { cat: 'weather-tools', subcat: 'climate-utilities', subcatName: 'Climate Utilities', slug: 'rainfall-collection-calculator', name: 'Rainfall Collection Calculator', icon: '🌧️', Component: RainfallCollectionCalculator,
    desc: 'Estimate how much water you could collect from a roof or catchment area during rainfall.',
    why: 'Converts catchment area and rainfall amount into gallons or liters collectable.',
    steps: ['Enter catchment area.', 'Enter rainfall amount.', 'Select Calculate collected water.'],
    keywords: 'rainwater collection calculator harvesting roof catchment' },

  { cat: 'construction-tools', subcat: 'material-estimation', subcatName: 'Material Estimation', slug: 'concrete-volume-calculator', name: 'Concrete Volume Calculator', icon: '🧱', Component: ConcreteVolumeCalculator,
    desc: 'Calculate concrete volume needed for a slab or post hole, and how many bags to buy.',
    why: 'Converts dimensions into cubic yards and a bag count so you order the right amount.',
    steps: ['Choose slab or post hole.', 'Enter the dimensions.', 'Select Calculate volume.'],
    keywords: 'concrete volume calculator slab post hole bags cubic yards' },
  { cat: 'construction-tools', subcat: 'material-estimation', subcatName: 'Material Estimation', slug: 'lumber-board-feet-calculator', name: 'Lumber Board Feet Calculator', icon: '🪵', Component: LumberBoardFeetCalculator,
    desc: 'Calculate total board feet and estimated cost across a list of lumber pieces.',
    why: 'Handles the board-foot formula across multiple board sizes and quantities at once.',
    steps: ['Add each board\u2019s thickness, width, length and quantity.', 'Optionally enter a price per board foot.'],
    keywords: 'lumber board feet calculator wood woodworking cost' },
  { cat: 'construction-tools', subcat: 'project-calculations', subcatName: 'Project Calculations', slug: 'roofing-square-calculator', name: 'Roofing Square Calculator', icon: '🏠', Component: RoofingSquareCalculator,
    desc: 'Convert a building footprint and roof pitch into roofing squares and shingle bundles.',
    why: 'Accounts for pitch, which adds real surface area beyond the flat footprint.',
    steps: ['Enter building footprint area.', 'Choose roof pitch and waste allowance.', 'Select Calculate.'],
    keywords: 'roofing square calculator shingles pitch bundles roof' },
  { cat: 'construction-tools', subcat: 'project-calculations', subcatName: 'Project Calculations', slug: 'drywall-sheet-calculator', name: 'Drywall Sheet Calculator', icon: '🧱', Component: DrywallSheetCalculator,
    desc: 'Calculate how many drywall sheets you need from wall and ceiling dimensions.',
    why: 'Adds up multiple surfaces and a waste buffer to give a sheet count for ordering.',
    steps: ['Add each surface\u2019s width and height.', 'Choose sheet size and waste allowance.', 'Select Calculate sheets needed.'],
    keywords: 'drywall sheet calculator sheetrock gypsum board construction' },

  { cat: 'interior-design-tools', subcat: 'room-planning', subcatName: 'Room Planning', slug: 'furniture-layout-space-planner', name: 'Furniture Layout Space Planner', icon: '🛋️', Component: FurnitureLayoutSpacePlanner,
    desc: 'See what percentage of your room floor area furniture will take up.',
    why: 'Flags when a room will feel cramped before you buy or arrange furniture.',
    steps: ['Enter room width and length.', 'Add each furniture piece\u2019s footprint.', 'Select Calculate.'],
    keywords: 'furniture layout planner room space floor area interior design' },
  { cat: 'interior-design-tools', subcat: 'room-planning', subcatName: 'Room Planning', slug: 'flooring-square-footage-calculator', name: 'Flooring Square Footage Calculator', icon: '🪵', Component: FlooringSquareFootageCalculator,
    desc: 'Calculate total flooring area and how many boxes of flooring to buy.',
    why: 'Sums multiple rooms and adds a waste buffer to give a box count for ordering.',
    steps: ['Add each room\u2019s width and length.', 'Enter coverage per box and waste allowance.', 'Select Calculate.'],
    keywords: 'flooring calculator square footage boxes laminate hardwood tile' },
  { cat: 'interior-design-tools', subcat: 'furniture-fitting', subcatName: 'Furniture Fitting', slug: 'rug-size-calculator', name: 'Rug Size Calculator', icon: '🟫', Component: RugSizeCalculator,
    desc: 'Get a suggested area rug size for a living room, dining room or bedroom setup.',
    why: 'Applies standard interior-design rules for how a rug should relate to the furniture around it.',
    steps: ['Choose your room setup.', 'Enter the furniture group or table/bed size.', 'Select Suggest rug size.'],
    keywords: 'rug size calculator area rug living room dining bedroom' },
  { cat: 'interior-design-tools', subcat: 'furniture-fitting', subcatName: 'Furniture Fitting', slug: 'curtain-fabric-calculator', name: 'Curtain Fabric Calculator', icon: '🪟', Component: CurtainFabricCalculator,
    desc: 'Calculate fabric widths and total yardage needed for curtains.',
    why: 'Accounts for fullness ratio and fabric width, the two things people usually get wrong.',
    steps: ['Enter track width and drop.', 'Enter fullness ratio and fabric width.', 'Select Calculate fabric needed.'],
    keywords: 'curtain fabric calculator drapes yardage fullness sewing' },

  { cat: 'business-tools', subcat: 'pricing-costing', subcatName: 'Pricing & Costing', slug: 'break-even-point-calculator', name: 'Break-Even Point Calculator', icon: '📊', Component: BreakEvenPointCalculator,
    desc: 'Calculate how many units you need to sell to cover your fixed costs.',
    why: 'Turns fixed costs, price and variable cost into a concrete break-even unit count.',
    steps: ['Enter fixed costs.', 'Enter price and variable cost per unit.', 'Select Calculate break-even.'],
    keywords: 'break even point calculator business fixed costs units' },
  { cat: 'business-tools', subcat: 'pricing-costing', subcatName: 'Pricing & Costing', slug: 'profit-margin-calculator', name: 'Profit Margin Calculator', icon: '💵', Component: ProfitMarginCalculator,
    desc: 'Calculate profit margin and markup from cost and price, or find the price for a target margin.',
    why: 'Keeps margin and markup straight — the two are easy to confuse but give different numbers.',
    steps: ['Choose what to calculate.', 'Enter cost and price (or target margin).', 'Select Calculate.'],
    keywords: 'profit margin calculator markup pricing business' },
  { cat: 'business-tools', subcat: 'operations-planning', subcatName: 'Operations Planning', slug: 'inventory-reorder-point-calculator', name: 'Inventory Reorder Point Calculator', icon: '📦', Component: InventoryReorderPointCalculator,
    desc: 'Calculate the stock level at which you should reorder inventory.',
    why: 'Combines usage rate, lead time and safety stock into one reorder trigger point.',
    steps: ['Enter average daily usage.', 'Enter supplier lead time.', 'Enter safety stock.', 'Select Calculate reorder point.'],
    keywords: 'inventory reorder point calculator stock supply chain' },
  { cat: 'business-tools', subcat: 'operations-planning', subcatName: 'Operations Planning', slug: 'staff-scheduling-coverage-calculator', name: 'Staff Scheduling Coverage Calculator', icon: '🗓️', Component: StaffSchedulingCoverageCalculator,
    desc: 'Check whether available staff cover the shifts you need for the day.',
    why: 'Adds up staffing needs across shifts and flags any coverage gap immediately.',
    steps: ['List each shift and staff needed.', 'Enter staff available.', 'Read the coverage gap.'],
    keywords: 'staff scheduling coverage calculator shifts labor planning' },

  { cat: 'organization-tools', subcat: 'home-organization', subcatName: 'Home Organization', slug: 'closet-decluttering-planner', name: 'Closet Decluttering Planner', icon: '👕', Component: ClosetDeclutteringPlanner,
    desc: 'Track keep/donate/toss decisions across clothing categories as you declutter.',
    why: 'Keeps a running tally so you can see progress across a big decluttering session.',
    steps: ['Enter counts for each category.', 'Copy the summary when you\u2019re done.'],
    keywords: 'closet decluttering planner clothes organization donate' },
  { cat: 'organization-tools', subcat: 'home-organization', subcatName: 'Home Organization', slug: 'moving-box-inventory-tracker', name: 'Moving Box Inventory Tracker', icon: '📦', Component: MovingBoxInventoryTracker,
    desc: 'Log box numbers, rooms and contents for a move, and flag fragile boxes.',
    why: 'Gives you a searchable list of what\u2019s in every box before you start unpacking.',
    steps: ['Add a row per box with room and contents.', 'Mark fragile boxes.', 'Copy or download the list.'],
    keywords: 'moving box inventory tracker relocation packing list' },
  { cat: 'organization-tools', subcat: 'digital-organization', subcatName: 'Digital Organization', slug: 'file-naming-convention-generator', name: 'File Naming Convention Generator', icon: '🗃️', Component: FileNamingConventionGenerator,
    desc: 'Generate a consistent, sortable filename from project, description, version and date.',
    why: 'Produces a filename that sorts and searches predictably, in the case style you choose.',
    steps: ['Enter project, description and version.', 'Choose date and case style.', 'Copy the filename.'],
    keywords: 'file naming convention generator filename organization digital' },
  { cat: 'organization-tools', subcat: 'digital-organization', subcatName: 'Digital Organization', slug: 'digital-photo-organization-planner', name: 'Digital Photo Organization Planner', icon: '🖼️', Component: DigitalPhotoOrganizationPlanner,
    desc: 'Estimate how long it\u2019ll take to sort a photo backlog and see a suggested folder structure.',
    why: 'Turns an overwhelming photo backlog into a concrete day count and a folder plan.',
    steps: ['Enter total photos and your daily sorting pace.', 'Pick a folder structure.'],
    keywords: 'digital photo organization planner folder structure backlog' },

  { cat: 'household-tools', subcat: 'cleaning-schedules', subcatName: 'Cleaning Schedules', slug: 'cleaning-schedule-rotator', name: 'Cleaning Schedule Rotator', icon: '🧽', Component: CleaningScheduleRotator,
    desc: 'Generate a 7-day cleaning schedule from tasks with different recurrence frequencies.',
    why: 'Spreads recurring chores like dusting and mopping across the week automatically.',
    steps: ['List each task and how often it recurs.', 'Choose a start day.', 'Read the 7-day schedule.'],
    keywords: 'cleaning schedule rotator chores household weekly' },
  { cat: 'household-tools', subcat: 'cleaning-schedules', subcatName: 'Cleaning Schedules', slug: 'laundry-load-size-estimator', name: 'Laundry Load Size Estimator', icon: '🧺', Component: LaundryLoadSizeEstimator,
    desc: 'Estimate laundry load weight from item counts and check it against your machine\u2019s capacity.',
    why: 'Flags overloaded or under-loaded washes before you start the machine.',
    steps: ['Choose your machine size.', 'Enter counts for each item type.', 'Check load size against capacity.'],
    keywords: 'laundry load size estimator washing machine capacity' },
  { cat: 'household-tools', subcat: 'home-inventory', subcatName: 'Home Inventory', slug: 'home-inventory-value-tracker', name: 'Home Inventory Value Tracker', icon: '🏡', Component: HomeInventoryValueTracker,
    desc: 'Track item values by room for insurance purposes and see totals by room.',
    why: 'Builds a documented, totaled inventory that\u2019s useful for an insurance claim.',
    steps: ['Add each item, room and value.', 'Copy or download the full list.'],
    keywords: 'home inventory value tracker insurance belongings household' },
  { cat: 'household-tools', subcat: 'home-inventory', subcatName: 'Home Inventory', slug: 'pantry-stock-tracker', name: 'Pantry Stock Tracker', icon: '🥫', Component: PantryStockTracker,
    desc: 'Compare what you have against target stock levels and generate a shopping list.',
    why: 'Turns pantry counts into a specific shopping list of exactly what\u2019s low.',
    steps: ['Enter each item\u2019s current quantity and target level.', 'Read the auto-generated shopping list.'],
    keywords: 'pantry stock tracker shopping list groceries inventory' },

  { cat: 'language-tools', subcat: 'vocabulary-building', subcatName: 'Vocabulary Building', slug: 'vocabulary-growth-tracker', name: 'Vocabulary Growth Tracker', icon: '📖', Component: VocabularyGrowthTracker,
    desc: 'Track known-word counts over time and see your weekly vocabulary growth rate.',
    why: 'Turns periodic word-count check-ins into a concrete words-per-week growth rate.',
    steps: ['Log a date and known-word count.', 'Add another check-in later.', 'Read your growth rate.'],
    keywords: 'vocabulary growth tracker language learning words per week' },
  { cat: 'language-tools', subcat: 'vocabulary-building', subcatName: 'Vocabulary Building', slug: 'flashcard-review-interval-calculator', name: 'Flashcard Review Interval Calculator', icon: '🔁', Component: FlashcardReviewIntervalCalculator,
    desc: 'Calculate your next spaced-repetition review interval using an SM-2 style algorithm.',
    why: 'Lets you run spaced repetition scheduling manually for any flashcard system you use.',
    steps: ['Enter current ease factor and interval.', 'Rate how well you recalled the card.', 'Select Calculate next review.'],
    keywords: 'flashcard spaced repetition interval calculator sm-2 language' },
  { cat: 'language-tools', subcat: 'study-tracking', subcatName: 'Study Tracking', slug: 'language-study-streak-tracker', name: 'Language Study Streak Tracker', icon: '🔥', Component: LanguageStudyStreakTracker,
    desc: 'Track your language study streak and see progress toward a streak goal.',
    why: 'Shows consistency percentage and days remaining to your goal, not just a raw streak count.',
    steps: ['Enter your study start date and days missed.', 'Set a streak goal.', 'Select Calculate streak.'],
    keywords: 'language study streak tracker habit consistency learning' },
  { cat: 'language-tools', subcat: 'study-tracking', subcatName: 'Study Tracking', slug: 'immersion-hours-calculator', name: 'Immersion Hours Calculator', icon: '⏳', Component: ImmersionHoursCalculator,
    desc: 'Estimate weeks remaining to reach a language fluency milestone at your current study pace.',
    why: 'Converts community hour-based fluency milestones into a personal timeline.',
    steps: ['Enter immersion hours so far and hours per week.', 'Choose a milestone.', 'Select Calculate time to goal.'],
    keywords: 'immersion hours calculator language fluency milestone study' },

  { cat: 'outdoor-tools', subcat: 'trip-prep', subcatName: 'Trip Prep', slug: 'camping-food-quantity-calculator', name: 'Camping Food Quantity Calculator', icon: '🏕️', Component: CampingFoodQuantityCalculator,
    desc: 'Estimate water, food and stove fuel quantities for a camping trip.',
    why: 'Applies standard backcountry consumption rates scaled by people, days and activity level.',
    steps: ['Enter number of people and days.', 'Choose activity level.', 'Select Calculate quantities.'],
    keywords: 'camping food quantity calculator backpacking water fuel trip' },
  { cat: 'outdoor-tools', subcat: 'trip-prep', subcatName: 'Trip Prep', slug: 'tent-capacity-checker', name: 'Tent Capacity Checker', icon: '⛺', Component: TentCapacityChecker,
    desc: 'Check how many people a tent can realistically fit comfortably with gear.',
    why: 'Adjusts manufacturer "sleeps N" claims for real comfort with gear inside.',
    steps: ['Enter tent floor dimensions.', 'Enter number of people and gear load.', 'Select Check comfort fit.'],
    keywords: 'tent capacity checker camping sleeps how many people' },
  { cat: 'outdoor-tools', subcat: 'gear-planning', subcatName: 'Gear Planning', slug: 'backpack-weight-calculator', name: 'Backpack Weight Calculator', icon: '🎒', Component: BackpackWeightCalculator,
    desc: 'Total your pack weight from individual items and compare it to your body weight.',
    why: 'Flags when total pack weight crosses the commonly recommended 20%-of-body-weight guideline.',
    steps: ['Enter your body weight.', 'List each gear item\u2019s weight.', 'Read the total and percentage.'],
    keywords: 'backpack weight calculator hiking pack base weight gear' },
  { cat: 'outdoor-tools', subcat: 'gear-planning', subcatName: 'Gear Planning', slug: 'campfire-wood-calculator', name: 'Campfire Wood Calculator', icon: '🔥', Component: CampfireWoodCalculator,
    desc: 'Estimate how much firewood you\u2019ll need for a campfire based on hours and purpose.',
    why: 'Converts burn duration and fire type into a concrete pound and bundle count.',
    steps: ['Enter hours you\u2019ll keep the fire burning.', 'Choose fire purpose.', 'Select Calculate wood needed.'],
    keywords: 'campfire wood calculator firewood camping bonfire' },

  { cat: 'real-estate-tools', slug: 'cap-rate-calculator', name: 'Cap Rate Calculator', icon: '📈', Component: CapRateCalculator,
    desc: 'Calculate a rental property\u2019s capitalization rate from net operating income and price.',
    why: 'Gives the standard metric investors use to compare rental properties independent of financing.',
    steps: ['Enter annual net operating income.', 'Enter property price.', 'Select Calculate cap rate.'],
    keywords: 'cap rate calculator rental property real estate investment noi' },
  { cat: 'real-estate-tools', slug: 'cash-on-cash-return-calculator', name: 'Cash-on-Cash Return Calculator', icon: '💰', Component: CashOnCashReturnCalculator,
    desc: 'Calculate annual return on the actual cash invested in a rental property.',
    why: 'Measures the return that matters to an investor who financed part of the purchase.',
    steps: ['Enter annual pre-tax cash flow.', 'Enter total cash invested.', 'Select Calculate return.'],
    keywords: 'cash on cash return calculator real estate investment rental' },
  { cat: 'real-estate-tools', slug: 'rent-vs-buy-comparison-tool', name: 'Rent vs Buy Comparison Tool', icon: '🏠', Component: RentVsBuyComparisonTool,
    desc: 'Compare total cost of renting versus buying a home over a chosen number of years.',
    why: 'Accounts for down payment, mortgage payments, maintenance and appreciation in one comparison.',
    steps: ['Enter rent and home price.', 'Enter mortgage rate and years to compare.', 'Select Compare.'],
    keywords: 'rent vs buy calculator home ownership comparison mortgage' },
  { cat: 'real-estate-tools', slug: 'rental-property-cash-flow-calculator', name: 'Rental Property Cash Flow Calculator', icon: '🧾', Component: RentalPropertyCashFlowCalculator,
    desc: 'Calculate monthly and annual cash flow on a rental property from income and itemized expenses.',
    why: 'Breaks out every common expense category so nothing gets missed when estimating profitability.',
    steps: ['Enter monthly rental income.', 'Fill in each expense category.', 'Read the resulting cash flow.'],
    keywords: 'rental property cash flow calculator landlord expenses income' },
  { cat: 'real-estate-tools', slug: 'property-appreciation-estimator', name: 'Property Appreciation Estimator', icon: '📊', Component: PropertyAppreciationEstimator,
    desc: 'Project a property\u2019s future value from an assumed annual appreciation rate.',
    why: 'Compounds a chosen appreciation rate over time into a concrete future value estimate.',
    steps: ['Enter current value.', 'Enter assumed appreciation rate and years.', 'Select Estimate future value.'],
    keywords: 'property appreciation estimator home value growth real estate' },
  { cat: 'real-estate-tools', slug: 'rent-increase-calculator', name: 'Rent Increase Calculator', icon: '📈', Component: RentIncreaseCalculator,
    desc: 'Calculate a new rent amount and annual impact from a proposed percentage increase.',
    why: 'Turns a percentage increase into a concrete dollar figure per month and per year.',
    steps: ['Enter current rent.', 'Enter the proposed increase percentage.', 'Select Calculate new rent.'],
    keywords: 'rent increase calculator landlord tenant percentage raise' },
  { cat: 'real-estate-tools', slug: 'security-deposit-calculator', name: 'Security Deposit Calculator', icon: '🔑', Component: SecurityDepositCalculator,
    desc: 'Calculate the refund due after itemized deductions from a security deposit.',
    why: 'Keeps a running itemized list so both landlord and tenant can see how the refund was calculated.',
    steps: ['Enter the original deposit.', 'Add each deduction with a reason and amount.', 'Read the refund due.'],
    keywords: 'security deposit calculator landlord tenant refund deductions' },
  { cat: 'real-estate-tools', slug: 'landlord-late-fee-calculator', name: 'Landlord Late Fee Calculator', icon: '⏰', Component: LandlordLateFeeCalculator,
    desc: 'Calculate a late rent fee as a flat amount or daily percentage, with an optional cap.',
    why: 'Handles both common late-fee structures and applies a percentage-of-rent cap automatically.',
    steps: ['Enter monthly rent.', 'Choose flat fee or daily percentage.', 'Select Calculate late fee.'],
    keywords: 'landlord late fee calculator rent overdue tenant' },
  { cat: 'real-estate-tools', slug: 'vacancy-rate-calculator', name: 'Vacancy Rate Calculator', icon: '🏚️', Component: VacancyRateCalculator,
    desc: 'Calculate a rental property\u2019s vacancy rate from vacant unit-days over a period.',
    why: 'Gives the standard occupancy metric landlords and property managers track.',
    steps: ['Enter total units.', 'Enter total vacant unit-days and the period length.', 'Select Calculate vacancy rate.'],
    keywords: 'vacancy rate calculator rental property occupancy landlord' },
  { cat: 'real-estate-tools', slug: 'one-percent-rule-property-screener', name: '1% Rule Property Screener', icon: '✅', Component: OnePercentRulePropertyScreener,
    desc: 'Check whether a property\u2019s expected rent meets the common 1% rule of thumb.',
    why: 'Gives a fast first-pass screen before running a full rental property analysis.',
    steps: ['Enter purchase price and expected monthly rent.', 'Select Check 1% rule.'],
    keywords: '1 percent rule property screener rental investment real estate' },
  { cat: 'real-estate-tools', slug: 'closing-cost-estimator', name: 'Closing Cost Estimator', icon: '📝', Component: ClosingCostEstimator,
    desc: 'Estimate a range of closing costs from a home\u2019s purchase price.',
    why: 'Gives a quick budgeting range before you get an actual Loan Estimate from a lender.',
    steps: ['Enter home purchase price.', 'Adjust the low/high percentage range if needed.', 'Select Estimate closing costs.'],
    keywords: 'closing cost estimator home buying mortgage fees real estate' },
  { cat: 'real-estate-tools', slug: 'home-equity-calculator', name: 'Home Equity Calculator', icon: '🏡', Component: HomeEquityCalculator,
    desc: 'Calculate current home equity and potential borrowing room at 80% loan-to-value.',
    why: 'Turns home value and loan balance into both an equity dollar amount and a borrowing estimate.',
    steps: ['Enter current home value.', 'Enter remaining mortgage balance.', 'Select Calculate equity.'],
    keywords: 'home equity calculator loan to value heloc mortgage' },

  { cat: 'insurance-tools', slug: 'life-insurance-needs-calculator', name: 'Life Insurance Needs Calculator', icon: '👪', Component: LifeInsuranceNeedsCalculator,
    desc: 'Estimate a life insurance coverage amount using an income-replacement method.',
    why: 'Combines income replacement, debts, future expenses and existing savings into one target figure.',
    steps: ['Enter income to replace and years.', 'Enter debts, future expenses and existing savings.', 'Select Calculate coverage need.'],
    keywords: 'life insurance needs calculator coverage amount income replacement' },
  { cat: 'insurance-tools', slug: 'insurance-coverage-gap-calculator', name: 'Insurance Coverage Gap Calculator', icon: '🕳️', Component: InsuranceCoverageGapCalculator,
    desc: 'Compare total value at risk against current policy coverage to spot an underinsurance gap.',
    why: 'Flags underinsurance in one step instead of manually comparing two numbers.',
    steps: ['Enter total value to insure.', 'Enter current policy coverage.', 'Select Calculate gap.'],
    keywords: 'insurance coverage gap calculator underinsured policy limit' },
  { cat: 'insurance-tools', slug: 'health-insurance-deductible-tracker', name: 'Health Insurance Deductible Tracker', icon: '🏥', Component: HealthInsuranceDeductibleTracker,
    desc: 'Track medical expenses against your annual deductible and see how much remains.',
    why: 'Keeps a running tally through the year so you know when the deductible will be met.',
    steps: ['Enter your annual deductible.', 'Log each medical expense.', 'Read remaining amount until met.'],
    keywords: 'health insurance deductible tracker medical expenses out of pocket' },
  { cat: 'insurance-tools', slug: 'deductible-premium-tradeoff-calculator', name: 'Insurance Deductible vs Premium Tradeoff Calculator', icon: '⚖️', Component: DeductiblePremiumTradeoffCalculator,
    desc: 'Compare a higher-deductible plan against a lower-deductible plan to find the break-even claim count.',
    why: 'Shows exactly how many claims you\u2019d need to file for the pricier plan to pay off.',
    steps: ['Enter both plans\u2019 premiums and deductibles.', 'Select Compare plans.'],
    keywords: 'insurance deductible premium tradeoff calculator plan comparison' },
  { cat: 'insurance-tools', slug: 'renters-insurance-coverage-estimator', name: 'Renters Insurance Coverage Estimator', icon: '🛋️', Component: RentersInsuranceCoverageEstimator,
    desc: 'Estimate total belongings value by category to size a renters insurance policy.',
    why: 'Breaks belongings into categories so nothing gets forgotten when estimating coverage needs.',
    steps: ['Enter estimated value for each category.', 'Read the suggested coverage amount.'],
    keywords: 'renters insurance coverage estimator belongings inventory' },
  { cat: 'insurance-tools', slug: 'umbrella-policy-coverage-calculator', name: 'Umbrella Policy Coverage Calculator', icon: '☂️', Component: UmbrellaPolicyCoverageCalculator,
    desc: 'Estimate umbrella liability coverage needed based on net worth and base policy limits.',
    why: 'Applies the common rule of insuring at least up to your net worth.',
    steps: ['Enter your net worth.', 'Enter home and auto liability limits.', 'Select Estimate umbrella coverage needed.'],
    keywords: 'umbrella insurance policy calculator liability coverage net worth' },
  { cat: 'insurance-tools', slug: 'insurance-claim-documentation-checklist', name: 'Insurance Claim Documentation Checklist', icon: '📋', Component: InsuranceClaimDocumentationChecklist,
    desc: 'Get a checklist of documentation to gather for common insurance claim types.',
    why: 'Prevents a delayed or denied claim from missing paperwork.',
    steps: ['Choose your claim type.', 'Check off items as you gather them.', 'Copy the checklist.'],
    keywords: 'insurance claim documentation checklist auto home health travel' },
  { cat: 'insurance-tools', slug: 'term-vs-whole-life-comparison', name: 'Term vs Whole Life Insurance Comparison', icon: '📉', Component: TermVsWholeLifeComparison,
    desc: 'Model the classic "buy term, invest the difference" comparison between term and whole life insurance.',
    why: 'Shows what investing the premium difference could grow to versus paying for whole life.',
    steps: ['Enter both annual premiums.', 'Enter years and assumed investment return.', 'Select Compare.'],
    keywords: 'term life whole life insurance comparison invest the difference' },
  { cat: 'insurance-tools', slug: 'hsa-contribution-calculator', name: 'HSA Contribution Calculator', icon: '🏦', Component: HsaContributionCalculator,
    desc: 'Calculate remaining HSA contribution room for the year based on coverage type and age.',
    why: 'Applies current IRS limits, including the age-55 catch-up contribution.',
    steps: ['Choose coverage type.', 'Enter contributions so far.', 'Select Calculate remaining room.'],
    keywords: 'hsa contribution calculator health savings account limit' },
  { cat: 'insurance-tools', slug: 'premium-payment-frequency-calculator', name: 'Insurance Premium Payment Frequency Calculator', icon: '🗓️', Component: PremiumPaymentFrequencyCalculator,
    desc: 'Compare the total annual cost of paying insurance monthly versus paying in full.',
    why: 'Surfaces the installment surcharge insurers often add for monthly billing.',
    steps: ['Enter the annual and monthly premium options.', 'Select Compare.'],
    keywords: 'insurance premium payment frequency calculator monthly annual' },
  { cat: 'insurance-tools', slug: 'out-of-pocket-maximum-tracker', name: 'Out-of-Pocket Maximum Tracker', icon: '📉', Component: OutOfPocketMaximumTracker,
    desc: 'Track medical expenses against your annual out-of-pocket maximum.',
    why: 'Tells you exactly when your plan should start covering 100% of costs for the year.',
    steps: ['Enter your out-of-pocket maximum.', 'Log each expense paid.', 'Read remaining amount.'],
    keywords: 'out of pocket maximum tracker health insurance medical expenses' },
  { cat: 'insurance-tools', slug: 'insurance-policy-renewal-reminder', name: 'Insurance Policy Renewal Reminder', icon: '🔔', Component: InsurancePolicyRenewalReminder,
    desc: 'Track renewal dates across multiple insurance policies and see which is coming up soonest.',
    why: 'Sorts every policy by days until renewal so nothing lapses unnoticed.',
    steps: ['Add each policy and its renewal date.', 'Read days remaining, sorted soonest first.'],
    keywords: 'insurance policy renewal reminder tracker expiration date' },

  { cat: 'retirement-planning-tools', slug: 'social-security-benefit-estimator', name: 'Social Security Benefit Estimator', icon: '🏛️', Component: SocialSecurityBenefitEstimator,
    desc: 'Estimate your adjusted monthly Social Security benefit for claiming early or delaying past full retirement age.',
    why: 'Applies the SSA\u2019s official early/delayed retirement adjustment formulas.',
    steps: ['Enter your full retirement age benefit.', 'Enter your full retirement age and planned claiming age.', 'Select Estimate adjusted benefit.'],
    keywords: 'social security benefit estimator claiming age retirement' },
  { cat: 'retirement-planning-tools', slug: 'employer-match-calculator', name: '401(k) Employer Match Calculator', icon: '🏢', Component: EmployerMatchCalculator,
    desc: 'Calculate your 401(k) contribution, employer match, and any match you\u2019re leaving on the table.',
    why: 'Flags exactly how much free employer match is being missed at your current contribution rate.',
    steps: ['Enter salary and your contribution percentage.', 'Enter employer match rate and limit.', 'Select Calculate match.'],
    keywords: '401k employer match calculator retirement contribution' },
  { cat: 'retirement-planning-tools', slug: 'withdrawal-rate-calculator', name: '4% Rule Withdrawal Calculator', icon: '💵', Component: WithdrawalRateCalculator,
    desc: 'Calculate sustainable annual withdrawal from a portfolio, or the portfolio needed for a spending target.',
    why: 'Works in both directions of the classic safe withdrawal rate calculation.',
    steps: ['Choose what to calculate.', 'Enter portfolio size or desired spending.', 'Enter withdrawal rate.'],
    keywords: '4 percent rule withdrawal rate calculator retirement portfolio' },
  { cat: 'retirement-planning-tools', slug: 'rmd-calculator', name: 'Required Minimum Distribution (RMD) Calculator', icon: '📤', Component: RmdCalculator,
    desc: 'Calculate your required minimum distribution from a retirement account using the IRS Uniform Lifetime Table.',
    why: 'Avoids the steep IRS penalty for missing or underpaying an RMD.',
    steps: ['Enter your account balance from Dec 31 last year.', 'Enter your age this year.', 'Select Calculate RMD.'],
    keywords: 'required minimum distribution rmd calculator ira 401k' },
  { cat: 'retirement-planning-tools', slug: 'income-replacement-ratio-calculator', name: 'Retirement Income Replacement Ratio Calculator', icon: '🔄', Component: IncomeReplacementRatioCalculator,
    desc: 'Calculate what percentage of your current income your expected retirement income will replace.',
    why: 'Compares your plan against the common 70-80% replacement ratio guideline.',
    steps: ['Enter current income.', 'Enter expected retirement income.', 'Select Calculate replacement ratio.'],
    keywords: 'retirement income replacement ratio calculator planning' },
  { cat: 'retirement-planning-tools', slug: 'years-to-retirement-countdown', name: 'Years to Retirement Countdown Calculator', icon: '⏳', Component: YearsToRetirementCountdown,
    desc: 'Calculate your exact retirement date and countdown from your birth date and target retirement age.',
    why: 'Turns a target age into an exact date, plus days and working days remaining.',
    steps: ['Enter your birth date.', 'Enter target retirement age.', 'Select Calculate countdown.'],
    keywords: 'years to retirement countdown calculator retirement date' },
  { cat: 'retirement-planning-tools', slug: 'pension-lump-sum-vs-annuity', name: 'Pension Lump Sum vs Annuity Comparison', icon: '🏦', Component: PensionLumpSumVsAnnuity,
    desc: 'Compare a pension lump sum offer against the monthly annuity option using an implied interest rate.',
    why: 'Reveals the effective interest rate the annuity option represents, for a like-for-like comparison.',
    steps: ['Enter the lump sum offer and monthly annuity payment.', 'Enter assumed investment return and years.', 'Select Compare.'],
    keywords: 'pension lump sum annuity comparison retirement calculator' },
  { cat: 'retirement-planning-tools', slug: 'catch-up-contribution-calculator', name: 'Catch-Up Contribution Calculator', icon: '🏃', Component: CatchUpContributionCalculator,
    desc: 'Calculate your total retirement account contribution limit including age-based catch-up contributions.',
    why: 'Applies the SECURE 2.0 enhanced catch-up limits for ages 60-63 automatically.',
    steps: ['Choose your account type.', 'Enter your age.', 'Select Calculate contribution limit.'],
    keywords: 'catch up contribution calculator 401k ira retirement age 50' },
  { cat: 'retirement-planning-tools', slug: 'coast-fire-calculator', name: 'Coast FIRE Calculator', icon: '🛟', Component: CoastFireCalculator,
    desc: 'Calculate your Coast FIRE number — the amount you need saved today to coast to your retirement goal.',
    why: 'Shows whether compound growth alone will get you to your target without further contributions.',
    steps: ['Enter current savings, ages and target nest egg.', 'Enter assumed return.', 'Select Calculate Coast FIRE number.'],
    keywords: 'coast fire calculator retirement savings early financial independence' },
  { cat: 'retirement-planning-tools', slug: 'retirement-healthcare-cost-estimator', name: 'Retirement Healthcare Cost Estimator', icon: '⚕️', Component: RetirementHealthcareCostEstimator,
    desc: 'Estimate total lifetime healthcare costs in retirement accounting for healthcare-specific inflation.',
    why: 'Compounds healthcare costs (which usually inflate faster than general prices) across your retirement years.',
    steps: ['Enter retirement age and life expectancy.', 'Enter today\u2019s annual healthcare cost and inflation rate.', 'Select Estimate total healthcare cost.'],
    keywords: 'retirement healthcare cost estimator medical expenses planning' },
  { cat: 'retirement-planning-tools', slug: 'social-security-claiming-age-comparison', name: 'Social Security Claiming Age Comparison', icon: '📅', Component: SocialSecurityClaimingAgeComparison,
    desc: 'Compare monthly benefit and total collected by a chosen age across several Social Security claiming ages.',
    why: 'Lays out multiple claiming ages side by side instead of calculating them one at a time.',
    steps: ['Enter your full retirement age benefit and FRA.', 'Enter an age to compare totals by.', 'Select Compare claiming ages.'],
    keywords: 'social security claiming age comparison calculator retirement' },
  { cat: 'retirement-planning-tools', slug: 'required-savings-rate-calculator', name: 'Required Savings Rate Calculator', icon: '📐', Component: RequiredSavingsRateCalculator,
    desc: 'Calculate the monthly savings amount and percentage of income needed to reach a retirement goal.',
    why: 'Converts a target nest egg and timeline into a concrete monthly savings figure.',
    steps: ['Enter income, current savings and target amount.', 'Enter years and assumed return.', 'Select Calculate required savings rate.'],
    keywords: 'required savings rate calculator retirement goal planning' },
]

export const related = (t) => {
  const same = tools.filter((x) => x.cat === t.cat && x !== t)
  return [...same, ...tools.filter((x) => x.cat !== t.cat)].slice(0, 4)
}

export function search(q, cat) {
  const terms = q.toLowerCase().split(/\s+/).filter(Boolean)
  return tools.filter((t) => {
    if (cat && t.cat !== cat) return false
    const c = categories.find((x) => x.slug === t.cat)
    const hay = `${t.name} ${c.name} ${t.keywords} ${t.desc} ${t.why}`.toLowerCase()
    return terms.every((w) => hay.includes(w))
  })
}
