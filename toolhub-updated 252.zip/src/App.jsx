import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout.jsx'
import Home from './pages/Home.jsx'
import AllCategories from './pages/AllCategories.jsx'
import AllTools from './pages/AllTools.jsx'
import Category from './pages/Category.jsx'
import ToolPage from './pages/ToolPage.jsx'
import NotFound from './pages/NotFound.jsx'
export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="categories" element={<AllCategories />} />
        <Route path="tools" element={<AllTools />} />
        <Route path=":cat" element={<Category />} />
        <Route path=":cat/:tool" element={<ToolPage />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  )
}
