import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { categories, tools, search } from '../data/registry.js'
import ToolCard from '../components/ToolCard.jsx'
import NotFound from './NotFound.jsx'

export default function Category() {
  const { cat } = useParams()
  const c = categories.find((x) => x.slug === cat)
  const [q, setQ] = useState('')
  useEffect(() => { if (c) document.title = `${c.name} – ToolHub`; setQ('') }, [c])
  if (!c) return <NotFound />
  const list = search(q, c.slug)
  const showGrouped = !q && c.subcategories?.length

  return (
    <>
      <nav className="crumbs" aria-label="Breadcrumb"><Link to="/">Home</Link> / <Link to="/categories">Categories</Link> / <span>{c.name}</span></nav>
      <header className={'head accent-' + c.accent}>
        <span className="ico big" aria-hidden="true">{c.icon}</span>
        <div>
          <h1>{c.name}</h1>
          <p>{c.desc}</p>
          <div className="head-meta">
            <span className="badge sub">{tools.filter((t) => t.cat === c.slug).length} tools</span>
            {c.subcategories?.length ? <span className="badge sub">{c.subcategories.length} subcategories</span> : null}
          </div>
        </div>
      </header>

      <input className="big" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={`Search ${c.name.toLowerCase()}`} aria-label={`Search ${c.name}`} />

      {!list.length && (
        <div className="empty"><p>No tool in {c.name} matches "{q}".</p><button className="btn" onClick={() => setQ('')}>Clear search</button></div>
      )}

      {list.length > 0 && showGrouped ? (
        c.subcategories.map((s) => {
          const subTools = list.filter((t) => t.subcat === s.slug)
          if (!subTools.length) return null
          return (
            <section key={s.slug}>
              <div className={'subhead accent-' + c.accent}>
                <span className="dot" aria-hidden="true"></span>
                <h2>{s.name}</h2>
                <span>{subTools.length} tools</span>
              </div>
              <div className="grid">{subTools.map((t) => <ToolCard key={t.slug} t={t} />)}</div>
            </section>
          )
        })
      ) : list.length > 0 ? (
        <div className="grid">{list.map((t) => <ToolCard key={t.slug} t={t} />)}</div>
      ) : null}

      <p className="back"><Link to="/">Back to Home</Link></p>
    </>
  )
}
