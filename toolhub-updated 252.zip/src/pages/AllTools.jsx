import { useEffect } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { categories, tools, search } from '../data/registry.js'
import ToolCard from '../components/ToolCard.jsx'

export default function AllTools() {
  const [p, setP] = useSearchParams()
  const q = p.get('q') || ''
  const cat = p.get('cat') || ''
  const popularOnly = p.get('popular') === '1'

  useEffect(() => { document.title = 'All Tools – ToolHub' }, [])

  let list = search(q, cat || undefined)
  if (popularOnly && !q) list = list.filter((t) => t.popular)

  const update = (patch) => {
    const next = { q, cat, popular: popularOnly ? '1' : '' , ...patch }
    const obj = {}
    if (next.q) obj.q = next.q
    if (next.cat) obj.cat = next.cat
    if (next.popular) obj.popular = '1'
    setP(obj, { replace: true })
  }

  return (
    <>
      <nav className="crumbs" aria-label="Breadcrumb"><Link to="/">Home</Link> / <span>All Tools</span></nav>
      <section className="section-head">
        <div>
          <span className="eyebrow-sm">Library</span>
          <h1>{popularOnly && !q ? 'Popular Tools' : 'All Tools'}</h1>
          <p>{list.length} of {tools.length} tools{cat ? ` in ${categories.find((c) => c.slug === cat)?.name || cat}` : ''}.</p>
        </div>
      </section>

      <div className="row" style={{ marginBottom: '1.4rem' }}>
        <label className="field">
          <span>Search</span>
          <input type="search" value={q} placeholder="Search all tools…" onChange={(e) => update({ q: e.target.value })} aria-label="Search all tools" />
        </label>
        <label className="field">
          <span>Category</span>
          <select value={cat} onChange={(e) => update({ cat: e.target.value })} aria-label="Filter by category">
            <option value="">All categories</option>
            {categories.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
          </select>
        </label>
      </div>

      {list.length
        ? <div className="grid">{list.map((t) => <ToolCard key={t.cat + t.slug} t={t} />)}</div>
        : <div className="empty"><p>No tool matches your filters.</p><button className="btn" onClick={() => setP({})}>Clear filters</button></div>}
    </>
  )
}
