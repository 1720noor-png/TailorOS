import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { categories, tools } from '../data/registry.js'

export default function AllCategories() {
  useEffect(() => { document.title = 'All Categories – ToolHub' }, [])
  const totalSub = categories.reduce((n, c) => n + (c.subcategories?.length || 0), 0)
  return (
    <>
      <nav className="crumbs" aria-label="Breadcrumb"><Link to="/">Home</Link> / <span>All Categories</span></nav>
      <section className="section-head">
        <div>
          <span className="eyebrow-sm">Browse</span>
          <h1>All Categories</h1>
          <p>{categories.length} categories, {totalSub} subcategories and {tools.length} tools — organised so you can find the right one fast.</p>
        </div>
      </section>
      <section>
        <div className="grid">
          {categories.map((c) => (
            <Link key={c.slug} to={'/' + c.slug} className={'cat-card accent-' + c.accent}>
              <span className="cat-ico" aria-hidden="true">{c.icon}</span>
              <h3>{c.name}</h3>
              <p>{c.desc}</p>
              <div className="cat-meta">
                <span>{tools.filter((t) => t.cat === c.slug).length} tools</span>
                {c.subcategories?.length ? <span>{c.subcategories.length} subcategories</span> : null}
              </div>
              <span className="cat-arrow">Browse category →</span>
            </Link>
          ))}
        </div>
      </section>
    </>
  )
}
