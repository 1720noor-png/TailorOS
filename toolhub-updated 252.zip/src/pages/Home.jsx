import { useEffect } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { categories, tools, search } from '../data/registry.js'
import ToolCard from '../components/ToolCard.jsx'

const SearchIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" />
  </svg>
)

const CHIPS = ['GPA calculator', 'JSON formatter', 'Password generator', 'Invoice', 'UTM builder', 'QR code', 'Regex tester', 'Pomodoro']

const COLLECTIONS = [
  { cat: 'student-tools', title: 'Student Essentials', blurb: 'Grades, attendance and study planning.' },
  { cat: 'developer-tools', title: 'Build & Ship', blurb: 'Format, encode and inspect data while you build.' },
  { cat: 'finance-tools', title: 'Money Matters', blurb: 'Mortgages, loans, compounding and SIP returns.' },
]

const FEATURES = [
  { icon: '🔒', accent: 'blue', title: 'Runs entirely in your browser', desc: 'Every calculation happens on your device — nothing is ever uploaded to a server.' },
  { icon: '⚡', accent: 'teal', title: 'No sign-up, ever', desc: 'Open a tool and start using it immediately. No accounts, no email, no friction.' },
  { icon: '🎯', accent: 'purple', title: 'Fast & focused', desc: 'Every tool is built to do one job well, with no clutter getting in the way.' },
  { icon: '🌱', accent: 'pink', title: 'Constantly expanding', desc: 'New categories and tools are added regularly across every part of the library.' },
]

export default function Home() {
  const [p, setP] = useSearchParams()
  const q = p.get('q') || ''
  const res = q.trim() ? search(q) : null
  useEffect(() => { document.title = 'ToolHub – Free everyday tools that run in your browser' }, [])

  const totalSub = categories.reduce((n, c) => n + (c.subcategories?.length || 0), 0)
  const featuredCats = categories.slice(0, 8)
  const popularTools = tools.filter((t) => t.popular).slice(0, 8)

  return (
    <>
      <section className="hero">
        <span className="eyebrow">✨ {tools.length}+ free tools, zero sign-up</span>
        <h1>Thousands of useful tools, <span className="grad">all in one place</span></h1>
        <p>Calculate a GPA, format JSON, build a campaign link, generate a password. Everything runs in your browser and nothing is ever uploaded.</p>
        <div className="hero-search">
          <SearchIcon />
          <input className="big" type="search" value={q} aria-label="Search tools" placeholder={'Try \u201Cattendance\u201D, \u201CJSON\u201D or \u201Cpassword\u201D'}
            onChange={(e) => setP(e.target.value ? { q: e.target.value } : {}, { replace: true })} />
          <span className="kbd-hint" aria-hidden="true">Ctrl K</span>
        </div>
        <div className="chips">
          {CHIPS.map((c) => (
            <button key={c} type="button" className="chip" onClick={() => setP({ q: c })}>{c}</button>
          ))}
        </div>
      </section>

      {res ? (
        <section aria-live="polite">
          <h2>{res.length} result{res.length === 1 ? '' : 's'} for "{q}"</h2>
          {res.length ? <div className="grid">{res.map((t) => <ToolCard key={t.cat + t.slug} t={t} />)}</div>
            : <div className="empty"><p>No tools match. Try a broader word like "calculator" or "text".</p></div>}
        </section>
      ) : (
        <>
          <section>
            <div className="stats">
              <div className="stat"><b>{tools.length}+</b><span>Free tools</span></div>
              <div className="stat"><b>{categories.length}</b><span>Categories</span></div>
              <div className="stat"><b>{totalSub}</b><span>Subcategories</span></div>
              <div className="stat"><b>100%</b><span>Browser-based</span></div>
            </div>
          </section>

          <section>
            <div className="section-head">
              <div><span className="eyebrow-sm">Featured</span><h2>Popular tools</h2><p>The tools people reach for most.</p></div>
              <Link className="view-all" to="/tools?popular=1">View all popular →</Link>
            </div>
            <div className="grid">{popularTools.map((t) => <ToolCard key={t.cat + t.slug} t={t} />)}</div>
          </section>

          <section>
            <div className="section-head">
              <div><span className="eyebrow-sm">Explore</span><h2>Browse categories</h2><p>Every tool is organised into a category and, in most cases, a subcategory.</p></div>
              <Link className="view-all" to="/categories">View all {categories.length} categories →</Link>
            </div>
            <div className="grid">
              {featuredCats.map((c) => (
                <Link key={c.slug} to={'/' + c.slug} className={'cat-card accent-' + c.accent}>
                  <span className="cat-ico" aria-hidden="true">{c.icon}</span>
                  <h3>{c.name}</h3>
                  <p>{c.desc}</p>
                  <div className="cat-meta">
                    <span>{tools.filter((t) => t.cat === c.slug).length} tools</span>
                    {c.subcategories?.length ? <span>{c.subcategories.length} subcategories</span> : null}
                  </div>
                  <span className="cat-arrow">Browse category →</span>
                </Link>
              ))}
            </div>
          </section>

          <section>
            <div className="section-head">
              <div><span className="eyebrow-sm">Collections</span><h2>Popular tool collections</h2><p>Curated groups of tools for common jobs.</p></div>
            </div>
            {COLLECTIONS.map((col) => {
              const c = categories.find((x) => x.slug === col.cat)
              const list = tools.filter((t) => t.cat === col.cat).slice(0, 4)
              return (
                <div key={col.cat} className={'collection accent-' + c.accent}>
                  <div className="collection-head">
                    <span className="cat-ico" aria-hidden="true">{c.icon}</span>
                    <div><h3>{col.title}</h3><p>{col.blurb}</p></div>
                  </div>
                  <div className="grid tight">{list.map((t) => <ToolCard key={t.slug} t={t} />)}</div>
                </div>
              )
            })}
          </section>

          <section>
            <div className="section-head"><div><span className="eyebrow-sm">Why ToolHub</span><h2>Built to be trusted</h2></div></div>
            <div className="why-grid">
              {FEATURES.map((f) => (
                <div key={f.title} className={'feature accent-' + f.accent}>
                  <span className="f-ico" aria-hidden="true">{f.icon}</span>
                  <h3>{f.title}</h3>
                  <p>{f.desc}</p>
                </div>
              ))}
            </div>
          </section>

          <section>
            <div className="cta-band">
              <h2>Find the right tool in seconds</h2>
              <p>Browse the full library or search for exactly what you need — every tool is free and runs locally.</p>
              <Link className="btn" to="/tools">Explore all {tools.length}+ tools</Link>
            </div>
          </section>
        </>
      )}
    </>
  )
}
