import { useEffect } from 'react'
import { Link, useParams } from 'react-router-dom'
import { categories, tools, related } from '../data/registry.js'
import ToolCard from '../components/ToolCard.jsx'
import NotFound from './NotFound.jsx'
export default function ToolPage() {
  const { cat, tool } = useParams()
  const c = categories.find((x) => x.slug === cat)
  const t = tools.find((x) => x.cat === cat && x.slug === tool)
  useEffect(() => {
    if (!t) return
    document.title = `${t.name} – Free online tool | ToolHub`
    let m = document.querySelector('meta[name="description"]')
    if (!m) { m = document.createElement('meta'); m.name = 'description'; document.head.appendChild(m) }
    m.content = `${t.desc} ${t.why}`
  }, [t])
  if (!c || !t) return <NotFound />
  const Tool = t.Component
  return (
    <>
      <nav className="crumbs" aria-label="Breadcrumb"><Link to="/">Home</Link> / <Link to={'/' + c.slug}>{c.name}</Link> / <span>{t.name}</span></nav>
      <header className={'head accent-' + c.accent}>
        <span className="ico big" aria-hidden="true">{t.icon}</span>
        <div>
          <h1>{t.name}</h1>
          <p>{t.desc}</p>
          <div className="head-meta">
            <small>{c.name}</small>
            {t.subcatName && <span className="badge sub">{t.subcatName}</span>}
            {t.popular && <span className="badge popular">Popular</span>}
          </div>
        </div>
      </header>
      <section className="note"><h2>Why is {t.name} useful?</h2><p>{t.why}</p></section>
      <section className="panel" aria-label={t.name}><Tool key={t.slug} /></section>
      <section><h2>How to use</h2><ol>{t.steps.map((s) => <li key={s}>{s}</li>)}</ol></section>
      <section>
        <div className="section-head"><h2>Related tools</h2></div>
        <div className="grid">{related(t).map((r) => <ToolCard key={r.slug} t={r} />)}</div>
      </section>
      <p className="back"><Link to={'/' + c.slug}>Back to {c.name}</Link> · <Link to="/">Back to Home</Link></p>
    </>
  )
}
