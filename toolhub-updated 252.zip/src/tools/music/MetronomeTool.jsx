import { useState, useEffect, useRef } from 'react'
import { Field } from '../../components/ui.jsx'

export default function MetronomeTool() {
  const [bpm, setBpm] = useState(120)
  const [beatsPerBar, setBeatsPerBar] = useState(4)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentBeat, setCurrentBeat] = useState(0)

  const timerRef = useRef(null)
  const audioCtxRef = useRef(null)

  const playClick = (isFirstBeat) => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || window.webkitAudioContext)()
      }
      const ctx = audioCtxRef.current
      if (ctx.state === 'suspended') {
        ctx.resume()
      }
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.type = 'sine'
      osc.frequency.setValueAtTime(isFirstBeat ? 1000 : 750, ctx.currentTime)
      gain.gain.setValueAtTime(1, ctx.currentTime)
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05)
      osc.connect(gain)
      gain.connect(ctx.destination)
      osc.start()
      osc.stop(ctx.currentTime + 0.05)
    } catch {
      // audio fallback silently handled
    }
  }

  useEffect(() => {
    if (isPlaying) {
      const intervalMs = (60 / bpm) * 1000
      timerRef.current = setInterval(() => {
        setCurrentBeat((prev) => {
          const next = (prev + 1) % beatsPerBar
          playClick(next === 0)
          return next
        })
      }, intervalMs)
    } else {
      clearInterval(timerRef.current)
      setCurrentBeat(0)
    }
    return () => clearInterval(timerRef.current)
  }, [isPlaying, bpm, beatsPerBar])

  const togglePlay = () => {
    setIsPlaying(!isPlaying)
  }

  return (
    <div className="tool-body">
      <div className="row">
        <Field label={`Tempo: ${bpm} BPM`}>
          <input
            type="range"
            min="40"
            max="240"
            value={bpm}
            onChange={(e) => setBpm(Number(e.target.value))}
          />
        </Field>
        <Field label="Time Signature Beats">
          <select value={beatsPerBar} onChange={(e) => setBeatsPerBar(Number(e.target.value))}>
            <option value={2}>2/4 March Tempo</option>
            <option value={3}>3/4 Waltz Time</option>
            <option value={4}>4/4 Standard Time</option>
            <option value={6}>6/8 Compound Time</option>
          </select>
        </Field>
      </div>

      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          gap: '0.8rem',
          margin: '1.5rem 0',
        }}
      >
        {Array.from({ length: beatsPerBar }).map((_, idx) => (
          <div
            key={idx}
            style={{
              width: '45px',
              height: '45px',
              borderRadius: '50%',
              background:
                isPlaying && currentBeat === idx
                  ? idx === 0
                    ? 'var(--bad)'
                    : 'var(--brand)'
                  : 'var(--line)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: isPlaying && currentBeat === idx ? '#fff' : 'var(--muted)',
              fontWeight: 700,
              fontSize: '1.1rem',
              transition: 'background 0.05s ease',
            }}
          >
            {idx + 1}
          </div>
        ))}
      </div>

      <div className="actions center">
        <button
          type="button"
          className="btn"
          style={{ padding: '0.8rem 2rem', fontSize: '1.1rem' }}
          onClick={togglePlay}
        >
          {isPlaying ? '⏸️ Stop Metronome' : '▶️ Start Metronome'}
        </button>
      </div>
    </div>
  )
}
