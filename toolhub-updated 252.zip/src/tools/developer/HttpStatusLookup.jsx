import { useMemo, useState } from 'react'
import { Field } from '../../components/ui.jsx'

const CODES = {
  100: ['Continue', 'The initial part of the request has been received; the client should continue.'],
  101: ['Switching Protocols', 'The server agrees to switch protocols as requested.'],
  200: ['OK', 'The request succeeded.'],
  201: ['Created', 'The request succeeded and a new resource was created.'],
  202: ['Accepted', 'The request was accepted for processing, but not completed yet.'],
  204: ['No Content', 'The request succeeded but there is no content to send back.'],
  301: ['Moved Permanently', 'The resource has been permanently moved to a new URL.'],
  302: ['Found', 'The resource temporarily resides at a different URL.'],
  304: ['Not Modified', 'The cached version of the resource is still valid.'],
  400: ['Bad Request', 'The server could not understand the request due to invalid syntax.'],
  401: ['Unauthorized', 'Authentication is required and has failed or not been provided.'],
  403: ['Forbidden', 'The client does not have access rights to the content.'],
  404: ['Not Found', 'The server cannot find the requested resource.'],
  405: ['Method Not Allowed', 'The request method is not supported for this resource.'],
  408: ['Request Timeout', 'The server timed out waiting for the request.'],
  409: ['Conflict', 'The request conflicts with the current state of the server.'],
  410: ['Gone', 'The resource requested is no longer available and will not be available again.'],
  413: ['Payload Too Large', 'The request entity is larger than limits the server will process.'],
  422: ['Unprocessable Entity', 'The request was well-formed but contains semantic errors.'],
  429: ['Too Many Requests', 'The user has sent too many requests in a given amount of time.'],
  500: ['Internal Server Error', 'The server has encountered a situation it does not know how to handle.'],
  501: ['Not Implemented', 'The request method is not supported by the server.'],
  502: ['Bad Gateway', 'The server got an invalid response from an upstream server.'],
  503: ['Service Unavailable', 'The server is not ready to handle the request, often due to maintenance or overload.'],
  504: ['Gateway Timeout', 'The upstream server failed to send a request in time.'],
}
const CLASS_NAME = { 1: 'Informational', 2: 'Success', 3: 'Redirection', 4: 'Client Error', 5: 'Server Error' }

export default function HttpStatusLookup() {
  const [q, setQ] = useState('')
  const results = useMemo(() => {
    const query = q.trim().toLowerCase()
    const entries = Object.entries(CODES)
    if (!query) return entries
    return entries.filter(([code, [name, desc]]) => code.includes(query) || name.toLowerCase().includes(query) || desc.toLowerCase().includes(query))
  }, [q])
  return (
    <div>
      <Field label="Search by code or keyword"><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="e.g. 404 or timeout" /></Field>
      <div className="out">
        {results.length === 0 && <p className="muted">No matching status codes.</p>}
        {results.map(([code, [name, desc]]) => (
          <p key={code}><strong>{code} {name}</strong> <span className="badge">{CLASS_NAME[code[0]]}</span><br /><span className="muted">{desc}</span></p>
        ))}
      </div>
    </div>
  )
}
