import { useState } from 'react'
import QRCode from 'qrcode'
import { Field, Msg, download } from '../../components/ui.jsx'
export default function QrGenerator() {
  const [t, setT] = useState('')
  const [lvl, setLvl] = useState('M')
  const [size, setSize] = useState(320)
  const [png, setPng] = useState('')
  const [used, setUsed] = useState(null)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const make = async () => {
    setPng('')
    const w = Number(size)
    if (!t.trim()) return setErr('Enter text or a URL to encode.')
    if (!Number.isInteger(w) || w < 128 || w > 1024) return setErr('Size must be a whole number from 128 to 1024 pixels.')
    setBusy(true)
    try { setPng(await QRCode.toDataURL(t, { width: w, margin: 2, errorCorrectionLevel: lvl })); setUsed({ t, lvl }); setErr('') }
    catch (e) { setErr(/big|long|capacity/i.test(e.message) ? 'That text is too long for a QR code at this error-correction level. Shorten it or choose a lower level.' : 'Could not generate the QR code: ' + e.message) }
    finally { setBusy(false) }
  }
  const svg = async () => { try { download('qr-code.svg', await QRCode.toString(used.t, { type: 'svg', errorCorrectionLevel: used.lvl, margin: 2 }), 'image/svg+xml') } catch (e) { setErr('SVG export failed: ' + e.message) } }
  return (
    <div>
      <Field label="Text or URL"><textarea rows="3" value={t} onChange={(e) => setT(e.target.value)} placeholder="https://example.com" /></Field>
      <div className="row">
        <Field label="Error correction"><select value={lvl} onChange={(e) => setLvl(e.target.value)}><option value="L">Low (7%)</option><option value="M">Medium (15%)</option><option value="Q">Quartile (25%)</option><option value="H">High (30%)</option></select></Field>
        <Field label="Size (px)"><input type="number" min="128" max="1024" value={size} onChange={(e) => setSize(e.target.value)} /></Field>
      </div>
      <div className="actions"><button className="btn" onClick={make} disabled={busy}>{busy ? 'Generating…' : 'Generate QR code'}</button><button className="btn ghost" onClick={() => { setT(''); setPng(''); setErr('') }}>Reset</button></div>
      <Msg>{err}</Msg>
      {png && <div className="out"><img src={png} alt="Generated QR code" style={{ maxWidth: '100%', height: 'auto' }} />
        <div className="actions"><a className="btn ghost" href={png} download="qr-code.png">Download PNG</a><button className="btn ghost" onClick={svg}>Download SVG</button></div></div>}
      <p className="hint">Generated locally with the open-source qrcode library. Your text is never uploaded.</p>
    </div>
  )
}
